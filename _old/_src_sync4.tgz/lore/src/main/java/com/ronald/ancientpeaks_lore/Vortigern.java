package com.ronald.ancientpeaks_lore;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.EvokerFangs;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

/**
 * Vortigern, the usurper, woken when Excalibur is drawn from the stone.
 *   Rises out of the ground (intro, 3 s, can't be hurt), then fights:
 *     attack_1 / attack_2   a two-swing combo in reach          (hit at tick 8 / tick 10 of the animation)
 *     slam                  both fists into the ground, knocks everyone near up and back   (tick 16)
 *   At half health he roars (phase_change, 2 s, can't be hurt), and from then on also uses
 *     spell                 a line of fangs out of the ground toward you                    (tick 12)
 *     summon                three Saxon warriors                                            (tick 20)
 *   Heavy blows stagger him. Anything but Excalibur does half damage to him. He drops his crown.
 */
public class Vortigern extends Monster implements GeoEntity {
    static final String MINION = "ancientpeaks_lore_vortigern_minion";

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bar = new ServerBossEvent(Component.literal("Vortigern, the Usurper"), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);

    private int intro = 60, busy, actTick, attackCd, slamCd = 120, spellCd = 60, summonCd, combo;
    private String act;
    private boolean phase2;
    private float staggerDamage;

    public Vortigern(EntityType<? extends Vortigern> type, Level level) {
        super(type, level);
        xpReward = 500;
        setPersistenceRequired();
        setMaxUpStep(1.0f);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 400).add(Attributes.ARMOR, 12).add(Attributes.ARMOR_TOUGHNESS, 6)
                .add(Attributes.ATTACK_DAMAGE, 14).add(Attributes.ATTACK_KNOCKBACK, 1.2).add(Attributes.MOVEMENT_SPEED, 0.27)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.85).add(Attributes.FOLLOW_RANGE, 48);
    }

    /** Draw him up out of the summit, a little way from the stone, facing whoever drew the sword. */
    public static void rise(ServerLevel level, BlockPos stone, Player by) {
        if (!level.getEntitiesOfClass(Vortigern.class, new net.minecraft.world.phys.AABB(stone).inflate(96)).isEmpty()) return;
        Vec3 away = by == null ? new Vec3(1, 0, 0) : new Vec3(stone.getX() + 0.5 - by.getX(), 0, stone.getZ() + 0.5 - by.getZ());
        if (away.lengthSqr() < 1e-3) away = new Vec3(1, 0, 0);
        away = away.normalize();
        int x = Mth.floor(stone.getX() + 0.5 + away.x * 10), z = Mth.floor(stone.getZ() + 0.5 + away.z * 10);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        Vortigern v = LoreContent.VORTIGERN.get().create(level);
        if (v == null) return;
        float yaw = by == null ? 0 : (float) (Mth.atan2(by.getZ() - (z + 0.5), by.getX() - (x + 0.5)) * Mth.RAD_TO_DEG) - 90;
        v.moveTo(x + 0.5, y, z + 0.5, yaw, 0);
        v.setYHeadRot(yaw); v.setYBodyRot(yaw);
        v.finalizeSpawn(level, level.getCurrentDifficultyAt(v.blockPosition()), MobSpawnType.EVENT, null, null);
        if (by != null) v.setTarget(by);
        level.addFreshEntity(v);
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DEEPSLATE.defaultBlockState()), x + 0.5, y + 0.2, z + 0.5, 120, 1.2, 0.3, 1.2, 0.2);
        level.playSound(null, v.blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 3.0f, 0.7f);
        Quest.say(level, v.position(), 64, "Vortigern", ChatFormatting.DARK_RED, "So the old fool found himself another champion. Come, then. The crown is MINE, and so is that blade!");
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 16));
        targetSelector.addGoal(1, new HurtByTargetGoal(this, Vortigern.class));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean requiresCustomPersistence() { return true; }
    @Override public boolean canChangeDimensions() { return false; }
    @Override protected boolean shouldDespawnInPeaceful() { return false; }
    @Override public boolean causeFallDamage(float d, float m, DamageSource s) { return false; }

    // ------------------------------------------------------------------ taking hits
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        if (intro > 0 || "phase_change".equals(act)) return false;
        Entity by = source.getEntity();
        if (by == this || (by != null && by.getTags().contains(MINION))) return false;
        if (!(by instanceof LivingEntity le && le.getMainHandItem().is(LoreContent.EXCALIBUR.get()))) amount *= 0.5f;
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide) {
            ServerLevel sl = (ServerLevel) level();
            staggerDamage += amount;
            if (!phase2 && getHealth() <= getMaxHealth() / 2) {
                phase2 = true; summonCd = 50; spellCd = 80;
                start("phase_change", 40);
                getNavigation().stop();
                sl.playSound(null, blockPosition(), SoundEvents.RAVAGER_ROAR, SoundSource.HOSTILE, 3.0f, 0.6f);
                Quest.say(sl, position(), 64, "Vortigern", ChatFormatting.DARK_RED, "Enough! Rise, my warriors! Rise and bury this upstart!");
                shove(sl, 8, 1.4, 0);
            } else if (staggerDamage >= 45 && !"phase_change".equals(act)) {
                staggerDamage = 0;
                start("stagger", 20);
                getNavigation().stop();
            }
        }
        return hit;
    }

    // ------------------------------------------------------------------ fighting
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        ServerLevel sl = (ServerLevel) level();
        bar.setProgress(getHealth() / getMaxHealth());
        if (intro > 0) {
            if (intro == 60) triggerAnim("action", "intro");
            intro--;
            getNavigation().stop();
            if (intro % 6 == 0) sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DEEPSLATE.defaultBlockState()), getX(), getY() + 0.2, getZ(), 25, 0.8, 0.2, 0.8, 0.15);
            return;
        }
        if (attackCd > 0) attackCd--;
        if (slamCd > 0) slamCd--;
        if (spellCd > 0) spellCd--;
        if (summonCd > 0) summonCd--;

        LivingEntity t = getTarget();
        if (act != null) {
            actTick++;
            perform(sl, t);
            if (--busy <= 0) act = null;
            if (t != null) getLookControl().setLookAt(t, 30, 30);
            return;
        }
        if (t == null || !t.isAlive()) return;
        getLookControl().setLookAt(t, 30, 30);
        double d = distanceTo(t);
        if (phase2 && summonCd <= 0) { start("summon", 30); summonCd = 20 * 30; getNavigation().stop(); }
        else if (slamCd <= 0 && d < 5.5) { start("slam", 30); slamCd = 20 * 8; getNavigation().stop(); }
        else if (phase2 && spellCd <= 0 && d > 5 && d < 24) { start("spell", 25); spellCd = 20 * 6; getNavigation().stop(); }
        else if (d < 3.8 && attackCd <= 0) { start(combo++ % 2 == 0 ? "attack_1" : "attack_2", combo % 2 == 1 ? 12 : 20); attackCd = 6; }
        else if (tickCount % 8 == 0) getNavigation().moveTo(t, d > 10 ? 1.35 : 1.0);
    }

    private void start(String name, int ticks) {
        act = name; actTick = 0; busy = ticks;
        triggerAnim("action", name);
    }

    /** The moment in each move where it lands. */
    private void perform(ServerLevel sl, LivingEntity t) {
        switch (act) {
            case "attack_1" -> { if (actTick == 8) swing(sl, t, 1.0f); }
            case "attack_2" -> { if (actTick == 10) swing(sl, t, 1.3f); }
            case "slam" -> {
                if (actTick == 16) {
                    sl.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 2.0f, 0.6f);
                    sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.3, getZ(), 6, 1.5, 0.2, 1.5, 0);
                    sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, sl.getBlockState(blockPosition().below())), getX(), getY() + 0.2, getZ(), 120, 2.5, 0.2, 2.5, 0.3);
                    shove(sl, 5.5, 1.1, (float) getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.9f);
                }
            }
            case "spell" -> {
                if (actTick == 12 && t != null) {
                    sl.playSound(null, blockPosition(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.HOSTILE, 2.0f, 0.6f);
                    double a = Mth.atan2(t.getZ() - getZ(), t.getX() - getX());
                    for (int i = 0; i < 14; i++) {
                        double r = 1.5 + i * 1.3;
                        fang(sl, getX() + Math.cos(a) * r, getZ() + Math.sin(a) * r, (float) a, i);
                    }
                }
            }
            case "summon" -> { if (actTick == 20) summon(sl, t); }
            default -> { }
        }
    }

    private void swing(ServerLevel sl, LivingEntity t, float mul) {
        if (t == null) return;
        sl.playSound(null, blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 1.5f, 0.6f);
        Vec3 look = getLookAngle();
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(4.2, 1.5, 4.2), e -> e != this && !e.getTags().contains(MINION))) {
            Vec3 to = e.position().subtract(position()).normalize();
            if (to.dot(look) < 0.2) continue;                                       // only in front of him
            float before = (float) getAttributeValue(Attributes.ATTACK_DAMAGE);
            e.hurt(damageSources().mobAttack(this), before * mul);
            e.knockback(0.8 * mul, getX() - e.getX(), getZ() - e.getZ());
        }
    }

    /** Everyone within r is thrown up and away (and hurt, if damage > 0). */
    private void shove(ServerLevel sl, double r, double strength, float damage) {
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r, 2, r), e -> e != this && !e.getTags().contains(MINION))) {
            if (damage > 0) e.hurt(damageSources().mobAttack(this), damage);
            Vec3 away = e.position().subtract(position()).multiply(1, 0, 1);
            if (away.lengthSqr() < 1e-3) away = new Vec3(1, 0, 0);
            away = away.normalize().scale(strength);
            e.push(away.x, 0.55 * strength, away.z);
            e.hurtMarked = true;
        }
    }

    private void fang(ServerLevel sl, double x, double z, float yaw, int delay) {
        int top = Mth.floor(getY()) + 4, bottom = Mth.floor(getY()) - 4;
        for (int y = top; y >= bottom; y--) {
            BlockPos p = BlockPos.containing(x, y, z);
            if (sl.getBlockState(p.below()).isFaceSturdy(sl, p.below(), net.minecraft.core.Direction.UP) && sl.isEmptyBlock(p)) {
                EvokerFangs f = new EvokerFangs(sl, x, y, z, yaw, delay, this);
                f.addTag(MINION);
                sl.addFreshEntity(f);
                return;
            }
        }
    }

    private void summon(ServerLevel sl, LivingEntity t) {
        long alive = sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(48), m -> m.getTags().contains(MINION)).size();
        sl.playSound(null, blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.HOSTILE, 2.5f, 0.6f);
        for (int i = 0; i < 3 && alive + i < 6; i++) {
            double a = random.nextDouble() * Math.PI * 2;
            int x = Mth.floor(getX() + Math.cos(a) * 4), z = Mth.floor(getZ() + Math.sin(a) * 4);
            int y = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            Mob w = EntityType.VINDICATOR.create(sl);
            if (w == null) continue;
            w.moveTo(x + 0.5, y, z + 0.5, random.nextFloat() * 360, 0);
            w.finalizeSpawn(sl, sl.getCurrentDifficultyAt(w.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
            w.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
            w.setDropChance(EquipmentSlot.HEAD, 0);
            w.setCustomName(Component.literal("Saxon Warrior").withStyle(ChatFormatting.DARK_RED));
            w.addTag(MINION);
            w.setPersistenceRequired();
            if (t != null) w.setTarget(t);
            sl.addFreshEntity(w);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, x + 0.5, y + 1, z + 0.5, 20, 0.3, 0.6, 0.3, 0.02);
        }
    }

    // ------------------------------------------------------------------ the end of him
    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level().isClientSide) return;
        ServerLevel sl = (ServerLevel) level();
        triggerAnim("action", "death");
        bar.setProgress(0);
        Quest.say(sl, position(), 64, "Vortigern", ChatFormatting.DARK_RED, "The red dragon... it was always... going to rise...");
        for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(64))) {
            Quest.set(p, Quest.SLAIN, true);
            p.sendSystemMessage(Component.literal("The usurper has fallen.").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        }
        for (Mob m : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(64), m -> m.getTags().contains(MINION))) {
            sl.sendParticles(ParticleTypes.POOF, m.getX(), m.getY() + 1, m.getZ(), 10, 0.3, 0.5, 0.3, 0.02);
            m.discard();
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        ItemStack crown = new ItemStack(LoreContent.CROWN.get());
        net.minecraft.world.entity.item.ItemEntity it = spawnAtLocation(crown, 1.5f);
        if (it != null) { it.setGlowingTag(true); it.setUnlimitedLifetime(); }
    }

    /** The death animation gets its 3 seconds before he is gone. */
    @Override
    protected void tickDeath() {
        deathTime++;
        if (!level().isClientSide && deathTime % 5 == 0)
            ((ServerLevel) level()).sendParticles(ParticleTypes.SOUL, getX(), getY() + 1, getZ(), 8, 0.5, 0.8, 0.5, 0.02);
        if (deathTime >= 60 && !level().isClientSide) {
            level().broadcastEntityEvent(this, (byte) 60);
            remove(RemovalReason.KILLED);
        }
    }

    // ------------------------------------------------------------------ boss bar, saving
    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bar.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bar.removePlayer(p); }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putBoolean("Phase2", phase2);
        t.putInt("Intro", intro);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        phase2 = t.getBoolean("Phase2");
        intro = t.contains("Intro") ? t.getInt("Intro") : 0;
        if (hasCustomName()) bar.setName(getDisplayName());
    }

    // ------------------------------------------------------------------ animation
    static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle"), WALK = RawAnimation.begin().thenLoop("walk"),
            RUN = RawAnimation.begin().thenLoop("run");

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<>(this, "main", 5, s -> {
            if (isDeadOrDying()) return PlayState.STOP;
            if (!s.isMoving()) return s.setAndContinue(IDLE);
            return s.setAndContinue(getDeltaMovement().horizontalDistanceSqr() > 0.012 ? RUN : WALK);
        }));
        AnimationController<Vortigern> action = new AnimationController<>(this, "action", 2, s -> PlayState.STOP);
        for (String a : new String[]{"intro", "attack_1", "attack_2", "slam", "spell", "summon", "stagger", "phase_change"})
            action.triggerableAnim(a, RawAnimation.begin().thenPlay(a));
        action.triggerableAnim("death", RawAnimation.begin().thenPlayAndHold("death"));
        c.add(action);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
