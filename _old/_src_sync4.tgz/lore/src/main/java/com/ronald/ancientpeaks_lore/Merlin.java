package com.ronald.ancientpeaks_lore;

import com.ronald.ancientpeaks.world.HighlandsAccess;
import com.ronald.ancientpeaks.world.Island;
import com.ronald.ancientpeaks.world.IslandSampler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

/**
 * Merlin, wounded in his besieged chapel near spawn.
 *   WOUNDED  lying on the floor. When a player comes close the siege begins.
 *   SIEGE    raiders come in waves and a bar shows him fading. Heal him in time (a golden apple, or a potion of
 *            healing drunk from your hand onto him / thrown at him) and he gets up, drives the raiders off, blesses
 *            everyone near and gives the healer his compass, which points to the nearest gateway to the island.
 *            If the time runs out he slips away; the raiders go, and the siege can be tried again a minute later.
 *   HEALED   stays in his chapel; talk to him for a hint (and a new compass if you lost yours).
 */
public class Merlin extends PathfinderMob implements GeoEntity {
    public static final int WOUNDED = 0, SIEGE = 1, HEALED = 2;
    static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(Merlin.class, EntityDataSerializers.INT);
    static final int SIEGE_TICKS = 20 * 180, WAVE_TICKS = 20 * 25, MAX_WAVES = 6;
    static final String BESIEGER = "ancientpeaks_lore_besieger";
    static final TagKey<Structure> GATEWAYS = TagKey.create(Registries.STRUCTURE, new ResourceLocation(AncientPeaksLore.MODID, "gateways"));

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bar = new ServerBossEvent(Component.literal("Merlin is fading"), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    private int timer, waveIn, waves, cooldown, talk = -1;
    private java.util.UUID healer;

    public Merlin(EntityType<? extends Merlin> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        bar.setVisible(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 40).add(Attributes.MOVEMENT_SPEED, 0.22).add(Attributes.FOLLOW_RANGE, 16);
    }

    public int state() { return entityData.get(STATE); }
    public boolean healed() { return state() == HEALED; }
    void setState(int s) { entityData.set(STATE, s); }

    @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(STATE, WOUNDED); }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.6) {
            @Override public boolean canUse() { return healed() && talk < 0 && super.canUse(); }
            @Override public boolean canContinueToUse() { return healed() && talk < 0 && super.canContinueToUse(); }
        });
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8) {
            @Override public boolean canUse() { return healed() && super.canUse(); }
        });
        goalSelector.addGoal(4, new RandomLookAroundGoal(this) {
            @Override public boolean canUse() { return healed() && super.canUse(); }
        });
    }

    // ------------------------------------------------------------------ he can't be killed (only /kill)
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        return false;
    }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean requiresCustomPersistence() { return true; }
    @Override public boolean isPushable() { return healed(); }
    @Override protected boolean shouldDespawnInPeaceful() { return false; }

    /** Instant health (a thrown or lingering potion of healing) wakes him too. */
    @Override
    public void heal(float amount) {
        super.heal(amount);
        if (amount > 0 && !level().isClientSide && state() == SIEGE) {
            Player p = level().getNearestPlayer(this, 24);
            onHealed(p);
        }
    }

    // ------------------------------------------------------------------ talking to him / healing him by hand
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (level().isClientSide) return InteractionResult.SUCCESS;
        ServerLevel sl = (ServerLevel) level();
        if (state() != HEALED) {
            boolean cure = held.is(Items.GOLDEN_APPLE) || held.is(Items.ENCHANTED_GOLDEN_APPLE)
                    || (held.is(Items.POTION) && (PotionUtils.getPotion(held) == Potions.HEALING || PotionUtils.getPotion(held) == Potions.STRONG_HEALING));
            if (!cure) {
                Quest.hint(player, state() == SIEGE ? "He is badly hurt... a golden apple or a potion of healing might save him."
                        : "An old man lies wounded on the floor, barely breathing.");
                return InteractionResult.CONSUME;
            }
            if (!player.getAbilities().instabuild) {
                if (held.is(Items.POTION)) player.setItemInHand(hand, new ItemStack(Items.GLASS_BOTTLE));
                else held.shrink(1);
            }
            if (state() == WOUNDED) startSiege(sl, false);     // healed before the raiders even came
            onHealed(player);
            return InteractionResult.CONSUME;
        }
        if (talk >= 0) return InteractionResult.CONSUME;
        triggerAnim("action", "talk");
        boolean slain = Quest.has(player, Quest.SLAIN), drawn = Quest.has(player, Quest.EXCALIBUR);
        String line = slain ? "The usurper is gone and the crown is yours to bear. Wear it more wisely than he did."
                : drawn ? "You carry the sword of kings. Vortigern will not rest while it is in your hand. Be ready."
                : "The compass knows the way to the gateway. Beyond the sea, seek the high meadow where three swords stand.";
        Quest.say(sl, position(), 12, "Merlin", ChatFormatting.LIGHT_PURPLE, line);
        if (!slain && !Quest.has(player, Quest.BLESSED)) {
            Quest.set(player, Quest.BLESSED, true);
            Quest.hint(player, "Merlin's blessing is upon you.");
        }
        if (!slain && !drawn && !hasCompass(player)) giveCompass(sl, player);
        return InteractionResult.CONSUME;
    }

    // ------------------------------------------------------------------ the siege
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        ServerLevel sl = (ServerLevel) level();
        if (state() != HEALED) getNavigation().stop();
        if (cooldown > 0) cooldown--;

        if (state() == WOUNDED && cooldown == 0 && tickCount % 10 == 0) {
            Player p = sl.getNearestPlayer(getX(), getY(), getZ(), 18, pl -> !pl.isSpectator() && !((Player) pl).isCreative());
            if (p != null) startSiege(sl, true);
        }
        if (state() == SIEGE) {
            timer--;
            bar.setProgress(Mth.clamp(timer / (float) SIEGE_TICKS, 0, 1));
            if (tickCount % 20 == 0) updateBar(sl);
            if (--waveIn <= 0 && waves < MAX_WAVES) { spawnWave(sl); waves++; waveIn = WAVE_TICKS; }
            if (timer % 400 == 0 && timer > 0) sl.sendParticles(ParticleTypes.SOUL, getX(), getY() + 0.3, getZ(), 6, 0.4, 0.1, 0.4, 0.01);
            boolean anyone = sl.getNearestPlayer(this, 64) != null;
            if (timer <= 0 || !anyone) fail(sl, anyone);
        }
        if (talk >= 0) dialogue(sl);
    }

    private void startSiege(ServerLevel sl, boolean announce) {
        setState(SIEGE);
        timer = SIEGE_TICKS; waves = 0; waveIn = announce ? 100 : WAVE_TICKS;
        bar.setProgress(1); bar.setVisible(true); updateBar(sl);
        if (announce) {
            Quest.say(sl, position(), 40, "Merlin", ChatFormatting.LIGHT_PURPLE, "...you... you can hear me? Then hear this: they are coming back for the old man.");
            Quest.say(sl, position(), 40, "Merlin", ChatFormatting.LIGHT_PURPLE, "Their blades found me... I have not long. A golden apple, a draught of healing... anything...");
            sl.playSound(null, blockPosition(), SoundEvents.RAID_HORN.get(), SoundSource.HOSTILE, 4.0f, 1.0f);
        }
    }

    private void updateBar(ServerLevel sl) {
        for (ServerPlayer p : List.copyOf(bar.getPlayers())) if (p.distanceToSqr(this) > 48 * 48 || !p.isAlive()) bar.removePlayer(p);
        if (bar.isVisible()) for (ServerPlayer p : sl.players()) if (p.distanceToSqr(this) <= 48 * 48) bar.addPlayer(p);
    }

    /** Raiders close in from every side, more each wave, all after the nearest player. */
    private void spawnWave(ServerLevel sl) {
        Player target = sl.getNearestPlayer(this, 64);
        int n = 2 + waves;
        for (int i = 0; i < n; i++) {
            double a = random.nextDouble() * Math.PI * 2, r = 14 + random.nextDouble() * 8;
            int x = Mth.floor(getX() + Math.cos(a) * r), z = Mth.floor(getZ() + Math.sin(a) * r);
            int y = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            EntityType<? extends Mob> type = waves >= 3 && i == 0 ? EntityType.VINDICATOR : i % 3 == 2 ? EntityType.SKELETON : EntityType.ZOMBIE;
            Mob m = type.create(sl);
            if (m == null) continue;
            m.moveTo(x + 0.5, y, z + 0.5, random.nextFloat() * 360, 0);
            m.finalizeSpawn(sl, sl.getCurrentDifficultyAt(m.blockPosition()), MobSpawnType.EVENT, null, null);
            m.setItemSlot(EquipmentSlot.HEAD, new ItemStack(i % 2 == 0 ? Items.CHAINMAIL_HELMET : Items.LEATHER_HELMET));
            m.setDropChance(EquipmentSlot.HEAD, 0);
            m.setCustomName(Component.literal("Raider"));
            m.addTag(BESIEGER);
            m.setPersistenceRequired();
            if (target != null) m.setTarget(target);
            sl.addFreshEntity(m);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, x + 0.5, y + 1, z + 0.5, 8, 0.3, 0.5, 0.3, 0.01);
        }
    }

    private void fail(ServerLevel sl, boolean anyoneThere) {
        setState(WOUNDED);
        bar.setVisible(false); bar.removeAllPlayers();
        cooldown = 20 * 60;
        if (anyoneThere) Quest.say(sl, position(), 48, "Merlin", ChatFormatting.LIGHT_PURPLE, "...the dark... takes me... come back... when you are ready...");
        for (Mob m : besiegers(sl)) { sl.sendParticles(ParticleTypes.POOF, m.getX(), m.getY() + 1, m.getZ(), 10, 0.3, 0.5, 0.3, 0.02); m.discard(); }
    }

    private List<Mob> besiegers(ServerLevel sl) {
        return sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(80), m -> m.getTags().contains(BESIEGER));
    }

    private void onHealed(Player by) {
        if (state() == HEALED) return;
        ServerLevel sl = (ServerLevel) level();
        setState(HEALED);
        setHealth(getMaxHealth());
        healer = by == null ? null : by.getUUID();
        bar.setVisible(false); bar.removeAllPlayers();
        triggerAnim("action", "heal_getup");
        sl.playSound(null, blockPosition(), SoundEvents.ZOMBIE_VILLAGER_CURE, SoundSource.NEUTRAL, 1.0f, 1.0f);
        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1, getZ(), 30, 0.6, 0.8, 0.6, 0.1);
        talk = 0;
    }

    /** What he says once he is on his feet; the raiders are driven off part-way through. */
    private void dialogue(ServerLevel sl) {
        talk++;
        Player p = healer == null ? null : sl.getPlayerByUUID(healer);
        if (p == null) p = sl.getNearestPlayer(this, 24);
        if (p != null) getLookControl().setLookAt(p, 30, 30);
        String m = ChatFormatting.LIGHT_PURPLE.toString();
        switch (talk) {
            case 50 -> {
                triggerAnim("action", "cast");
                sl.playSound(null, blockPosition(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.NEUTRAL, 2.0f, 0.8f);
                for (Mob b : besiegers(sl)) {
                    sl.sendParticles(ParticleTypes.ENCHANT, b.getX(), b.getY() + 1, b.getZ(), 40, 0.4, 0.8, 0.4, 1.0);
                    sl.sendParticles(ParticleTypes.WITCH, b.getX(), b.getY() + 1, b.getZ(), 15, 0.3, 0.6, 0.3, 0.05);
                    b.hurt(damageSources().indirectMagic(this, this), 1000);
                }
                Quest.say(sl, position(), 32, "Merlin", ChatFormatting.LIGHT_PURPLE, "Begone!");
            }
            case 110 -> { triggerAnim("action", "talk"); Quest.say(sl, position(), 24, "Merlin", ChatFormatting.LIGHT_PURPLE, "Ah... the warmth returns. You have a kind hand, stranger. I am Merlin, or what is left of him."); }
            case 210 -> { triggerAnim("action", "talk"); Quest.say(sl, position(), 24, "Merlin", ChatFormatting.LIGHT_PURPLE, "Long ago I hid the sword of kings beyond the western sea, on an island the maps forgot."); }
            case 310 -> { triggerAnim("action", "talk"); Quest.say(sl, position(), 24, "Merlin", ChatFormatting.LIGHT_PURPLE, "Vortigern, who stole a crown that was never his, waits there for whoever would draw it. He sent these men for me."); }
            case 410 -> {
                triggerAnim("action", "point");
                Quest.say(sl, position(), 24, "Merlin", ChatFormatting.LIGHT_PURPLE, "Take my blessing, and this compass. It finds the old gateway. The rest... you must find for yourself.");
                for (Player q : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(24))) {
                    Quest.set(q, Quest.BLESSED, true);
                    Quest.hint(q, "Merlin's blessing is upon you.");
                }
                if (p != null) giveCompass(sl, p);
                talk = -1;
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ his compass
    static boolean hasCompass(Player p) {
        for (ItemStack s : p.getInventory().items) if (s.hasTag() && s.getTag().getBoolean("ancientpeaks_lore_compass")) return true;
        return p.getOffhandItem().hasTag() && p.getOffhandItem().getTag().getBoolean("ancientpeaks_lore_compass");
    }

    /** A lodestone-style compass to the nearest gateway (or the nearest island, if no gateway is found). */
    void giveCompass(ServerLevel sl, Player p) {
        BlockPos target = sl.findNearestMapStructure(GATEWAYS, blockPosition(), 100, false);
        if (target == null) target = nearestIsland(sl);
        ItemStack c = new ItemStack(Items.COMPASS);
        CompoundTag tag = c.getOrCreateTag();
        if (target != null) {
            tag.put("LodestonePos", NbtUtils.writeBlockPos(target));
            Level.RESOURCE_KEY_CODEC.encodeStart(net.minecraft.nbt.NbtOps.INSTANCE, sl.dimension()).result().ifPresent(d -> tag.put("LodestoneDimension", d));
            tag.putBoolean("LodestoneTracked", false);
        }
        tag.putBoolean("ancientpeaks_lore_compass", true);
        c.setHoverName(Component.literal("Merlin's Compass").withStyle(ChatFormatting.LIGHT_PURPLE).withStyle(s -> s.withItalic(false)));
        ListTag lore = new ListTag();
        lore.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal("It points to the old gateway.").withStyle(ChatFormatting.GRAY))));
        CompoundTag display = tag.getCompound("display"); display.put("Lore", lore); tag.put("display", display);
        if (!p.addItem(c)) p.drop(c, false);
    }

    private BlockPos nearestIsland(ServerLevel sl) {
        IslandSampler s = ((HighlandsAccess) (Object) sl.getChunkSource().randomState()).ancientpeaks$sampler();
        if (s == null) return null;
        int sx = Math.floorDiv(getBlockX(), IslandSampler.SECTOR), sz = Math.floorDiv(getBlockZ(), IslandSampler.SECTOR);
        Island best = null; double bd = Double.MAX_VALUE;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            Island is = s.islandInSector(sx + dx, sz + dz);
            if (is == null) continue;
            double d = Math.hypot(is.cx - getX(), is.cz - getZ());
            if (d < bd) { bd = d; best = is; }
        }
        return best == null ? null : new BlockPos(best.cx, 64, best.cz);
    }

    // ------------------------------------------------------------------ saving
    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putInt("QuestState", state() == SIEGE ? WOUNDED : state());       // a siege doesn't survive a reload
        if (healer != null) t.putUUID("Healer", healer);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        setState(t.getInt("QuestState"));
        if (t.hasUUID("Healer")) healer = t.getUUID("Healer");
    }

    @Override
    public void remove(RemovalReason reason) {
        bar.removeAllPlayers();
        super.remove(reason);
    }

    // ------------------------------------------------------------------ animation
    static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle"), WALK = RawAnimation.begin().thenLoop("walk"),
            LYING = RawAnimation.begin().thenLoop("injured_lying");

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<>(this, "main", 5, s -> {
            if (state() != HEALED && !s.getController().isPlayingTriggeredAnimation()) return s.setAndContinue(LYING);
            return s.setAndContinue(s.isMoving() ? WALK : IDLE);
        }));
        AnimationController<Merlin> action = new AnimationController<>(this, "action", 3, s -> software.bernie.geckolib.core.object.PlayState.STOP);
        for (String a : new String[]{"heal_getup", "talk", "cast", "point", "vanish"}) action.triggerableAnim(a, RawAnimation.begin().thenPlay(a));
        c.add(action);
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
