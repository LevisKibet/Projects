package com.ronald.ancientpeaks_lore;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Everything the quest adds: Merlin, Vortigern, Excalibur and its stone, and the crown. */
public final class LoreContent {
    private LoreContent() {}
    static final String MODID = AncientPeaksLore.MODID;

    static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, MODID);
    static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, MODID);
    static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, MODID);

    public static final RegistryObject<EntityType<Merlin>> MERLIN = ENTITIES.register("merlin", () ->
            EntityType.Builder.of(Merlin::new, MobCategory.MISC).sized(0.6f, 1.95f).clientTrackingRange(10).build(MODID + ":merlin"));
    public static final RegistryObject<EntityType<Vortigern>> VORTIGERN = ENTITIES.register("vortigern", () ->
            EntityType.Builder.of(Vortigern::new, MobCategory.MONSTER).sized(0.9f, 2.7f).fireImmune().clientTrackingRange(12).build(MODID + ":vortigern"));

    public static final RegistryObject<Block> SWORD_IN_STONE = BLOCKS.register("sword_in_stone", () -> new SwordInStoneBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(-1.0f, 3600000.0f).noLootTable()
                    .sound(SoundType.STONE).pushReaction(PushReaction.BLOCK).noOcclusion()));

    public static final RegistryObject<Item> EXCALIBUR = ITEMS.register("excalibur", ExcaliburItem::new);
    public static final RegistryObject<Item> CROWN = ITEMS.register("crown_of_vortigern", CrownItem::new);
    public static final RegistryObject<Item> SWORD_IN_STONE_ITEM = ITEMS.register("sword_in_stone",
            () -> new BlockItem(SWORD_IN_STONE.get(), new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> MERLIN_EGG = ITEMS.register("merlin_spawn_egg",
            () -> new ForgeSpawnEggItem(MERLIN, 0x2E3F8F, 0xC9C9D9, new Item.Properties()));
    public static final RegistryObject<Item> VORTIGERN_EGG = ITEMS.register("vortigern_spawn_egg",
            () -> new ForgeSpawnEggItem(VORTIGERN, 0x3A1D1D, 0xC9A227, new Item.Properties()));

    static void register(IEventBus bus) {
        ENTITIES.register(bus); BLOCKS.register(bus); ITEMS.register(bus);
        bus.addListener(LoreContent::attributes);
        bus.addListener(LoreContent::tabs);
    }

    private static void attributes(EntityAttributeCreationEvent e) {
        e.put(MERLIN.get(), Merlin.createAttributes().build());
        e.put(VORTIGERN.get(), Vortigern.createAttributes().build());
    }

    private static void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.COMBAT) { e.accept(EXCALIBUR); e.accept(CROWN); }
        else if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) { e.accept(MERLIN_EGG); e.accept(VORTIGERN_EGG); }
        else if (e.getTabKey() == CreativeModeTabs.OP_BLOCKS) { e.accept(SWORD_IN_STONE_ITEM); }
    }
}
