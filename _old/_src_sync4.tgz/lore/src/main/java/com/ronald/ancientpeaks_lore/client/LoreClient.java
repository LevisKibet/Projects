package com.ronald.ancientpeaks_lore.client;

import com.ronald.ancientpeaks_lore.LoreContent;
import com.ronald.ancientpeaks_lore.Merlin;
import com.ronald.ancientpeaks_lore.Vortigern;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Client only: how Merlin and Vortigern are drawn. */
public final class LoreClient {
    private LoreClient() {}

    public static void init(IEventBus bus) {
        bus.addListener(LoreClient::renderers);
        bus.addListener((RegisterClientReloadListenersEvent e) -> e.registerReloadListener((ResourceManagerReloadListener) rm -> ClientRes.forget()));
    }

    private static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(LoreContent.MERLIN.get(), ctx -> {
            GeoEntityRenderer<Merlin> r = new GeoEntityRenderer<>(ctx, new CharacterModel<>("merlin", "minecraft:textures/entity/illager/illusioner.png"));
            r.withScale(0.9375f);
            return r;
        });
        e.registerEntityRenderer(LoreContent.VORTIGERN.get(), ctx -> {
            GeoEntityRenderer<Vortigern> r = new GeoEntityRenderer<>(ctx, new CharacterModel<>("vortigern", "minecraft:textures/entity/illager/vindicator.png"));
            r.withScale(1.35f);
            return r;
        });
    }
}
