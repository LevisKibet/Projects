package com.ronald.rivergence.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.ronald.rivergence.Rivergence;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

import java.util.List;

/**
 * What a passing shower looks like from anywhere round about: a dark, heavy cloud over it (blocky, like Minecraft's
 * own clouds, only lower and greyer), grey veils of rain hanging from it to the ground, and - with the sun low
 * behind you and the shower ahead - a rainbow.
 */
@Mod.EventBusSubscriber(modid = Rivergence.MODID, value = Dist.CLIENT)
public final class RainClouds {
    private RainClouds() {}

    private static final int CELL = 8;

    private static double hash(long a, long b, long c) {
        long h = a * 0x9E3779B97F4A7C15L ^ b * 0xC2B2AE3D27D4EB4FL ^ c * 0x165667B19E3779F9L;
        h ^= h >>> 33; h *= 0xff51afd7ed558ccdL; h ^= h >>> 33;
        return (h >>> 11) * 0x1.0p-53;
    }

    /** Whether the shower's cloud has a puff over cell (i, j), and how thick it is there (0 = none). */
    private static int puff(WaterWeather.Shower s, int i, int j) {
        float cx = i * CELL + CELL / 2f, cz = j * CELL + CELL / 2f;
        float d = (float) Math.hypot(cx - s.x, cz - s.z) / (s.radius * 1.15f);
        double n = hash(Math.floorDiv(i, 2), Math.floorDiv(j, 2), s.seed) * 0.6 + hash(i, j, s.seed + 1) * 0.4;
        if (d + (n - 0.5) * 0.45 > 1) return 0;
        return 4 + (int) ((1 - d) * 5 + n * 3);
    }

    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        List<WaterWeather.Shower> showers = WaterWeather.seen;
        if (showers.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        if (e.getStage() == RenderLevelStageEvent.Stage.AFTER_SKY) { rainbow(e, level, showers); return; }
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Vec3 cam = e.getCamera().getPosition();
        Matrix4f mat = e.getPoseStack().last().pose();
        float pt = e.getPartialTick();
        // the light of the day (and its colour) on the cloud, as on vanilla's clouds
        Vec3 cc = level.getCloudColor(pt);
        float lr = (float) cc.x, lg = (float) cc.y, lb = (float) cc.z;
        float drift = 0;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder b = Tesselator.getInstance().getBuilder();
        b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        for (WaterWeather.Shower s : showers) {
            float base = s.cloudY();
            double dist = Math.hypot(s.x - cam.x, s.z - cam.z);
            float fade = s.strength * Mth.clamp((float) (1 - (dist - 320) / 120), 0, 1);
            if (fade < 0.02f) continue;
            float a = 0.88f * fade;
            int i0 = Mth.floor((s.x - s.radius * 1.4f) / CELL), i1 = Mth.floor((s.x + s.radius * 1.4f) / CELL);
            int j0 = Mth.floor((s.z - s.radius * 1.4f) / CELL), j1 = Mth.floor((s.z + s.radius * 1.4f) / CELL);
            for (int i = i0; i <= i1; i++) for (int j = j0; j <= j1; j++) {
                int t = puff(s, i, j);
                if (t == 0) continue;
                float x0 = (float) (i * CELL + drift - cam.x), x1 = x0 + CELL;
                float z0 = (float) (j * CELL - cam.z), z1 = z0 + CELL;
                float y0 = (float) (base - t * 0.35f - cam.y), y1 = (float) (base + t - cam.y);
                // dark underneath, lighter on top, as a rain cloud is
                quad(b, mat, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0, lr * 0.62f, lg * 0.63f, lb * 0.66f, a);
                quad(b, mat, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, lr * 0.30f, lg * 0.31f, lb * 0.34f, a);
                if (puff(s, i - 1, j) < t) quad(b, mat, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, lr * 0.45f, lg * 0.46f, lb * 0.5f, a);
                if (puff(s, i + 1, j) < t) quad(b, mat, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1, lr * 0.42f, lg * 0.43f, lb * 0.47f, a);
                if (puff(s, i, j - 1) < t) quad(b, mat, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0, lr * 0.48f, lg * 0.49f, lb * 0.53f, a);
                if (puff(s, i, j + 1) < t) quad(b, mat, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, lr * 0.4f, lg * 0.41f, lb * 0.45f, a);
            }
            // veils of rain hanging from it, seen from outside (inside, the drops themselves do it)
            float inside = (float) (dist / s.radius);
            float veil = 0.2f * fade * Mth.clamp((inside - 0.5f) * 1.5f, 0, 1);
            if (veil > 0.01f) {
                for (int k = 0; k < 9; k++) {
                    double ang = hash(k, 3, s.seed) * Math.PI * 2, rr = Math.sqrt(hash(k, 5, s.seed)) * s.radius * 0.75;
                    float vx = (float) (s.x + Math.cos(ang) * rr - cam.x), vz = (float) (s.z + Math.sin(ang) * rr - cam.z);
                    float w = 14 + (float) hash(k, 7, s.seed) * 14;
                    // a veil turned to face the camera
                    float fx = -vz, fz = vx, fl = (float) Math.sqrt(fx * fx + fz * fz);
                    if (fl < 1e-3f) continue;
                    fx = fx / fl * w / 2; fz = fz / fl * w / 2;
                    float top = (float) (base - 2 - cam.y), bot = (float) (s.ground - 2 - cam.y);
                    float g = 0.55f;
                    b.vertex(mat, vx - fx, top, vz - fz).color(lr * g, lg * g, lb * g * 1.05f, veil).endVertex();
                    b.vertex(mat, vx - fx, bot, vz - fz).color(lr * g, lg * g, lb * g * 1.05f, veil * 0.35f).endVertex();
                    b.vertex(mat, vx + fx, bot, vz + fz).color(lr * g, lg * g, lb * g * 1.05f, veil * 0.35f).endVertex();
                    b.vertex(mat, vx + fx, top, vz + fz).color(lr * g, lg * g, lb * g * 1.05f, veil).endVertex();
                }
            }
        }
        Tesselator.getInstance().end();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void quad(BufferBuilder b, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float r, float g, float bl, float a) {
        b.vertex(m, x0, y0, z0).color(r, g, bl, a).endVertex();
        b.vertex(m, x1, y1, z1).color(r, g, bl, a).endVertex();
        b.vertex(m, x2, y2, z2).color(r, g, bl, a).endVertex();
        b.vertex(m, x3, y3, z3).color(r, g, bl, a).endVertex();
    }

    /**
     * A rainbow: with the sun low behind you (under 42° up) and a shower ahead of you in the antisolar direction,
     * an arc of colour 42° round the point opposite the sun. Brightest as the shower passes off (toward its end).
     */
    private static void rainbow(RenderLevelStageEvent e, ClientLevel level, List<WaterWeather.Shower> showers) {
        float pt = e.getPartialTick();
        float ang = level.getSunAngle(pt);
        float sx = -Mth.sin(ang), sy = Mth.cos(ang);                         // the sun's direction (it moves in x/y)
        if (sy < 0.04f || sy > 0.62f) return;                                 // low sun, but up
        Vec3 cam = e.getCamera().getPosition();
        float vis = 0;
        for (WaterWeather.Shower s : showers) {
            double dx = s.x - cam.x, dz = s.z - cam.z, d = Math.hypot(dx, dz);
            if (d < s.radius * 0.6 || d > s.radius * 3.2) continue;            // not from deep inside it, not from too far
            double toward = -dx / d * Math.signum(sx);                         // the shower lies away from the sun
            if (toward < 0.25) continue;
            float late = Mth.clamp((s.phase - 0.45f) / 0.25f, 0, 1);
            vis = Math.max(vis, s.strength * late * (float) Math.min(1, (toward - 0.25) * 2));
        }
        vis *= 1 - level.getRainLevel(pt);
        if (vis < 0.02f) return;
        // round the antisolar point A, 42° out; drawn far off on the sky, behind everything
        float ax = -sx, ay = -sy;
        // two directions square to A: across (z) and "up" in A's plane
        float ux = -ay, uy = ax;
        if (uy < 0) { ux = -ux; uy = -uy; }
        Matrix4f mat = e.getPoseStack().last().pose();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder b = Tesselator.getInstance().getBuilder();
        b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        float[][] bands = {{0.55f, 0.2f, 0.75f}, {0.25f, 0.3f, 0.9f}, {0.2f, 0.7f, 0.9f}, {0.3f, 0.85f, 0.3f}, {0.95f, 0.9f, 0.25f}, {0.95f, 0.55f, 0.15f}, {0.9f, 0.2f, 0.15f}};
        float R = 200, a = 0.32f * vis;
        int steps = 96;
        for (int k = 0; k < bands.length; k++) {
            float r0 = (float) Math.toRadians(39.5 + k * 0.62), r1 = (float) Math.toRadians(39.5 + (k + 1) * 0.62);
            float[] c = bands[k];
            float edge = k == 0 || k == bands.length - 1 ? 0.55f : 1f;
            for (int i = 0; i < steps; i++) {
                double p0 = Math.PI * 2 * i / steps, p1 = Math.PI * 2 * (i + 1) / steps;
                float[] v00 = ring(ax, ay, ux, uy, r0, p0), v10 = ring(ax, ay, ux, uy, r0, p1), v11 = ring(ax, ay, ux, uy, r1, p1), v01 = ring(ax, ay, ux, uy, r1, p0);
                if (v00[1] < -0.08f && v10[1] < -0.08f) continue;               // below the horizon
                float al = a * edge;
                b.vertex(mat, v00[0] * R, v00[1] * R, v00[2] * R).color(c[0], c[1], c[2], al).endVertex();
                b.vertex(mat, v10[0] * R, v10[1] * R, v10[2] * R).color(c[0], c[1], c[2], al).endVertex();
                b.vertex(mat, v11[0] * R, v11[1] * R, v11[2] * R).color(c[0], c[1], c[2], al).endVertex();
                b.vertex(mat, v01[0] * R, v01[1] * R, v01[2] * R).color(c[0], c[1], c[2], al).endVertex();
            }
        }
        Tesselator.getInstance().end();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    /** A point on the circle radius rad round A, at angle p (U is in A's vertical plane, z across it). */
    private static float[] ring(float ax, float ay, float ux, float uy, float rad, double p) {
        float c = Mth.cos(rad), s = Mth.sin(rad);
        float cp = (float) Math.cos(p), sp = (float) Math.sin(p);
        return new float[]{ax * c + ux * s * cp, ay * c + uy * s * cp, s * sp};
    }
}
