package com.ronald.rivergence.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.ronald.rivergence.Rivergence;
import com.ronald.rivergence.RivergenceConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * More life in the sea, drawn only on this screen like the schools of fish: drifting clusters of glowing jellyfish over
 * coral reefs; and, very rarely in the deep cold seas, two sightings - a great dark shape far off in the gloom that
 * lifts its head to look at you before turning and sliding away into the deep, and a big tuna that tears past you.
 */
@Mod.EventBusSubscriber(modid = Rivergence.MODID, value = Dist.CLIENT)
public final class SeaLife {
    private SeaLife() {}

    private static final ResourceLocation TEX = new ResourceLocation(Rivergence.MODID, "textures/misc/fish.png");
    private static final Random RND = new Random();
    /** For testing: sightings on demand. */
    static boolean forceSerpent, forceTuna;

    // ------------------------------------------------------------------ jellyfish

    static final class Jelly {
        float x, y, z, px, py, pz, vx, vy, vz;
        float size, phase, rate;
        int r, g, b, cr, cg, cb;
        int strands;
    }

    static final class Bloom {
        double cx, cz;
        int floorY, topY;
        float alpha, palpha;
        boolean leaving;
        Jelly[] jellies;
    }

    private static final List<Bloom> blooms = new ArrayList<>();

    // ------------------------------------------------------------------ the deep: a sea serpent's shadow, a tuna

    static final class Serpent {
        final List<float[]> path = new ArrayList<>();     // head first, half a block apart
        float hx, hy, hz, yaw, pitch, speed;
        int age;
        float alpha, palpha, eyes;
    }

    static final class Tuna {
        float x, y, z, px, py, pz, dx, dy, dz, speed;
        int age, life;
        float alpha, palpha;
    }

    private static Serpent serpent;
    private static Tuna tuna;
    private static long serpentRest, tunaRest;
    private static ClientLevel lastLevel;
    private static int clock;

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        Player p = mc.player;
        if (level != lastLevel) { blooms.clear(); serpent = null; tuna = null; lastLevel = level; }
        if (level == null || p == null || mc.isPaused()) return;
        if (!RivergenceConfig.schools()) { blooms.clear(); serpent = null; tuna = null; return; }
        clock++;
        if (clock % 40 == 7) tryBloom(level, p);
        for (int i = blooms.size() - 1; i >= 0; i--) {
            Bloom b = blooms.get(i);
            updateBloom(p, b);
            if (b.leaving && b.alpha <= 0) blooms.remove(i);
        }
        boolean deepCold = clock % 20 == 0 && deepCold(level, p);
        if (serpent == null && (forceSerpent || deepCold && clock > serpentRest && clock % 200 == 0 && RND.nextInt(45) == 0)) {
            forceSerpent = false;
            spawnSerpent(level, p);
        }
        if (tuna == null && (forceTuna || deepCold && clock > tunaRest && clock % 100 == 0 && RND.nextInt(30) == 0)) {
            forceTuna = false;
            spawnTuna(p);
        }
        if (serpent != null && updateSerpent(p)) { serpent = null; serpentRest = clock + 20 * 60 * 15; }
        if (tuna != null && updateTuna()) { tuna = null; tunaRest = clock + 20 * 60 * 6; }
    }

    /** Swimming in a cold or frozen sea with deep water under you. */
    private static boolean deepCold(ClientLevel level, Player p) {
        if (!p.isEyeInFluid(FluidTags.WATER)) return false;
        BlockPos at = p.blockPosition();
        String id = level.getBiome(at).unwrapKey().map(k -> k.location().getPath()).orElse("");
        if (!(id.contains("frozen") || id.contains("cold")) || !id.contains("ocean")) return false;
        int d = 0;
        BlockPos.MutableBlockPos m = at.mutable();
        while (d < 40 && level.getFluidState(m.move(0, -1, 0)).is(FluidTags.WATER)) d++;
        return d >= 10 || id.contains("deep");
    }

    // ---- jellyfish over reefs

    private static void tryBloom(ClientLevel level, Player p) {
        if (blooms.size() >= 2) return;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int attempt = 0; attempt < 3; attempt++) {
            double a = RND.nextDouble() * Math.PI * 2, d = 18 + RND.nextDouble() * 30;
            int x = Mth.floor(p.getX() + Math.cos(a) * d), z = Mth.floor(p.getZ() + Math.sin(a) * d);
            int top = Integer.MIN_VALUE;
            for (int y = Mth.floor(p.getY()) + 20; y >= Mth.floor(p.getY()) - 30; y--)
                if (level.getFluidState(m.set(x, y, z)).is(FluidTags.WATER)) { if (level.getFluidState(m.set(x, y + 1, z)).isEmpty()) top = y; break; }
            if (top == Integer.MIN_VALUE) continue;
            int floor = top;
            while (floor > top - 30 && level.getFluidState(m.set(x, floor - 1, z)).is(FluidTags.WATER)) floor--;
            if (top - floor < 5) continue;
            // a reef: coral on the bed round about
            int coral = 0;
            for (int dx = -4; dx <= 4; dx += 2) for (int dz = -4; dz <= 4; dz += 2) for (int dy = -1; dy <= 2; dy++) {
                var st = level.getBlockState(m.set(x + dx, floor + dy, z + dz));
                if (st.is(BlockTags.CORALS) || st.is(BlockTags.CORAL_BLOCKS) || st.is(BlockTags.WALL_CORALS)) coral++;
            }
            if (coral < 3) continue;
            boolean near = false;
            for (Bloom o : blooms) if (Math.hypot(o.cx - x, o.cz - z) < 20) near = true;
            if (near) continue;
            blooms.add(makeBloom(x, z, floor, top));
            return;
        }
    }

    static Bloom makeBloom(int x, int z, int floor, int top) {
        Bloom b = new Bloom();
        b.cx = x + 0.5; b.cz = z + 0.5; b.floorY = floor; b.topY = top;
        // amber and orange with a glowing rim, or pink and magenta
        boolean amber = RND.nextBoolean();
        int n = 6 + RND.nextInt(13);
        b.jellies = new Jelly[n];
        for (int i = 0; i < n; i++) {
            Jelly j = new Jelly();
            double a = RND.nextDouble() * Math.PI * 2, r = Math.sqrt(RND.nextDouble()) * 6;
            j.x = j.px = (float) (b.cx + Math.cos(a) * r);
            j.z = j.pz = (float) (b.cz + Math.sin(a) * r);
            j.y = j.py = floor + 2 + RND.nextFloat() * Math.max(0.5f, top - floor - 3.5f);
            float big = RND.nextFloat();
            j.size = 0.35f + big * big * 0.9f;
            j.phase = RND.nextFloat() * 6.283f;
            j.rate = 0.07f + RND.nextFloat() * 0.04f;
            j.strands = 5 + RND.nextInt(4);
            if (amber) { j.r = 230; j.g = 120 + RND.nextInt(40); j.b = 70; j.cr = 255; j.cg = 175; j.cb = 70; }
            else { j.r = 235; j.g = 120 + RND.nextInt(30); j.b = 200; j.cr = 255; j.cg = 190; j.cb = 230; }
            b.jellies[i] = j;
        }
        return b;
    }

    private static void updateBloom(Player p, Bloom b) {
        b.palpha = b.alpha;
        if (Math.hypot(b.cx - p.getX(), b.cz - p.getZ()) > 80) b.leaving = true;
        b.alpha = Mth.clamp(b.alpha + (b.leaving ? -0.04f : 0.02f), 0, 1);
        for (Jelly j : b.jellies) {
            j.px = j.x; j.py = j.y; j.pz = j.z;
            j.phase += j.rate;
            // each beat of the bell lifts it a little; between beats it sinks slowly
            float beat = Math.max(0, Mth.sin(j.phase));
            j.vy = j.vy * 0.9f + beat * 0.006f - 0.0022f;
            j.vx = j.vx * 0.96f + (RND.nextFloat() - 0.5f) * 0.002f;
            j.vz = j.vz * 0.96f + (RND.nextFloat() - 0.5f) * 0.002f;
            // drifting gently aside from a swimmer
            double qx = j.x - p.getX(), qy = j.y - p.getEyeY(), qz = j.z - p.getZ(), qd = Math.sqrt(qx * qx + qy * qy + qz * qz);
            if (qd < 2.5 && qd > 1e-3) { j.vx += qx / qd * 0.004f; j.vy += qy / qd * 0.003f; j.vz += qz / qd * 0.004f; }
            // kept loosely together over the reef
            j.vx += (float) (b.cx - j.x) * 0.00015f; j.vz += (float) (b.cz - j.z) * 0.00015f;
            j.x += j.vx; j.z += j.vz;
            j.y = Mth.clamp(j.y + j.vy, b.floorY + 1.5f, b.topY - 0.3f - j.size * 0.5f);
        }
    }

    // ---- the serpent's shadow

    private static void spawnSerpent(ClientLevel level, Player p) {
        Serpent s = new Serpent();
        float look = p.getYRot() * Mth.DEG_TO_RAD;
        // ahead of you, out at the edge of what you can see in the gloom
        float a = look + (RND.nextFloat() - 0.5f) * 1.0f;
        float d = devDist > 0 ? devDist : 24 + RND.nextFloat() * 8;
        s.hx = (float) (p.getX() - Mth.sin(a) * d);
        s.hz = (float) (p.getZ() + Mth.cos(a) * d);
        s.hy = (float) (devDist > 0 ? p.getEyeY() + 1.5 : p.getEyeY() - 1 - RND.nextFloat() * 3);
        // its head toward you; its body lying back away in a slow S, sinking into the dark below
        s.yaw = (float) Math.atan2(p.getZ() - s.hz, p.getX() - s.hx);
        float bx = -Mth.cos(s.yaw), bz = -Mth.sin(s.yaw);
        float side = RND.nextBoolean() ? 1 : -1;
        float x = s.hx, y = s.hy, z = s.hz;
        for (int i = 0; i < 70; i++) {
            s.path.add(new float[]{x, y, z});
            float curve = Mth.sin(i * 0.11f) * 0.9f * side;
            float dx = bx * Mth.cos(curve) - bz * Mth.sin(curve), dz = bz * Mth.cos(curve) + bx * Mth.sin(curve);
            x += dx * 0.7f; z += dz * 0.7f;
            y -= i < 6 ? -0.12f : 0.12f;                     // the neck raised, the rest falling away beneath
        }
        s.speed = 0;
        serpent = s;
    }

    /** True when it's gone. */
    private static boolean updateSerpent(Player p) {
        Serpent s = serpent;
        s.age++;
        s.palpha = s.alpha;
        int stare = 120;
        if (s.age < stare) {
            // watching you: the head follows you, swaying a little
            float want = (float) Math.atan2(p.getZ() - s.hz, p.getX() - s.hx);
            s.yaw += Mth.clamp(Mth.wrapDegrees((want - s.yaw) * Mth.RAD_TO_DEG) * Mth.DEG_TO_RAD, -0.03f, 0.03f);
            s.alpha = Math.min(1, s.alpha + 0.02f);
            s.eyes = Math.min(1, s.eyes + 0.03f);
            s.path.get(0)[1] = s.hy + Mth.sin(s.age * 0.05f) * 0.15f;
        } else {
            // then it turns away and slides down into the deep, the body following the way the head went
            float away = (float) Math.atan2(s.hz - p.getZ(), s.hx - p.getX());
            s.yaw += Mth.clamp(Mth.wrapDegrees((away - s.yaw) * Mth.RAD_TO_DEG) * Mth.DEG_TO_RAD, -0.06f, 0.06f);
            s.pitch = Math.max(-0.6f, s.pitch - 0.01f);
            s.speed = Math.min(0.32f, s.speed + 0.01f);
            s.eyes = Math.max(0, s.eyes - 0.05f);
            s.hx += Mth.cos(s.yaw) * Mth.cos(s.pitch) * s.speed;
            s.hz += Mth.sin(s.yaw) * Mth.cos(s.pitch) * s.speed;
            s.hy += Mth.sin(s.pitch) * s.speed;
            float[] last = s.path.get(0);
            float mx = s.hx - last[0], my = s.hy - last[1], mz = s.hz - last[2];
            if (mx * mx + my * my + mz * mz >= 0.49f) { s.path.add(0, new float[]{s.hx, s.hy, s.hz}); s.path.remove(s.path.size() - 1); }
            if (s.age > stare + 160) s.alpha -= 0.015f;
        }
        return s.alpha <= 0 && s.age > stare;
    }

    // ---- the tuna

    private static void spawnTuna(Player p) {
        Tuna t = new Tuna();
        Vec3 look = p.getLookAngle();
        double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
        if (ll < 1e-3) { lx = 1; lz = 0; ll = 1; }
        lx /= ll; lz /= ll;
        double sx = -lz, sz = lx, dir = RND.nextBoolean() ? 1 : -1;
        double ahead = 4 + RND.nextDouble() * 4;
        t.x = t.px = (float) (p.getX() + lx * ahead - sx * dir * 32);
        t.z = t.pz = (float) (p.getZ() + lz * ahead - sz * dir * 32);
        t.y = t.py = (float) (p.getEyeY() - 0.5 + RND.nextDouble());
        t.dx = (float) (sx * dir); t.dz = (float) (sz * dir); t.dy = 0;
        t.speed = 1.3f + RND.nextFloat() * 0.4f;
        t.life = (int) (64 / t.speed) + 4;
        tuna = t;
    }

    private static boolean updateTuna() {
        Tuna t = tuna;
        t.age++;
        t.px = t.x; t.py = t.y; t.pz = t.z; t.palpha = t.alpha;
        t.x += t.dx * t.speed; t.z += t.dz * t.speed;
        t.y += Mth.sin(t.age * 0.3f) * 0.03f;
        t.alpha = t.age < 6 ? t.age / 6f : t.age > t.life - 6 ? Math.max(0, (t.life - t.age) / 6f) : 1;
        return t.age >= t.life;
    }

    // ------------------------------------------------------------------ drawing

    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_CUTOUT_BLOCKS) return;
        if (blooms.isEmpty() && serpent == null && tuna == null) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        Vec3 cam = e.getCamera().getPosition();
        Matrix4f mat = e.getPoseStack().last().pose();
        RenderSystem.setShader(GameRenderer::getParticleShader);
        RenderSystem.setShaderTexture(0, TEX);
        mc.gameRenderer.lightTexture().turnOnLightLayer();
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        BufferBuilder bb = Tesselator.getInstance().getBuilder();

        // solid bodies first (they hide what's behind them)
        if (serpent != null || tuna != null) {
            RenderSystem.depthMask(true);
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
            if (serpent != null) drawSerpent(bb, mat, cam, pt, level);
            if (tuna != null) drawTuna(bb, mat, cam, pt, level);
            BufferUploader.drawWithShader(bb.end());
        }
        // the jellyfish: see-through and glowing, so drawn without hiding one another
        if (!blooms.isEmpty()) {
            RenderSystem.depthMask(false);
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
            int n = 0;
            for (Bloom b : blooms) {
                float a = Mth.lerp(pt, b.palpha, b.alpha);
                if (a <= 0.01f) continue;
                for (Jelly j : b.jellies) { drawJelly(bb, mat, cam, pt, j, a); n++; }
            }
            if (n > 0) BufferUploader.drawWithShader(bb.end()); else bb.end().release();
            RenderSystem.depthMask(true);
        }
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        mc.gameRenderer.lightTexture().turnOffLightLayer();
    }

    private static final float SU0 = 0.02f, SU1 = 0.1f, SV0 = 0.52f, SV1 = 0.98f;   // the plain white patch of the texture
    private static final int GLOW = 0xF000F0;

    private static void quad(BufferBuilder bb, Matrix4f m, float[] a, float[] b, float[] c, float[] d, int r, int g, int bl, int al, int light) {
        FishSchools.v(bb, m, a[0], a[1], a[2], SU0, SV0, r, g, bl, al, light);
        FishSchools.v(bb, m, b[0], b[1], b[2], SU1, SV0, r, g, bl, al, light);
        FishSchools.v(bb, m, c[0], c[1], c[2], SU1, SV1, r, g, bl, al, light);
        FishSchools.v(bb, m, d[0], d[1], d[2], SU0, SV1, r, g, bl, al, light);
    }

    private static void drawJelly(BufferBuilder bb, Matrix4f m, Vec3 cam, float pt, Jelly j, float fade) {
        float x = (float) (Mth.lerp(pt, j.px, j.x) - cam.x), y = (float) (Mth.lerp(pt, j.py, j.y) - cam.y), z = (float) (Mth.lerp(pt, j.pz, j.z) - cam.z);
        if (x * x + y * y + z * z > 64 * 64) return;
        float ph = j.phase + j.rate * pt;
        float pulse = Math.max(0, Mth.sin(ph));
        float R = j.size * 0.5f * (1 - 0.14f * pulse), H = j.size * 0.42f * (1 + 0.1f * pulse);
        final int AR = 9, RINGS = 4;
        float[][][] ring = new float[RINGS + 1][AR][];
        for (int k = 0; k <= RINGS; k++) {
            float phi = k / (float) RINGS * 1.75f;                       // to just past the side: a bell, its rim turned in
            float rr = R * Mth.sin(phi) * (k == RINGS ? 0.93f : 1), hh = H * Mth.cos(phi);
            for (int i = 0; i < AR; i++) {
                float th = i / (float) AR * Mth.TWO_PI;
                ring[k][i] = new float[]{x + Mth.cos(th) * rr, y + hh, z + Mth.sin(th) * rr};
            }
        }
        int A = (int) (fade * 150);
        for (int k = 0; k < RINGS; k++) for (int i = 0; i < AR; i++) {
            int i2 = (i + 1) % AR;
            float glow = k >= RINGS - 1 ? 1 : 0.75f + k * 0.08f;           // brightest at the rim
            int r = (int) (k >= RINGS - 1 ? j.cr : j.r * glow), g = (int) (k >= RINGS - 1 ? j.cg : j.g * glow), b = (int) (k >= RINGS - 1 ? j.cb : j.b * glow);
            quad(bb, m, ring[k][i], ring[k][i2], ring[k + 1][i2], ring[k + 1][i], r, g, b, k >= RINGS - 1 ? Math.min(255, A + 60) : A, GLOW);
        }
        // a glowing heart in the bell
        float cy = y + H * 0.25f, cr = R * 0.35f;
        float[] c0 = {x - cr, cy, z}, c1 = {x, cy + cr, z}, c2 = {x + cr, cy, z}, c3 = {x, cy - cr, z};
        float[] d0 = {x, cy, z - cr}, d2 = {x, cy, z + cr};
        quad(bb, m, c0, c1, c2, c3, j.cr, j.cg, j.cb, (int) (fade * 120), GLOW);
        quad(bb, m, d0, c1, d2, c3, j.cr, j.cg, j.cb, (int) (fade * 120), GLOW);
        // trailing threads and frilly arms, swaying behind the beat
        float len = j.size * 2.6f;
        for (int s = 0; s < j.strands + 3; s++) {
            boolean arm = s >= j.strands;
            float th = (s + 0.5f) / (arm ? 3f : j.strands) * Mth.TWO_PI + (arm ? 0.6f : 0);
            float sr = arm ? R * 0.2f : R * 0.85f;
            float sx = x + Mth.cos(th) * sr, sz = z + Mth.sin(th) * sr, sy = y + H * Mth.cos(1.75f) + 0.02f;
            float l = arm ? len * 0.55f : len * (0.8f + 0.3f * Mth.sin(s * 2.1f));
            float w = arm ? j.size * 0.09f : j.size * 0.018f + 0.008f;
            int segs = 6;
            float px0 = sx, py0 = sy, pz0 = sz;
            for (int k = 1; k <= segs; k++) {
                float t = k / (float) segs;
                float sway = Mth.sin(ph * 0.9f - t * 3f + s) * 0.12f * j.size * t;
                float px1 = sx + Mth.cos(th + 1.57f) * sway * 2, pz1 = sz + Mth.sin(th + 1.57f) * sway * 2, py1 = sy - l * t * (1 - 0.15f * pulse);
                // a ribbon turned to face you
                float vx = (px0 + px1) / 2, vy = (py0 + py1) / 2, vz = (pz0 + pz1) / 2;
                float dx = px1 - px0, dy = py1 - py0, dz = pz1 - pz0;
                float ox = dy * vz - dz * vy, oy = dz * vx - dx * vz, oz = dx * vy - dy * vx;
                float ol = Mth.sqrt(ox * ox + oy * oy + oz * oz);
                if (ol < 1e-5f) continue;
                float ww = w * (1 - t * 0.6f) / ol;
                ox *= ww; oy *= ww; oz *= ww;
                int al = (int) (fade * (arm ? 110 : 140) * (1 - t * 0.75f));
                int r = arm ? j.cr : j.r, g = arm ? j.cg : j.g, b = arm ? j.cb : j.b;
                quad(bb, m, new float[]{px0 - ox, py0 - oy, pz0 - oz}, new float[]{px0 + ox, py0 + oy, pz0 + oz},
                        new float[]{px1 + ox, py1 + oy, pz1 + oz}, new float[]{px1 - ox, py1 - oy, pz1 - oz}, r, g, b, al, GLOW);
                px0 = px1; py0 = py1; pz0 = pz1;
            }
        }
    }

    /**
     * A body along a spine (camera-relative points, head first): a four-sided section, wider than tall, the back in
     * one colour and the belly in another.
     */
    private static void tube(BufferBuilder bb, Matrix4f m, float[][] p, float[] w, float[] h, int[] back, int[] belly, int A, int light) {
        int n = p.length;
        float[][][] ring = new float[n][4][];
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - 1), b = Math.min(n - 1, i + 1);
            float tx = p[a][0] - p[b][0], ty = p[a][1] - p[b][1], tz = p[a][2] - p[b][2];
            float sx = -tz, sz = tx, sl = Mth.sqrt(sx * sx + sz * sz);
            if (sl < 1e-5f) { sx = 1; sz = 0; sl = 1; }
            sx /= sl; sz /= sl;
            // up: square to the spine and the side
            float ux = -sz * ty, uy = sz * tx - sx * tz, uz = sx * ty;
            float ul = Mth.sqrt(ux * ux + uy * uy + uz * uz);
            if (ul < 1e-5f) { ux = 0; uy = 1; uz = 0; ul = 1; }
            ux /= ul; uy /= ul; uz /= ul;
            if (uy < 0) { ux = -ux; uy = -uy; uz = -uz; }
            float[] c = p[i];
            ring[i][0] = new float[]{c[0] + sx * w[i], c[1], c[2] + sz * w[i]};
            ring[i][1] = new float[]{c[0] + ux * h[i], c[1] + uy * h[i], c[2] + uz * h[i]};
            ring[i][2] = new float[]{c[0] - sx * w[i], c[1], c[2] - sz * w[i]};
            ring[i][3] = new float[]{c[0] - ux * h[i] * 0.85f, c[1] - uy * h[i] * 0.85f, c[2] - uz * h[i] * 0.85f};
        }
        for (int i = 0; i + 1 < n; i++) for (int q = 0; q < 4; q++) {
            int q2 = (q + 1) % 4;
            int[] c = q < 2 ? back : belly;
            float sh = q == 0 || q == 3 ? 0.85f : 1;
            quad(bb, m, ring[i][q], ring[i + 1][q], ring[i + 1][q2], ring[i][q2], (int) (c[0] * sh), (int) (c[1] * sh), (int) (c[2] * sh), A, light);
        }
    }

    private static void drawSerpent(BufferBuilder bb, Matrix4f m, Vec3 cam, float pt, ClientLevel level) {
        Serpent s = serpent;
        float a = Mth.lerp(pt, s.palpha, s.alpha);
        if (a <= 0.01f) return;
        int n = Math.min(s.path.size(), 70);
        float[][] p = new float[n][];
        float[] w = new float[n], h = new float[n];
        float t = s.age + pt;
        for (int i = 0; i < n; i++) {
            float[] q = s.path.get(i);
            float u = i / (float) (n - 1);
            // a slow ripple travelling down the body
            float rip = Mth.sin(t * 0.08f - i * 0.25f) * 0.25f * u;
            p[i] = new float[]{(float) (q[0] - cam.x) + rip * Mth.sin(s.yaw), (float) (q[1] - cam.y), (float) (q[2] - cam.z) - rip * Mth.cos(s.yaw)};
            // a heavy head, a narrower neck, the thick of the body, then a long taper to the tail
            float prof = u < 0.04f ? 0.75f + u / 0.04f * 0.25f : u < 0.1f ? 1 - (u - 0.04f) / 0.06f * 0.25f : u < 0.35f ? 0.75f + (u - 0.1f) / 0.25f * 0.45f : 1.2f * (1 - (u - 0.35f) / 0.65f) + 0.05f;
            w[i] = 1.0f * prof; h[i] = 0.8f * prof;
        }
        int light = LevelRenderer.getLightColor(level, BlockPos.containing(s.hx, s.hy, s.hz));
        int A = (int) (a * 235);
        tube(bb, m, p, w, h, new int[]{14, 20, 28}, new int[]{26, 32, 40}, A, light);
        // the eyes: two pale points, only while it's looking at you
        if (s.eyes > 0.02f && n > 2) {
            float[] hd = p[0], nk = p[2];
            float dx = hd[0] - nk[0], dz = hd[2] - nk[2], dl = Mth.sqrt(dx * dx + dz * dz);
            if (dl > 1e-4f) {
                dx /= dl; dz /= dl;
                float sx = -dz, sz = dx;
                for (int side = -1; side <= 1; side += 2) {
                    float ex = hd[0] + dx * 0.35f + sx * side * 0.6f, ey = hd[1] + 0.3f, ez = hd[2] + dz * 0.35f + sz * side * 0.6f;
                    float e = 0.12f;
                    int al = (int) (a * s.eyes * 220);
                    quad(bb, m, new float[]{ex - e, ey - e, ez}, new float[]{ex + e, ey - e, ez}, new float[]{ex + e, ey + e, ez}, new float[]{ex - e, ey + e, ez}, 190, 215, 170, al, GLOW);
                    quad(bb, m, new float[]{ex, ey - e, ez - e}, new float[]{ex, ey - e, ez + e}, new float[]{ex, ey + e, ez + e}, new float[]{ex, ey + e, ez - e}, 190, 215, 170, al, GLOW);
                }
            }
        }
    }

    private static void drawTuna(BufferBuilder bb, Matrix4f m, Vec3 cam, float pt, ClientLevel level) {
        Tuna t = tuna;
        float a = Mth.lerp(pt, t.palpha, t.alpha);
        if (a <= 0.01f) return;
        float x = (float) (Mth.lerp(pt, t.px, t.x) - cam.x), y = (float) (Mth.lerp(pt, t.py, t.y) - cam.y), z = (float) (Mth.lerp(pt, t.pz, t.z) - cam.z);
        final int N = 10;
        float L = 2.4f;
        float sx = -t.dz, sz = t.dx;
        float[][] p = new float[N + 1][];
        float[] w = new float[N + 1], h = new float[N + 1];
        float time = t.age + pt;
        for (int i = 0; i <= N; i++) {
            float u = i / (float) N;
            float wig = Mth.sin(time * 1.6f - u * 3) * 0.12f * u * u;
            p[i] = new float[]{x + t.dx * (L * 0.5f - u * L) + sx * wig, y, z + t.dz * (L * 0.5f - u * L) + sz * wig};
            // a torpedo: blunt nose, deepest a third back, a thin wrist before the tail
            float prof = u < 0.3f ? 0.45f + 0.55f * Mth.sqrt(u / 0.3f) : 1 - (u - 0.3f) / 0.7f * 0.92f;
            w[i] = 0.3f * prof; h[i] = 0.38f * prof;
        }
        int light = LevelRenderer.getLightColor(level, BlockPos.containing(t.x, t.y, t.z));
        int A = (int) (a * 255);
        tube(bb, m, p, w, h, new int[]{28, 44, 86}, new int[]{205, 212, 222}, A, light);
        // the sickle tail: two swept lobes
        float[] tw = p[N];
        float bx = -t.dx, bz = -t.dz;
        float sw = Mth.sin(time * 1.6f - 3) * 0.15f;
        float[] tip1 = {tw[0] + bx * 0.45f + sx * sw, tw[1] + 0.55f, tw[2] + bz * 0.45f + sz * sw};
        float[] tip2 = {tw[0] + bx * 0.45f + sx * sw, tw[1] - 0.55f, tw[2] + bz * 0.45f + sz * sw};
        float[] mid = {tw[0] + bx * 0.22f + sx * sw * 0.5f, tw[1], tw[2] + bz * 0.22f + sz * sw * 0.5f};
        quad(bb, m, tw, tip1, mid, tw, 40, 55, 95, A, light);
        quad(bb, m, tw, mid, tip2, tw, 40, 55, 95, A, light);
        // a dorsal fin and yellow finlets toward the tail
        float[] d0 = p[3], d1 = p[5];
        quad(bb, m, new float[]{d0[0], d0[1] + h[3], d0[2]}, new float[]{d0[0], d0[1] + h[3] + 0.22f, d0[2]},
                new float[]{d1[0], d1[1] + h[5] + 0.08f, d1[2]}, new float[]{d1[0], d1[1] + h[5], d1[2]}, 32, 48, 90, A, light);
        for (int i = 6; i <= 8; i++) {
            float[] f = p[i];
            quad(bb, m, new float[]{f[0], f[1] + h[i], f[2]}, new float[]{f[0], f[1] + h[i] + 0.09f, f[2]},
                    new float[]{f[0] + bx * 0.08f, f[1] + h[i] + 0.05f, f[2] + bz * 0.08f}, new float[]{f[0] + bx * 0.08f, f[1] + h[i], f[2] + bz * 0.08f}, 240, 210, 40, A, light);
            quad(bb, m, new float[]{f[0], f[1] - h[i] * 0.85f, f[2]}, new float[]{f[0], f[1] - h[i] * 0.85f - 0.09f, f[2]},
                    new float[]{f[0] + bx * 0.08f, f[1] - h[i] * 0.85f - 0.05f, f[2] + bz * 0.08f}, new float[]{f[0] + bx * 0.08f, f[1] - h[i] * 0.85f, f[2] + bz * 0.08f}, 240, 210, 40, A, light);
        }
    }

    // ------------------------------------------------------------------ testing

    public static void devBloom(int x, int z, int floor, int top) { Bloom b = makeBloom(x, z, floor, top); b.alpha = b.palpha = 1; blooms.add(b); }
    public static String devInfo() {
        return "blooms " + blooms.size() + (serpent == null ? " no serpent" : String.format(" serpent %.1f,%.1f,%.1f a%.2f age%d path%d", serpent.hx, serpent.hy, serpent.hz, serpent.alpha, serpent.age, serpent.path.size()))
                + (tuna == null ? " no tuna" : String.format(" tuna %.1f,%.1f,%.1f", tuna.x, tuna.y, tuna.z));
    }
    public static float devDist = 0;
    public static void devSerpent(float d) { devDist = d; forceSerpent = true; }
    public static void devTuna() { forceTuna = true; }
}
