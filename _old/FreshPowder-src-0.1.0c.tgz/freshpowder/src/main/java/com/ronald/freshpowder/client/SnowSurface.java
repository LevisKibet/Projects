package com.ronald.freshpowder.client;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The smooth snow surface: each column's depth, softened with its neighbours', then blended across the block with an
 * eased curve. Every block works its corners out from the same absolute columns, so neighbours always meet.
 */
public final class SnowSurface {
    private SnowSurface() {}

    public static final int G = 4;
    /** Never quite down to the ground: the ground's top face under snow isn't drawn, so the snow must cover it. */
    private static final float MIN = 0.004f;

    /** A column's snow surface, relative to the base of the block row: NaN where a wall or such stands. */
    private static float raw(BlockAndTintGetter level, BlockPos.MutableBlockPos m, BlockPos pos, int dx, int dz) {
        BlockState s = level.getBlockState(m.setWithOffset(pos, dx, 0, dz));
        if (s.is(Blocks.SNOW)) return s.getValue(SnowLayerBlock.LAYERS) / 8f;
        if (s.is(Blocks.SNOW_BLOCK) || s.is(Blocks.POWDER_SNOW)) return 1f;
        if (s.isAir() || s.canBeReplaced()) {
            BlockState b = level.getBlockState(m.setWithOffset(pos, dx, -1, dz));
            if (b.is(Blocks.SNOW)) return (b.getValue(SnowLayerBlock.LAYERS) - 8) / 8f;   // a step down
            return 0f;                                                                      // bare ground or a drop
        }
        return Float.NaN;
    }

    private static float ease(float t) { return t * t * (3 - 2 * t); }

    /** The heights of the (G+1)² points across the top of the snow at pos. */
    public static float[] grid(BlockAndTintGetter level, BlockPos pos, int layers) {
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        float[] r = new float[25];                                              // 5×5 columns round this one
        for (int dz = -2; dz <= 2; dz++) for (int dx = -2; dx <= 2; dx++)
            r[(dz + 2) * 5 + dx + 2] = dx == 0 && dz == 0 ? layers / 8f : raw(level, m, pos, dx, dz);
        float[] c = new float[9];                                               // the middle 3×3, softened
        for (int dz = -1; dz <= 1; dz++) for (int dx = -1; dx <= 1; dx++) {
            float self = r[(dz + 2) * 5 + dx + 2];
            if (Float.isNaN(self)) { c[(dz + 1) * 3 + dx + 1] = Float.NaN; continue; }
            float sum = 0, w = 0;
            for (int bz = -1; bz <= 1; bz++) for (int bx = -1; bx <= 1; bx++) {
                float v = r[(dz + bz + 2) * 5 + dx + bx + 2];
                if (Float.isNaN(v)) continue;
                float wt = (bx == 0 ? 2 : 1) * (bz == 0 ? 2 : 1);
                sum += wt * v; w += wt;
            }
            c[(dz + 1) * 3 + dx + 1] = sum / w;
        }
        float[] h = new float[(G + 1) * (G + 1)];
        for (int j = 0; j <= G; j++) for (int i = 0; i <= G; i++) {
            float px = (float) i / G - 0.5f, pz = (float) j / G - 0.5f;
            int ix = px < 0 ? -1 : 0, iz = pz < 0 ? -1 : 0;
            float tx = ease(px - ix), tz = ease(pz - iz);
            float sum = 0, w = 0;
            for (int b = 0; b <= 1; b++) for (int a = 0; a <= 1; a++) {
                float v = c[(iz + b + 1) * 3 + ix + a + 1];
                if (Float.isNaN(v)) continue;
                float wt = (a == 0 ? 1 - tx : tx) * (b == 0 ? 1 - tz : tz);
                sum += wt * v; w += wt;
            }
            float v = w > 1e-4f ? sum / w : c[4];
            h[j * (G + 1) + i] = Math.max(MIN, Math.min(1f, v));
        }
        return h;
    }

    /** The surface height at a point (block-relative fx, fz in 0..1) over the snow at pos. */
    public static float heightAt(BlockAndTintGetter level, BlockPos pos, int layers, float fx, float fz) {
        float[] h = grid(level, pos, layers);
        float gx = Math.max(0, Math.min(G - 1e-4f, fx * G)), gz = Math.max(0, Math.min(G - 1e-4f, fz * G));
        int i = (int) gx, j = (int) gz;
        float tx = gx - i, tz = gz - j;
        int W = G + 1;
        float a = h[j * W + i] + (h[j * W + i + 1] - h[j * W + i]) * tx;
        float b = h[(j + 1) * W + i] + (h[(j + 1) * W + i + 1] - h[(j + 1) * W + i]) * tx;
        return a + (b - a) * tz;
    }
}
