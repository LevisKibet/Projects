package com.ronald.freshpowder;

import net.minecraftforge.common.ForgeConfigSpec;

public final class Config {
    public static final ForgeConfigSpec COMMON_SPEC, CLIENT_SPEC;
    public static final ForgeConfigSpec.BooleanValue DRIFTS, TREE_SNOW, SNOWFALL, TRAILS, MOB_TRAILS;
    public static final ForgeConfigSpec.IntValue MAX_DEPTH;
    public static final ForgeConfigSpec.BooleanValue FOOTPRINTS;
    public static final ForgeConfigSpec.IntValue MAX_FOOTPRINTS, FOOTPRINT_SECONDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("snow");
        DRIFTS = b.comment("Deeper snow in cold biomes, piled up against walls and in hollows.").define("drifts", true);
        MAX_DEPTH = b.comment("The deepest a drift gets, in snow layers (8 would be a full block).").defineInRange("max_depth", 4, 1, 7);
        TREE_SNOW = b.comment("Snow settles on the lower boughs of trees and under them, not only on top.").define("tree_snow", true);
        SNOWFALL = b.comment("Snowfall builds the drifts back up over time (and fills in old trails).").define("snowfall_builds_drifts", true);
        TRAILS = b.comment("Walking through snow presses it down, leaving a trail.").define("trails", true);
        MOB_TRAILS = b.comment("Animals and mobs leave trails too, not only players.").define("mob_trails", true);
        b.pop();
        COMMON_SPEC = b.build();

        ForgeConfigSpec.Builder c = new ForgeConfigSpec.Builder();
        c.push("footprints");
        FOOTPRINTS = c.comment("Footprints and paw prints in the snow.").define("footprints", true);
        MAX_FOOTPRINTS = c.comment("How many prints are kept at once. Lower is cheaper.").defineInRange("max_footprints", 600, 50, 3000);
        FOOTPRINT_SECONDS = c.comment("How long a print lasts, in seconds.").defineInRange("footprint_seconds", 90, 10, 1200);
        c.pop();
        CLIENT_SPEC = c.build();
    }

    private Config() {}
}
