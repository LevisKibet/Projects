ANCIENT PEAKS LORE - CHARACTERS
===============================

Each character has a folder here. The game reads it while you test (F3+T reloads it):

  characters/merlin/merlin.geo.json          the model     (Blockbench > GeckoLib Animated Model > export)
  characters/merlin/merlin.animation.json    the animations
  characters/merlin/merlin.png               the texture   (until it exists, the vanilla illusioner skin is used)

  characters/vortigern/vortigern.geo.json
  characters/vortigern/vortigern.animation.json
  characters/vortigern/vortigern.png         (until it exists, the vanilla vindicator skin is used)

The .geo.json and .animation.json here now are STAND-INS (a plain illager body with every animation roughed in),
so everything works before your own models are done. Overwrite them with your Blockbench exports.

Item art goes in   items/   next to   characters/ :
  items/excalibur.png             16x16 item icon (held like a sword)
  items/crown_of_vortigern.png    16x16 item icon
  items/crown_layer_1.png         the crown as worn (64x32 armour layout, helmet area only)

Files starting with "_" are ignored, so you can keep old versions as _merlin_old.geo.json.


TOOLS
-----
Blockbench (free) with the "GeckoLib Animation Utils" plugin (File > Plugins). New project type:
"GeckoLib Animated Model". Keep the model about 2 blocks tall (32 px) for Merlin, Vortigern a bit bigger
(he is drawn at 1.35x anyway). One texture per character, 64x64 or 128x128.


BONES  (names matter: the game turns "head" to look at players; "root" should hold everything)
-----
  root                 at the feet (0,0,0); every other bone inside it
    body
      head             turned by the game to look at you
      right_arm  /  left_arm
        staff          Merlin: held in the right hand
        sword          Vortigern: held in the right hand
      crown            Vortigern: on the head (put it under head)
    right_leg / left_leg
Add as many extra bones as you like (beard, cape, robe, fingers); just keep these names.


ANIMATIONS  (exact names; the game asks for them by name. Lengths are what the stand-ins use.)
----------
MERLIN
  idle            loop                standing, leaning on the staff
  walk            loop
  injured_lying   loop                on the chapel floor, wounded (lying on his back, breathing)
  heal_getup      once, ~2.5 s        getting up after you heal him
  talk            once, ~1.5 s        a gesture; played for each line he speaks
  cast            once, ~2 s          drives the raiders off (they vanish at 0.0 s of this)
  point           once, ~1.5 s        when he gives you his compass
  vanish          once, hold last     (not used yet)

VORTIGERN  (the "hits at" times are when the game deals the damage: make the blow land there,
            or tell me your times and I will move them)
  idle            loop
  walk            loop
  run             loop                when chasing from far away
  intro           once, 3 s           rising out of the ground at the summit (he can't be hurt meanwhile)
  attack_1        once, 0.9 s         first swing of his combo      - hits at 0.40 s
  attack_2        once, 1.0 s         second swing                  - hits at 0.50 s
  slam            once, 1.5 s         both fists into the ground    - lands at 0.80 s (knocks everyone back)
  spell           once, 1.25 s        fangs out of the ground       - cast at 0.60 s   (from half health)
  summon          once, 1.5 s         calls 3 Saxon warriors        - they appear at 1.00 s (from half health)
  stagger         once, 1.0 s         knocked off balance by heavy hits
  phase_change    once, 2.0 s         roar at half health (he can't be hurt meanwhile)
  death           once, hold last     3 s before he disappears and drops the crown


EPIC FIGHT
----------
With Epic Fight installed, Excalibur fights as an Epic Fight longsword and the crown has Epic Fight armour stats.
Merlin and Vortigern stay GeckoLib characters (Epic Fight can still fight them). Making them full Epic Fight
characters needs Epic Fight's own armature models, made in Blender with Epic Fight's exporter - a later step.
