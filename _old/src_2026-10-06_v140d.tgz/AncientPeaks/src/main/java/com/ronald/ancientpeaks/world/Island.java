package com.ronald.ancientpeaks.world;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * One Ancient Highlands island (pure Java, previewable outside the game).
 *
 * Shape: a long, bending strip built around a curved spine (s = 0..1 along it, e = 0 on the spine, 1 at the coast).
 * The low end (s ~ 0) holds the megalake grove and landing beach; forested hills rise toward the main massif and a
 * secondary peak with glacier caps. A meadow shelf sits partway up the main massif's flank, a sea strait cuts across
 * the island, rivers start at mountain tarns, and a great arch springs from the hillside into the lake.
 */
public final class Island {
    public static final double SHELF = 170, SEA = 63, LEAN = 0.13;

    public final int cx, cz;
    final double cos, sin;
    final Perlin[] n = new Perlin[14];
    public final double boundR;

    // spine
    final double[] spU, spV, spL; final double spLen;
    final double w0, wa1, wp1, wa2, wp2;
    // elevation along the spine
    final double peakS, peakH, peak2S, peak2H, hillS, hillH, marshEnd;
    // meadow shelf
    final double shU, shV, shR;
    private boolean shelfReady = false;
    private double shSide;
    // sea strait
    Path strait;
    // rivers and tarns
    final List<Path> rivers = new ArrayList<>();
    final List<double[]> tarns = new ArrayList<>();           // u, v, radius, level, kind(0 fall, 1 neck), outU, outV
    // great arch: low end (in the lake), high end (on the hillside)
    double aLoU, aLoV, aLoH, aHiU, aHiV, aHiH, aRise;
    // sea stacks (u, v, radius, height)
    final List<double[]> stacks = new ArrayList<>();
    // landing beach
    double landU, landV;

    /** A river, stream or strait: dense polyline with a water level per point. */
    static final class Path {
        final double[] u, v, l, level; final double len;
        final double width0, width1, depth0, depth1, bankSlope; final boolean gorge;
        final double[] bridges;
        Path(double[][] uv, double[] level, double width0, double width1, double depth0, double depth1, double bankSlope, boolean gorge, double[] bridges) {
            this.u = uv[0]; this.v = uv[1]; this.level = level; this.l = new double[u.length];
            double acc = 0; l[0] = 0;
            for (int i = 1; i < u.length; i++) { acc += Math.hypot(u[i] - u[i - 1], v[i] - v[i - 1]); l[i] = acc; }
            this.len = Math.max(acc, 1);
            this.width0 = width0; this.width1 = width1; this.depth0 = depth0; this.depth1 = depth1;
            this.bankSlope = bankSlope; this.gorge = gorge; this.bridges = bridges;
            double a = 1e18, b = -1e18, c = 1e18, d = -1e18;
            for (int i = 0; i < u.length; i++) { a = Math.min(a, u[i]); b = Math.max(b, u[i]); c = Math.min(c, v[i]); d = Math.max(d, v[i]); }
            minU = a; maxU = b; minV = c; maxV = d;
        }
        final double minU, maxU, minV, maxV;
        /** Streams only: flow gathered at each point, and the half-width and depth it gives. */
        double[] flow, wid, dep;
        /** Quick test: could (u, v) be within `reach` of this path? */
        boolean near(double u, double v, double reach) {
            return u > minU - reach && u < maxU + reach && v > minV - reach && v < maxV + reach;
        }
    }

    /** Cached per-column base terrain terms (everything except the per-block lean and carving). */
    static final class Base {
        double rough, warp, s, e, side, wBlocks, hs, coastH, rug, step, hw, marshW, marshH, shelfM, shelfH, shelfD, seabed, coastK, tarnLift;
    }

    public Island(int cx, int cz, long seed) {
        this.cx = cx; this.cz = cz;
        Random r = new Random(seed);
        double rot = r.nextDouble() * Math.PI * 2;
        cos = Math.cos(rot); sin = Math.sin(rot);
        for (int i = 0; i < n.length; i++) n[i] = new Perlin(r.nextLong());

        // --- spine: a bending strip 1000-1350 blocks long
        double length = 1000 + r.nextDouble() * 350;
        int k = 5;
        double[] cu = new double[k], cv = new double[k];
        double bend = r.nextGaussian() * 140;
        for (int i = 0; i < k; i++) {
            double t = i / (double) (k - 1);
            cu[i] = (t - 0.5) * length;
            cv[i] = bend * Math.sin(Math.PI * t) + r.nextGaussian() * 45;
        }
        double[][] sp = spline(cu, cv, 16);
        spU = sp[0]; spV = sp[1]; spL = new double[spU.length];
        double acc = 0;
        for (int i = 1; i < spU.length; i++) { acc += Math.hypot(spU[i] - spU[i - 1], spV[i] - spV[i - 1]); spL[i] = acc; }
        spLen = acc;
        w0 = 200 + r.nextDouble() * 50; wa1 = 0.22 + r.nextDouble() * 0.1; wp1 = r.nextDouble(); wa2 = 0.12; wp2 = r.nextDouble();

        marshEnd = 0.30 + r.nextDouble() * 0.04;
        hillS = 0.40 + r.nextDouble() * 0.04; hillH = 45 + r.nextDouble() * 30;
        peakS = 0.62 + r.nextDouble() * 0.06; peakH = 172 + r.nextDouble() * 28;
        peak2S = 0.86 + r.nextDouble() * 0.05; peak2H = 120 + r.nextDouble() * 40;

        // --- meadow shelf on the main massif's flank (not the summit)
        shSide = r.nextBoolean() ? 1 : -1;
        double[] shP = pointAt(peakS - 0.07 + r.nextDouble() * 0.04, shSide * (0.42 + r.nextDouble() * 0.08));
        shU = shP[0]; shV = shP[1]; shR = 85 + r.nextDouble() * 25;

        double maxW = 0;
        for (int i = 0; i < spU.length; i++) maxW = Math.max(maxW, Math.hypot(spU[i], spV[i]));
        boundR = maxW + w0 * 1.45 + SHELF;
        this.r = r;
    }

    /** Island streams of our own - off when Streams Reflowing is installed (it brings its own, and they win). */
    public static volatile boolean OWN_STREAMS = true;
    private Random r;
    private volatile boolean complete;

    /**
     * The costly part (strait, shelf, tarns, streams, arch, stacks, landing), done once the island's spot is chosen:
     * the placement search tries many spots and only needs the outline (spine, width, bounds) to judge them.
     */
    public synchronized Island complete() {
        if (complete) return this;
        Random r = this.r;
        double shSide = this.shSide;
        // --- sea strait across the island between the forest hills and the massif
        double sS = marshEnd + 0.10 + r.nextDouble() * 0.06;
        int m = 6;
        double[] su = new double[m], sv = new double[m];
        for (int i = 0; i < m; i++) {
            double t = i / (double) (m - 1);
            double[] p = pointAt(sS + (r.nextDouble() - 0.5) * 0.025, (t * 2 - 1) * 1.35 * -shSide);
            su[i] = p[0]; sv[i] = p[1];
        }
        double[][] st = spline(su, sv, 10);
        double[] stLev = new double[st[0].length];
        java.util.Arrays.fill(stLev, 40);
        // the strait runs as a sea tunnel through the island; only its last quarter (the shelf side) is open to the sky,
        // where one remnant of the old roof still stands as an arch
        strait = new Path(st, stLev, 11, 11, 0, 0, 6, true, new double[]{0.73 + r.nextDouble() * 0.03});

        // the shelf level: a little below the local massif height
        Base b = new Base();
        baseAt(shU, shV, b, false);
        double hHere = heightAt(b, b.e);
        shLevelHolder = Math.max(120, Math.min(hHere - 25, 175));
        shelfReady = true;

        // --- tarns, and the streams that run out of them (buildStreams).
        // Two kinds: WATERFALL tarns sit on a cliff lip, in a bowl whose rim has a single one-block notch where the
        // water spills over; NECK tarns sit on gentler ground and drain through a narrow neck channel downhill.
        pickTarns(r, b);
        if (OWN_STREAMS) buildStreams(r, b);

        // --- great arch: springs from the hillside (high end) and lands in the megalake (low end)
        double aSide = r.nextBoolean() ? 1 : -1;
        archSide = aSide;
        double[] hi = pointAt(marshEnd + 0.035, aSide * 0.22);
        double[] lo = pointAt(marshEnd - 0.075, aSide * 0.45);
        aHiU = hi[0]; aHiV = hi[1]; aLoU = lo[0]; aLoV = lo[1];
        baseAt(aHiU, aHiV, b, false); aHiH = heightAt(b, b.e) - 6;
        aLoH = 63;
        aRise = 42 + r.nextDouble() * 16;

        // --- sea stacks off the high coasts
        int count = 5 + r.nextInt(5);
        for (int i = 0; i < count; i++) {
            double s = 0.45 + r.nextDouble() * 0.55;
            double[] p = pointAt(s, (r.nextBoolean() ? 1 : -1) * (1.08 + r.nextDouble() * 0.12));
            stacks.add(new double[]{p[0], p[1], 6 + r.nextDouble() * 8, 90 + r.nextDouble() * 70});
        }
        double[] land = pointAt(0.0, 0);
        double[] land2 = pointAt(0.03, 0);
        double dx = land[0] - land2[0], dy = land[1] - land2[1], dl = Math.hypot(dx, dy);
        landU = land[0] + dx / dl * w0 * 0.35; landV = land[1] + dy / dl * w0 * 0.35;
        complete = true;
        return this;
    }

    private double shLevelHolder;
    private double archSide = 1;
    public double shelfLevel() { return shLevelHolder; }

    // ------------------------------------------------------------------ geometry helpers
    /** World-local point at spine position s with signed cross offset (in units of local half-width). */
    double[] pointAt(double s, double crossE) {
        s = Math.max(0, Math.min(1, s));
        double target = s * spLen;
        int i = 1;
        while (i < spL.length - 1 && spL[i] < target) i++;
        double t = (target - spL[i - 1]) / Math.max(spL[i] - spL[i - 1], 1e-6);
        double u = spU[i - 1] + (spU[i] - spU[i - 1]) * t, v = spV[i - 1] + (spV[i] - spV[i - 1]) * t;
        double tu = spU[i] - spU[i - 1], tv = spV[i] - spV[i - 1], tl = Math.hypot(tu, tv);
        double nu = -tv / tl, nv = tu / tl;
        double w = width(s);
        return new double[]{u + nu * crossE * w, v + nv * crossE * w};
    }

    double width(double s) {
        double taper = 0.35 + 0.65 * Math.sqrt(smooth(0, 0.10, s) * smooth(1, 0.90, s));
        return w0 * (1 + wa1 * Math.sin(2 * Math.PI * (s * 1.3 + wp1)) + wa2 * Math.sin(2 * Math.PI * (s * 3.1 + wp2))) * taper;
    }

    static double smooth(double a, double b, double x) {
        double t = Math.max(0, Math.min(1, (x - a) / (b - a)));
        return t * t * (3 - 2 * t);
    }
    static double terrace(double h, double step, double sharp) {
        double t = h / step, fl = Math.floor(t), fr = t - fl;
        return (fl + smooth(sharp, 1.0, fr)) * step;
    }
    static double gauss(double s, double c, double w) { double d = (s - c) / w; return Math.exp(-d * d); }
    double fbm(Perlin p, double x, double z, int oct) {
        double s = 0, a = 1, f = 1, norm = 0;
        for (int i = 0; i < oct; i++) { s += a * p.get(x * f + i * 17.3, z * f - i * 9.1); norm += a; a *= 0.5; f *= 2; }
        return s / norm;
    }
    double ridged(Perlin p, double x, double z, int oct) {
        double s = 0, a = 1, f = 1, norm = 0;
        for (int i = 0; i < oct; i++) { double q = 1 - Math.abs(p.get(x * f + i * 31.7, z * f + i * 11.3)); s += a * q * q; norm += a; a *= 0.5; f *= 2.1; }
        return s / norm;
    }

    /** Closest spine point: fills s, signed side and distance. */
    void spineCoords(double u, double v, double[] out) {
        double best = Double.MAX_VALUE, bs = 0, side = 1;
        for (int i = 0; i < spU.length - 1; i++) {
            double ax = spU[i], ay = spV[i], dx = spU[i + 1] - ax, dy = spV[i + 1] - ay;
            double l2 = dx * dx + dy * dy;
            double t = l2 == 0 ? 0 : Math.max(0, Math.min(1, ((u - ax) * dx + (v - ay) * dy) / l2));
            double qx = u - (ax + t * dx), qy = v - (ay + t * dy);
            double d = qx * qx + qy * qy;
            if (d < best) { best = d; bs = spL[i] + t * Math.sqrt(l2); side = Math.signum(dx * qy - dy * qx); }
        }
        out[0] = bs / spLen; out[1] = Math.sqrt(best); out[2] = side == 0 ? 1 : side;
    }

    // ------------------------------------------------------------------ base terrain
    void baseAt(double u, double v, Base b, boolean withTarns) {
        double[] sc = new double[3];
        spineCoords(u, v, sc);
        double s = sc[0];
        b.s = s; b.side = sc[2];
        b.wBlocks = width(s);
        double e = sc[1] / b.wBlocks;
        e *= 1 + 0.09 * n[0].get(u / 170, v / 170) + 0.035 * n[1].get(u / 45, v / 45);
        b.e = e;
        b.hs = 72 + hillH * gauss(s, hillS, 0.12) + peakH * gauss(s, peakS, 0.19) + peak2H * gauss(s, peak2S, 0.12);
        b.coastH = Math.max(63, Math.min(175, 63 + (b.hs - 72) * 0.5));
        double hi = Math.max(0, Math.min(1, (b.hs - 100) / 160));
        b.hw = hi;
        b.rug = (b.hs - 72) / 230 * (26 * ridged(n[2], u / 120, v / 120, 4) - 9) + 5 * n[3].get(u / 55, v / 55);
        b.step = 22 * (1 + 0.3 * n[4].get(u / 170, v / 170));
        // break up smooth, uniform slopes: mid-scale lumps, small knolls and rocky crags
        double wild = (1 - smooth(0.85, 1.0, e));
        b.rough = wild * (5.5 * fbm(n[3], u / 38 + 11, v / 38, 3) + 2.2 * n[4].get(u / 11, v / 11)
                + 14 * Math.pow(Math.max(0, ridged(n[1], u / 70 + 5, v / 70, 2) - 0.72) / 0.28, 2));
        b.warp = 9 * n[8].get(u / 55 + 3, v / 55);
        double sw = s + 0.06 * n[10].get(u / 140 + 7, v / 140);
        b.marshW = 1 - smooth(marshEnd - 0.08, marshEnd + 0.04, sw);
        // lowland plains (for the village and castle): broad, gently rolling ground a little above the sea
        b.marshH = 67.5 + 3.2 * fbm(n[5], u / 110, v / 110, 3) + 1.4 * n[6].get(u / 34, v / 34);
        // meadow shelf (with noisy rim)
        double pd = Math.hypot(u - shU, v - shV), pa = Math.atan2(v - shV, u - shU);
        double rr = shR * (1 + 0.28 * n[7].get(Math.cos(pa) * 2.3, Math.sin(pa) * 2.3) + 0.08 * n[8].get(Math.cos(pa) * 7, Math.sin(pa) * 7));
        b.shelfD = pd / rr;
        b.shelfM = shelfReady ? 1 - smooth(0.93, 1.0, b.shelfD) : 0;
        b.shelfH = shLevelHolder + 3 * fbm(n[8], u / 60, v / 60, 2);
        b.seabed = 34 + 8 * n[9].get(u / 90, v / 90);
        b.coastK = 0.14 + (0.016 - 0.14) * smooth(68, 100, b.coastH);
        // tarn dams: raise a rim around each tarn so the water is held in
        b.tarnLift = -1e9;
        if (withTarns) for (double[] t : tarns) {
            double d = Math.hypot(u - t[0], v - t[1]);
            if (d < t[2] + 14) b.tarnLift = Math.max(b.tarnLift, t[3] + 2 - Math.max(0, d - t[2]) * 0.5);
        }
    }

    /** Terrain height for a column at an (optionally leaned) coast-distance e. */
    double heightAt(Base b, double e) {
        double t = smooth(0, 1, e);
        double h = b.coastH + (b.hs - b.coastH) * (1 - Math.pow(t, 1.5)) + b.rug * (1 - t * 0.6) + b.rough;
        // cliff bands low down; the upper mountain rises in gentler, broken slopes instead of sheer walls
        double tw = 0.72 * b.hw * (1 - 0.8 * smooth(165, 225, h));
        h = h + (terrace(h + b.warp, b.step, 0.8) - b.warp - h) * tw;
        h = h + (b.marshH - h) * b.marshW;
        // the meadow shelf: flat within, the mountain keeps rising gently behind it on the uphill side
        double sm = h > b.shelfH ? b.shelfM * (1 - smooth(0.55, 1.0, b.shelfD)) : b.shelfM;
        h = h + (b.shelfH - h) * sm;
        h = Math.max(h, b.tarnLift);
        double coast = smooth(1, 1 + b.coastK, e);
        return h + (b.seabed - h) * coast;
    }

    /** Real terrain surface (with the cliff lean the density applies), ignoring small jitter. */
    double surfaceAt(double u, double v, Base b) {
        baseAt(u, v, b, false);
        for (int y = 318; y > 40; y--) {
            double lean = LEAN * Math.max(0, Math.min(y, 175) - 66) * (0.35 + 0.65 * b.hw) / b.wBlocks;
            if (heightAt(b, b.e - lean) >= y) return y;
        }
        return 40;
    }

    private void pickTarns(Random r, Base b) {
        double[][] cand = new double[160][];
        int nc = 0;
        for (int i = 0; i < 160; i++) {
            double s = 0.42 + r.nextDouble() * 0.54, side = (r.nextBoolean() ? 1 : -1) * (0.08 + r.nextDouble() * 0.6);
            double[] p = pointAt(s, side);
            baseAt(p[0], p[1], b, false);
            if (b.shelfM > 0.2 || b.marshW > 0.2) continue;
            double h = surfaceAt(p[0], p[1], b);
            if (h < 110) continue;
            // look around: where is the land lowest, and by how much does it drop?
            double lowest = 1e9, dir = 0, ringMax = -1e9;
            for (int k = 0; k < 16; k++) {
                double a = k * Math.PI / 8;
                for (double rad : new double[]{20, 30}) {
                    double hh = surfaceAt(p[0] + Math.cos(a) * rad, p[1] + Math.sin(a) * rad, b);
                    if (rad == 20) ringMax = Math.max(ringMax, hh);
                    if (hh < lowest) { lowest = hh; dir = a; }
                }
            }
            cand[nc++] = new double[]{p[0], p[1], h, h - lowest, dir, ringMax - h};
        }
        // waterfall tarns: the biggest drops next to a still-flattish spot
        java.util.List<double[]> list = new java.util.ArrayList<>(java.util.Arrays.asList(cand).subList(0, nc));
        list.sort((x, y) -> Double.compare(y[3] - 0.8 * Math.max(0, y[5]), x[3] - 0.8 * Math.max(0, x[5])));
        int falls = 0;
        for (double[] c : list) {
            if (falls >= 2 || c[3] < 30) break;
            if (tooClose(c, 120)) continue;
            double rad = 11 + r.nextDouble() * 4;
            tarns.add(new double[]{c[0], c[1], rad, Math.floor(c[2] - 2), 0, Math.cos(c[4]), Math.sin(c[4])});
            falls++;
        }
        // neck tarns: gentle slopes
        list.sort((x, y) -> Double.compare(Math.abs(x[3] - 14), Math.abs(y[3] - 14)));
        int necks = 0;
        for (double[] c : list) {
            if (necks >= 2) break;
            if (c[3] < 6 || c[3] > 26 || tooClose(c, 120)) continue;
            double rad = 13 + r.nextDouble() * 5;
            tarns.add(new double[]{c[0], c[1], rad, Math.floor(c[2] - 2), 1, Math.cos(c[4]), Math.sin(c[4])});
            necks++;
        }
        // give every tarn its own irregular outline (lobes, a kidney bend) and sometimes a little islet
        for (int i = 0; i < tarns.size(); i++) {
            double[] t = tarns.get(i);
            Random q = new Random(Double.doubleToLongBits(t[0]) * 31 + Double.doubleToLongBits(t[1]));
            double a2 = 0.12 + q.nextDouble() * 0.2, a3 = 0.06 + q.nextDouble() * 0.14, a5 = q.nextDouble() * 0.07;
            double[] e = java.util.Arrays.copyOf(t, 14);
            e[7] = a2; e[8] = q.nextDouble() * Math.PI * 2; e[9] = a3; e[10] = q.nextDouble() * Math.PI * 2;
            e[11] = a5; e[12] = q.nextDouble() * Math.PI * 2;
            e[13] = q.nextDouble() < 0.5 ? q.nextDouble() * Math.PI * 2 : Double.NaN;   // islet direction, or none
            tarns.set(i, e);
        }
    }

    /** Outline factor of tarn t at angle a: the shore sits at radius * factor. */
    static double tarnShape(double[] t, double a) {
        return 1 + t[7] * Math.sin(2 * a + t[8]) + t[9] * Math.sin(3 * a + t[10]) + t[11] * Math.sin(5 * a + t[12]);
    }

    private boolean tooClose(double[] c, double d) {
        for (double[] t : tarns) if (Math.hypot(t[0] - c[0], t[1] - c[1]) < d) return true;
        return false;
    }

    // ------------------------------------------------------------------ streams
    //
    // Spring-to-sea streams. Each rises at a spring (a shallow, irregular seep of dotted pools) or runs out of a tarn,
    // and finds its way downhill: the lowest way ahead, drawn into valleys, wandering gently from side to side. It
    // widens as it goes and as tributaries join it, stops to form small ponds where the ground levels out, drops over
    // falls (each with a plunge pool) where the ground drops away, and ends in the sea, the great lake, another
    // stream - or at the edge of the plains, where it goes underground. The shapes live here (pure geometry: the
    // terrain density carves them, IslandSampler.isWater fills them); StreamDecor dresses them block by block.

    /** Where a stream reaches the plains and drops underground (u, v, water level). */
    final List<double[]> sinks = new ArrayList<>();
    /** Springs: u, v, radius, water level, outlet direction (du, dv), noise seed. */
    final List<double[]> springs = new ArrayList<>();
    /** Ponds on the way: u, v, radius, water level, noise seed. */
    final List<double[]> ponds = new ArrayList<>();
    /** Falls: lip u, v, top level, bottom level, direction (du, dv), half-width; pool centre u, v, pool radius. */
    final List<double[]> falls = new ArrayList<>();
    /** How many streams the sampler keeps track of per column. */
    public static final int MAX_STREAMS = 12;
    static boolean DEBUG_STREAMS = Boolean.getBoolean("ancientpeaks.debugStreams");

    private void buildStreams(Random r, Base b) {
        List<double[]> joinsAt = new ArrayList<>();              // per traced stream: {target stream, target point} or null
        // tarn outflows: lake-fed, so they start a little fuller
        for (int i = 0; i < tarns.size() && rivers.size() < MAX_STREAMS; i++) {
            double[] t = tarns.get(i);
            double reach = t[2] * tarnShape(t, Math.atan2(t[6], t[5])) + 3;
            double u = t[0] + t[5] * reach, v = t[1] + t[6] * reach;
            traceStream(u, v, t[3] - 1, r, 4, joinsAt, 6);
        }
        // springs: on hillsides and in hollows, wet ground away from the tarns, the shelf and each other
        List<double[]> cands = new ArrayList<>();
        for (int k = 0; k < 400; k++) {
            double s = 0.40 + r.nextDouble() * 0.56, side = (r.nextBoolean() ? 1 : -1) * (0.08 + r.nextDouble() * 0.62);
            double[] p = pointAt(s, side);
            baseAt(p[0], p[1], b, false);
            if (b.shelfM > 0.05 || b.marshW > 0.05 || b.e > 0.85) continue;
            double h = heightAt(b, b.e);
            if (h < 110 || h > 225) continue;
            // a hollow: lower than the ground around it (water gathers and seeps out there)
            double ring = 0, lowest = 1e9;
            for (int a = 0; a < 8; a++) {
                double ang = a * Math.PI / 4;
                baseAt(p[0] + Math.cos(ang) * 14, p[1] + Math.sin(ang) * 14, b, false);
                double hh = heightAt(b, b.e);
                ring += hh / 8; lowest = Math.min(lowest, hh);
            }
            double hollow = ring - h, wet = n[9].get(p[0] / 70 + 3, p[1] / 70) + 0.35 * hollow / 6;
            if (lowest > h - 1.5) continue;                       // nowhere for it to run off
            cands.add(new double[]{p[0], p[1], h, wet});
        }
        cands.sort((x, y) -> Double.compare(y[3], x[3]));         // wettest first
        for (double[] c : cands) {
            if (rivers.size() >= MAX_STREAMS || springs.size() >= 7) break;
            boolean ok = true;
            for (double[] t : tarns) if (Math.hypot(t[0] - c[0], t[1] - c[1]) < 70) { ok = false; break; }
            for (double[] q : springs) if (Math.hypot(q[0] - c[0], q[1] - c[1]) < 110) { ok = false; break; }
            double[] o = new double[5];
            for (Path p : rivers) { if (!p.near(c[0], c[1], 30)) continue; pathDist(p, c[0], c[1], o); if (o[0] < 30) { ok = false; break; } }
            if (!ok) continue;
            double rad = 2.5 + r.nextDouble() * 2.2;
            // outlet: the lowest way off the spring's rim
            double dir = 0, low = 1e9;
            for (int a = 0; a < 16; a++) {
                double ang = a * Math.PI / 8;
                baseAt(c[0] + Math.cos(ang) * (rad + 4), c[1] + Math.sin(ang) * (rad + 4), b, false);
                double hh = heightAt(b, b.e);
                if (hh < low) { low = hh; dir = ang; }
            }
            double level = Math.floor(Math.min(c[2], low + 2)) - 1;
            double ou = c[0] + Math.cos(dir) * (rad + 1), ov = c[1] + Math.sin(dir) * (rad + 1);
            int before = rivers.size();
            traceStream(ou, ov, level, r, 1, joinsAt, 16);
            if (rivers.size() > before) springs.add(new double[]{c[0], c[1], rad, level, Math.cos(dir), Math.sin(dir), r.nextDouble() * 1000});
        }
        // flow: each stream gathers along its length and takes in its tributaries' flow below where they join
        for (int k = rivers.size() - 1; k >= 0; k--) {
            double[] j = joinsAt.get(k);
            if (j == null) continue;
            Path into = rivers.get((int) j[0]);
            double add = rivers.get(k).flow[rivers.get(k).flow.length - 1];
            for (int i = (int) j[1]; i < into.flow.length; i++) into.flow[i] += add * Math.min(1, (i - j[1] + 1) / 4.0);   // eases in
        }
        for (Path p : rivers) {
            if (p.flow == null) continue;
            p.wid = new double[p.flow.length]; p.dep = new double[p.flow.length];
            for (int i = 0; i < p.flow.length; i++) {
                double f = Math.sqrt(p.flow[i]);
                p.wid[i] = Math.min(4.6, 0.2 + 0.55 * f);           // half-width: a trickle a block wide, a small river five to nine
                p.dep[i] = Math.min(3.0, 0.7 + 0.32 * f);
            }
            findPonds(p);
            findFalls(p);
        }
    }

    /**
     * Follows the land downhill from (u0, v0): the lowest way ahead, drawn into valleys, wandering gently, until it
     * meets the sea or a lake, joins a stream already traced, or comes to the plains.
     */
    private void traceStream(double u0, double v0, double level0, Random r, double flow0, List<double[]> joinsAt, int minPts) {
        List<double[]> pts = new ArrayList<>();
        Base b = new Base();
        double u = u0, v = v0;
        double dir = 0, low = 1e9;
        for (int k = 0; k < 16; k++) {
            double a = k * Math.PI / 8;
            baseAt(u + Math.cos(a) * 12, v + Math.sin(a) * 12, b, false);
            double hh = heightAt(b, b.e) + 250 * b.shelfM;
            if (hh < low) { low = hh; dir = a; }
        }
        double wander = r.nextDouble() * 100;
        boolean sink = false;
        String why = "long";
        double[] sd = new double[5];
        double[] join = null;
        for (int step = 0; step < 700; step++) {
            pts.add(new double[]{u, v});
            baseAt(u, v, b, false);
            double h = heightAt(b, b.e);
            if (h < 63.5) { why = "sea"; break; }
            if (b.e > 0.98) {                                          // the coast, high up: on over the cliff edge
                why = "cliff";
                for (int k = 0; k < 8; k++) {
                    u += Math.cos(dir) * 4; v += Math.sin(dir) * 4;
                    baseAt(u, v, b, false);
                    if (heightAt(b, b.e) < 64) break;
                    pts.add(new double[]{u, v, 1});
                }
                break;
            }
            if (step > 2) { join = joins(u, v); if (join != null) { why = "join"; break; } }
            double best = Double.MAX_VALUE, bestDir = Double.NaN;
            double[] here = new double[5];
            pathDist(strait, u, v, here);
            for (int pass = 0; pass < 2 && Double.isNaN(bestDir); pass++)        // the wide turns only when boxed in
            for (int j = -(pass == 0 ? 6 : 11); j <= (pass == 0 ? 6 : 11); j++) {
                double a = dir + j * 0.3;
                double pu = u + Math.cos(a) * 6, pv = v + Math.sin(a) * 6;
                baseAt(pu, pv, b, false);
                if (b.marshW > 0.2) continue;                                   // never onto the plains: round them, to the sea
                double hc = heightAt(b, b.e);
                if (b.shelfM > 0.02 || b.marshW > 0.05) hc += 250 * b.shelfM + 40 * b.marshW;
                // valleys draw it in: ground rising on both sides of the way ahead
                double nu = -Math.sin(a), nv = Math.cos(a);
                baseAt(pu + nu * 10, pv + nv * 10, b, false); double hl = heightAt(b, b.e);
                baseAt(pu - nu * 10, pv - nv * 10, b, false); double hr = heightAt(b, b.e);
                double valley = Math.max(0, Math.min(12, (hl + hr) / 2 - hc));
                double score = hc - 0.3 * valley + 1.5 * Math.abs(j);
                pathDist(strait, pu, pv, sd);
                if (sd[0] < 45 && sd[1] > IslandSampler.TUNNEL_END - 0.08 && sd[0] <= here[0]) continue;
                if (score < best) { best = score; bestDir = a; }
            }
            if (Double.isNaN(bestDir)) { why = "strait"; break; }
            double swing = 0.35 * Math.sin(step * 0.21 + wander) + 0.22 * n[10].get(u / 45 + wander, v / 45);
            dir = dir + (bestDir - dir) * 0.55 + swing * 0.5;
            u += Math.cos(dir) * 5; v += Math.sin(dir) * 5;
        }
        int nPts = pts.size();
        if (DEBUG_STREAMS) System.out.println("[ancientpeaks] stream " + rivers.size() + " from " + (int) u0 + "," + (int) v0 + " len " + nPts * 5 + " ends: " + why);
        if (nPts < minPts) return;
        double[] pu = new double[nPts], pv = new double[nPts], lev = new double[nPts], flow = new double[nPts];
        double cur = level0, len = 0;
        for (int i = 0; i < nPts; i++) {
            int a = Math.max(0, i - 2), c = Math.min(nPts - 1, i + 2);
            double su = 0, sv = 0;
            for (int j = a; j <= c; j++) { su += pts.get(j)[0]; sv += pts.get(j)[1]; }
            pu[i] = su / (c - a + 1); pv[i] = sv / (c - a + 1);
            if (i > 0) len += Math.hypot(pu[i] - pu[i - 1], pv[i] - pv[i - 1]);
            baseAt(pu[i], pv[i], b, false);
            double ground = heightAt(b, b.e) - 1.2;
            if (pts.get(i).length < 3) cur = Math.min(cur, ground);
            lev[i] = Math.max(Math.floor(cur), 62.5);
            flow[i] = flow0 + len / 45;
        }
        if (join != null) {                                            // meet the other stream at (or above) its own water
            Path into = rivers.get((int) join[0]);
            lev[nPts - 1] = Math.max(lev[nPts - 1], into.level[(int) join[1]]);
            for (int i = nPts - 2; i >= 0; i--) lev[i] = Math.max(lev[i], lev[i + 1]);
        }
        if (sink) sinks.add(new double[]{pu[nPts - 1], pv[nPts - 1], lev[nPts - 1]});
        Path p = new Path(new double[][]{pu, pv}, lev, 1, 1, 1, 1, 0.9, false, new double[0]);
        p.flow = flow;
        joinsAt.add(join);
        rivers.add(p);
    }

    /** {stream index, point index} of a stream already traced within a few blocks, or null. */
    private double[] joins(double u, double v) {
        for (int k = 0; k < rivers.size(); k++) {
            Path p = rivers.get(k);
            if (!p.near(u, v, 6)) continue;
            int bi = -1; double bd = 36;
            for (int i = 0; i < p.u.length; i++) {
                double d = (p.u[i] - u) * (p.u[i] - u) + (p.v[i] - v) * (p.v[i] - v);
                if (d < bd) { bd = d; bi = i; }
            }
            if (bi >= 0) return new double[]{k, bi};
        }
        return null;
    }

    /** Where the stream crosses a level stretch of ground some way from its source, it spreads into a small pond. */
    private void findPonds(Path p) {
        Base b = new Base();
        int n = p.u.length;
        double lastAt = -1e9;
        int made = 0;
        for (int i = 6; i < n - 4 && made < 2; i++) {
            if (p.l[i] < 55 || p.l[i] - lastAt < 70) continue;
            baseAt(p.u[i - 4], p.v[i - 4], b, false); double h0 = heightAt(b, b.e);
            baseAt(p.u[i + 4], p.v[i + 4], b, false); double h1 = heightAt(b, b.e);
            baseAt(p.u[i], p.v[i], b, false); double hc = heightAt(b, b.e);
            if (b.shelfM > 0.05 || b.marshW > 0.05 || b.e > 0.9) continue;
            if (Math.abs(h0 - h1) > 2.0 || hc - p.level[i] > 3) continue;             // not level, or deep in a cut
            boolean clear = true;
            for (double[] t : tarns) if (Math.hypot(t[0] - p.u[i], t[1] - p.v[i]) < t[2] + 25) clear = false;
            if (!clear) continue;
            double rad = 3.5 + p.wid[i] * 1.6 + (p.l[i] % 3);
            // the water downstream of the pond must not stand higher than it
            for (int j = i; j < n; j++) p.level[j] = Math.min(p.level[j], p.level[i]);
            ponds.add(new double[]{p.u[i], p.v[i], rad, p.level[i], p.l[i] * 7.31});
            lastAt = p.l[i];
            made++;
        }
    }

    /** Wherever the water drops three blocks or more between two points, a fall over a lip into a plunge pool. */
    private void findFalls(Path p) {
        for (int i = 1; i < p.u.length; i++) {
            double drop = p.level[i - 1] - p.level[i];
            if (drop < 4) continue;
            double du = p.u[i] - p.u[i - 1], dv = p.v[i] - p.v[i - 1], dl = Math.max(1e-6, Math.hypot(du, dv));
            du /= dl; dv /= dl;
            double lu = (p.u[i] + p.u[i - 1]) / 2, lv = (p.v[i] + p.v[i - 1]) / 2;
            double w = p.wid[i];
            double pr = w + 1.6 + Math.min(2.5, drop * 0.15);
            falls.add(new double[]{lu, lv, p.level[i - 1], p.level[i], du, dv, w, lu + du * (pr * 0.8), lv + dv * (pr * 0.8), pr});
        }
    }

    // world-space views for the decoration pass
    public List<double[]> sinksWorld() { return world(sinks, 0); }
    /** {x, z, radius, level, outlet dx, outlet dz, seed} */
    public List<double[]> springsWorld() { return world(springs, 4); }
    /** {x, z, radius, level, seed} */
    public List<double[]> pondsWorld() { return world(ponds, -1); }
    /** {lip x, lip z, top, bottom, dx, dz, half-width, pool x, pool z, pool radius} */
    public List<double[]> fallsWorld() {
        List<double[]> out = new ArrayList<>();
        for (double[] f : falls) {
            int[] a = toWorld(f[0], f[1]), c = toWorld(f[7], f[8]);
            out.add(new double[]{a[0], a[1], f[2], f[3], f[4] * cos - f[5] * sin, f[4] * sin + f[5] * cos, f[6], c[0], c[1], f[9]});
        }
        return out;
    }
    private List<double[]> world(List<double[]> in, int dirAt) {
        List<double[]> out = new ArrayList<>();
        for (double[] s : in) {
            double[] w = s.clone();
            w[0] = cx + s[0] * cos - s[1] * sin; w[1] = cz + s[0] * sin + s[1] * cos;
            if (dirAt > 0) { w[dirAt] = s[dirAt] * cos - s[dirAt + 1] * sin; w[dirAt + 1] = s[dirAt] * sin + s[dirAt + 1] * cos; }
            out.add(w);
        }
        return out;
    }

    /** Irregular outline factor for a spring or pond (seeded), at angle a. */
    static double blobShape(double seed, double a) {
        return 1 + 0.22 * Math.sin(2 * a + seed) + 0.14 * Math.sin(3 * a + seed * 1.7) + 0.08 * Math.sin(5 * a + seed * 2.3);
    }

    /** Catmull-Rom densification so paths meander smoothly. */
    static double[][] spline(double[] u, double[] v, int sub) {
        int n = u.length, total = (n - 1) * sub + 1;
        double[] ou = new double[total], ov = new double[total];
        for (int i = 0; i < n - 1; i++) {
            int i0 = Math.max(i - 1, 0), i2 = i + 1, i3 = Math.min(i + 2, n - 1);
            for (int s = 0; s < sub; s++) {
                double t = s / (double) sub, t2 = t * t, t3 = t2 * t;
                ou[i * sub + s] = 0.5 * (2 * u[i] + (-u[i0] + u[i2]) * t + (2 * u[i0] - 5 * u[i] + 4 * u[i2] - u[i3]) * t2 + (-u[i0] + 3 * u[i] - 3 * u[i2] + u[i3]) * t3);
                ov[i * sub + s] = 0.5 * (2 * v[i] + (-v[i0] + v[i2]) * t + (2 * v[i0] - 5 * v[i] + 4 * v[i2] - v[i3]) * t2 + (-v[i0] + 3 * v[i] - 3 * v[i2] + v[i3]) * t3);
            }
        }
        ou[total - 1] = u[n - 1]; ov[total - 1] = v[n - 1];
        return new double[][]{ou, ov};
    }

    /** Distance to a path: fills distance, along-path fraction and interpolated water level. */
    static void pathDist(Path p, double u, double v, double[] out) {
        if (p.u.length < 2) {
            out[0] = Math.hypot(u - p.u[0], v - p.v[0]); out[1] = 0; out[2] = p.level[0];
            if (out.length >= 5) { out[3] = p.wid != null ? p.wid[0] : p.width0; out[4] = p.dep != null ? p.dep[0] : p.depth0; }
            return;
        }
        double best = Double.MAX_VALUE; int bi = 0; double bt = 0;
        for (int i = 0; i < p.u.length - 1; i++) {
            double ax = p.u[i], ay = p.v[i], dx = p.u[i + 1] - ax, dy = p.v[i + 1] - ay;
            double l2 = dx * dx + dy * dy;
            double t = l2 == 0 ? 0 : Math.max(0, Math.min(1, ((u - ax) * dx + (v - ay) * dy) / l2));
            double qx = ax + t * dx - u, qy = ay + t * dy - v;
            double d = qx * qx + qy * qy;
            if (d < best) { best = d; bi = i; bt = t; }
        }
        out[0] = Math.sqrt(best);
        out[1] = (p.l[bi] + bt * (p.l[bi + 1] - p.l[bi])) / p.len;
        if (p.wid != null) {
            // a stream's water stands level along each stretch and steps down halfway to the next: riffles and falls
            out[2] = bt < 0.5 ? p.level[bi] : p.level[bi + 1];
            if (out.length >= 5) { out[3] = p.wid[bi] + bt * (p.wid[bi + 1] - p.wid[bi]); out[4] = p.dep[bi] + bt * (p.dep[bi + 1] - p.dep[bi]); }
        } else {
            out[2] = p.level[bi] + bt * (p.level[bi + 1] - p.level[bi]);
            if (out.length >= 5) { out[3] = p.width0 + (p.width1 - p.width0) * out[1]; out[4] = p.depth0 + (p.depth1 - p.depth0) * out[1]; }
        }
    }

    /** Tarn in world space: centre x, z and its outflow direction snapped to a block axis (dx, dz). */
    private double[][] tarnW;
    double[] tarnWorld(int i) {
        if (tarnW == null) {
            double[][] a = new double[tarns.size()][];
            for (int k = 0; k < a.length; k++) {
                double[] t = tarns.get(k);
                double wx = cx + t[0] * cos - t[1] * sin, wz = cz + t[0] * sin + t[1] * cos;
                double dx = t[5] * cos - t[6] * sin, dz = t[5] * sin + t[6] * cos;
                double sx = 0, sz = 0;
                if (Math.abs(dx) > Math.abs(dz)) sx = Math.signum(dx); else sz = Math.signum(dz);
                a[k] = new double[]{wx, wz, sx, sz};
            }
            tarnW = a;
        }
        return tarnW[i];
    }

    /** Each tarn in world space: {x, z, water level, radius}. */
    public java.util.List<double[]> tarnsWorld() {
        java.util.List<double[]> out = new java.util.ArrayList<>();
        for (int k = 0; k < tarns.size(); k++) { double[] w = tarnWorld(k), t = tarns.get(k); out.add(new double[]{w[0], w[1], t[3], t[2]}); }
        return out;
    }

    public String describeTarns() {
        StringBuilder sb = new StringBuilder();
        for (int k = 0; k < tarns.size(); k++) {
            double[] w = tarnWorld(k), t = tarns.get(k);
            sb.append(String.format("%d,%d,%d r%.0f%s; ", (int) w[0], (int) t[3], (int) w[1], t[2], Double.isNaN(t[13]) ? "" : " islet"));
        }
        return sb.toString();
    }

    public int[] toWorld(double u, double v) { return new int[]{(int) Math.round(cx + u * cos - v * sin), (int) Math.round(cz + u * sin + v * cos)}; }
    /** The great arch's two feet (world x, z): the low end in the lake, the high end on the hillside. */
    public int[] archLow() { return toWorld(aLoU, aLoV); }
    public int[] archHigh() { return toWorld(aHiU, aHiV); }
    public int[] greatArch() { return toWorld((aLoU + aHiU) / 2, (aLoV + aHiV) / 2); }
    public int[] landingCove() { return toWorld(landU, landV); }
    public int[] meadow() { return toWorld(shU, shV); }

    /** Where island structures stand (world x, z), by anchor name; null for an unknown anchor. */
    public int[] anchor(String name) {
        double[] p;
        switch (name) {
            case "plains_village": p = pointAt(marshEnd * 0.40, -archSide * 0.12); break;
            case "plains_castle": p = pointAt(marshEnd * 0.72, -archSide * 0.50); break;
            case "plains_center": p = pointAt(marshEnd * 0.5, 0); break;
            case "meadow_plateau": p = new double[]{shU, shV}; break;
            case "great_arch": p = new double[]{(aLoU + aHiU) / 2, (aLoV + aHiV) / 2}; break;
            case "main_peak": p = pointAt(peakS, 0); break;
            default: return null;
        }
        return toWorld(p[0], p[1]);
    }
    public double localU(int x, int z) { double dx = x - cx, dz = z - cz; return dx * cos + dz * sin; }
    public double localV(int x, int z) { double dx = x - cx, dz = z - cz; return -dx * sin + dz * cos; }
}
