package com.ronald.ambientmotion;

import net.minecraftforge.common.ForgeConfigSpec;

/** Client settings, kept in config/ambientmotion-client.toml and changed from the settings screen. */
public final class Settings {
    private Settings() {}

    public enum DofMode {
        OFF("Off"), AUTOFOCUS("Autofocus"), FAR("Far blur"), TILT_SHIFT("Tilt-shift");
        public final String label;
        DofMode(String label) { this.label = label; }
        public DofMode next() { return values()[(ordinal() + 1) % values().length]; }
    }

    static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue MOTION_BLUR, DOF_STRENGTH, SWAY, FAR_FOCUS;
    public static final ForgeConfigSpec.EnumValue<DofMode> DOF_MODE;
    public static final ForgeConfigSpec.BooleanValue LANTERNS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("motion_blur");
        MOTION_BLUR = b.comment("Camera motion blur strength, 0 (off) to 100.").defineInRange("strength", 35, 0, 100);
        b.pop().push("depth_of_field");
        DOF_MODE = b.comment("OFF, AUTOFOCUS (focus on what you look at), FAR (blur in the distance) or TILT_SHIFT (miniature look).")
                .defineEnum("mode", DofMode.AUTOFOCUS);
        DOF_STRENGTH = b.comment("How soft the out-of-focus parts get, 0 to 100.").defineInRange("strength", 40, 0, 100);
        FAR_FOCUS = b.comment("Far blur: how far away (in blocks) things start to soften.").defineInRange("far_focus_distance", 32, 4, 256);
        b.pop().push("sway");
        SWAY = b.comment("How much grass and leaves sway in the breeze, 0 (still) to 100.").defineInRange("strength", 60, 0, 100);
        LANTERNS = b.comment("Lanterns swing gently too.").define("lanterns", true);
        b.pop();
        SPEC = b.build();
    }

    static int get(ForgeConfigSpec.IntValue v, int fallback) {
        try { return v.get(); } catch (IllegalStateException notLoaded) { return fallback; }
    }
    public static float motionBlur() { return get(MOTION_BLUR, 0) / 100f; }
    public static float dofStrength() { return get(DOF_STRENGTH, 0) / 100f; }
    public static float sway() { return get(SWAY, 0) / 100f; }
    public static int farFocus() { return get(FAR_FOCUS, 32); }
    public static DofMode dofMode() { try { return DOF_MODE.get(); } catch (IllegalStateException e) { return DofMode.OFF; } }
    public static boolean lanterns() { try { return LANTERNS.get(); } catch (IllegalStateException e) { return false; } }
}
