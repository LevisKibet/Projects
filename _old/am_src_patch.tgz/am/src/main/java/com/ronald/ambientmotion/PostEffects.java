package com.ronald.ambientmotion;

import com.mojang.blaze3d.systems.RenderSystem;
import com.ronald.ambientmotion.mixin.PostChainAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EffectInstance;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;

/**
 * Motion blur and depth of field, run on the finished world image (before the hand and the HUD are drawn, so those
 * stay crisp) as one post-processing chain: assets/ambientmotion/shaders/post/ambient.json.
 */
public final class PostEffects {
    private PostEffects() {}

    private static final ResourceLocation CHAIN = new ResourceLocation(AmbientMotion.MODID, "shaders/post/ambient.json");
    private static PostChain chain;
    private static boolean failed;
    private static int width = -1, height = -1;
    private static Matrix4f prevViewProj;
    private static Vec3 prevCam;

    static void render(RenderLevelStageEvent e) {
        Minecraft mc = Minecraft.getInstance();
        float blur = Settings.motionBlur();
        Settings.DofMode mode = Settings.dofMode();
        float dof = Settings.dofStrength();
        boolean on = (blur > 0 || (mode != Settings.DofMode.OFF && dof > 0)) && !AmbientMotion.shaderPackInUse();
        if (!on || failed || mc.level == null) { prevViewProj = null; return; }
        if (!ensure(mc)) return;

        Matrix4f viewProj = new Matrix4f(e.getProjectionMatrix()).mul(e.getPoseStack().last().pose());
        Matrix4f inv = new Matrix4f(viewProj).invert();
        Vec3 cam = e.getCamera().getPosition();
        if (prevViewProj == null || prevCam == null || cam.distanceToSqr(prevCam) > 64) { prevViewProj = viewProj; prevCam = cam; }
        float dx = (float) (cam.x - prevCam.x), dy = (float) (cam.y - prevCam.y), dz = (float) (cam.z - prevCam.z);

        for (PostPass pass : ((PostChainAccessor) chain).ambientmotion$passes()) {
            EffectInstance fx = pass.getEffect();
            fx.safeGetUniform("InvViewProj").set(inv);
            fx.safeGetUniform("PrevViewProj").set(prevViewProj);
            fx.safeGetUniform("CamDelta").set(dx, dy, dz);
            fx.safeGetUniform("MotionStrength").set(blur * 0.9f);
            fx.safeGetUniform("DofMode").set((float) mode.ordinal());
            fx.safeGetUniform("DofStrength").set(dof * 14f);
            fx.safeGetUniform("FocusDistance").set((float) Settings.farFocus());
        }

        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.resetTextureMatrix();
        chain.process(e.getPartialTick());
        mc.getMainRenderTarget().bindWrite(true);
        RenderSystem.enableDepthTest();

        prevViewProj = viewProj;
        prevCam = cam;
    }

    private static boolean ensure(Minecraft mc) {
        var target = mc.getMainRenderTarget();
        try {
            if (chain == null) {
                chain = new PostChain(mc.getTextureManager(), mc.getResourceManager(), target, CHAIN);
                width = -1;
            }
            if (width != target.width || height != target.height) {
                chain.resize(target.width, target.height);
                width = target.width; height = target.height;
            }
            return true;
        } catch (Exception ex) {
            AmbientMotion.LOGGER.error("Ambient Motion: couldn't load its post-processing shaders; motion blur and depth of field are off", ex);
            failed = true;
            if (chain != null) { chain.close(); chain = null; }
            return false;
        }
    }

    /** Resource packs reloaded: build the chain again next frame. */
    static void reset() {
        if (chain != null) { chain.close(); chain = null; }
        failed = false;
        prevViewProj = null;
    }
}
