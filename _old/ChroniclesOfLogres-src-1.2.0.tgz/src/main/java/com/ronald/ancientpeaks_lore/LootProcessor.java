package com.ronald.ancientpeaks_lore;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BarrelBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessorType;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;

/**
 * Every chest in our buildings gets the Logres loot (enchanted iron gear and up, food, ingots and ores - including other
 * mods' through their tags and the vanilla tables they add to); about a third of the barrels get the lighter
 * stores table, the rest stay empty. Whatever a template had in its containers is replaced.
 */
public class LootProcessor extends StructureProcessor {
    public static final Codec<LootProcessor> CODEC = Codec.unit(LootProcessor::new);
    static final String CHEST = AncientPeaksLore.MODID + ":chests/logres", BARREL = AncientPeaksLore.MODID + ":chests/logres_stores";

    @Override
    public StructureTemplate.StructureBlockInfo processBlock(LevelReader level, BlockPos offset, BlockPos pos,
                                                             StructureTemplate.StructureBlockInfo original,
                                                             StructureTemplate.StructureBlockInfo current, StructurePlaceSettings settings) {
        if (current == null) return null;
        boolean chest = current.state().getBlock() instanceof ChestBlock, barrel = current.state().getBlock() instanceof BarrelBlock;
        if (!chest && !barrel) return current;
        var r = settings.getRandom(current.pos());
        if (barrel && r.nextFloat() > 0.35f) return current;
        CompoundTag nbt = current.nbt() == null ? new CompoundTag() : current.nbt().copy();
        nbt.remove("Items");
        nbt.putString("id", chest ? "minecraft:chest" : "minecraft:barrel");
        nbt.putString("LootTable", chest ? CHEST : BARREL);
        nbt.putLong("LootTableSeed", r.nextLong());
        return new StructureTemplate.StructureBlockInfo(current.pos(), current.state(), nbt);
    }

    @Override protected StructureProcessorType<?> getType() { return AncientPeaksLore.LOOT.get(); }
}
