package com.ronald.ancientpeaks_lore;

import com.ronald.ancientpeaks.world.HighlandsAccess;
import com.ronald.ancientpeaks.world.Island;
import com.ronald.ancientpeaks.world.IslandSampler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

/**
 * Merlin, wounded in his besieged chapel near spawn.
 *   WOUNDED  lying on the floor. When a player comes close the siege begins.
 *   SIEGE    raiders come in waves and a bar shows him fading. Heal him in time (a golden apple, or a potion of
 *            healing used on him / thrown at him) and, with the last of his strength, he drives the raiders off.
 *            If the time runs out he slips away; the raiders go, and the siege can be tried again a minute later.
 *   HEALED   the "merlin" cutscene plays (20 s, see client/Cutscenes): still slumped against the wall, he tells you
 *            what you need to know, blesses everyone near, gives the healer his map to the nearest gateway, and
 *            vanishes in light.
 * He only ever plays one animation: "injured_leaning" (slumped against a chapel wall, facing the room).
 */
public class Merlin extends PathfinderMob implements GeoEntity {
    public static final int WOUNDED = 0, SIEGE = 1, HEALED = 2;
    private final java.util.Set<java.util.UUID> heardBell = new java.util.HashSet<>();
    static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(Merlin.class, EntityDataSerializers.INT);
    static final int SIEGE_TICKS = 20 * 180, WAVE_TICKS = 20 * 25, MAX_WAVES = 6;
    static final String BESIEGER = "ancientpeaks_lore_besieger";
    static final TagKey<Structure> GATEWAYS = TagKey.create(Registries.STRUCTURE, new ResourceLocation(AncientPeaksLore.MODID, "gateways"));

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bar = new ServerBossEvent(Component.literal("Merlin is fading"), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    private int timer, waveIn, waves, cooldown, talk = -1;
    private java.util.UUID healer;

    public Merlin(EntityType<? extends Merlin> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        bar.setVisible(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 40).add(Attributes.MOVEMENT_SPEED, 0.22).add(Attributes.FOLLOW_RANGE, 16);
    }

    public int state() { return entityData.get(STATE); }
    public boolean healed() { return state() == HEALED; }
    void setState(int s) { entityData.set(STATE, s); }

    @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(STATE, WOUNDED); }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
    }

    // ------------------------------------------------------------------ he can't be killed (only /kill)
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);
        return false;
    }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean requiresCustomPersistence() { return true; }
    @Override public boolean isPushable() { return false; }
    @Override protected boolean shouldDespawnInPeaceful() { return false; }

    /** Instant health (a thrown or lingering potion of healing) wakes him too. */
    @Override
    public void heal(float amount) {
        super.heal(amount);
        if (amount > 0 && !level().isClientSide && state() == SIEGE) {
            Player p = level().getNearestPlayer(this, 24);
            onHealed(p);
        }
    }

    // ------------------------------------------------------------------ talking to him / healing him by hand
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (level().isClientSide) return InteractionResult.SUCCESS;
        ServerLevel sl = (ServerLevel) level();
        if (state() != HEALED) {
            boolean cure = held.is(Items.GOLDEN_APPLE) || held.is(Items.ENCHANTED_GOLDEN_APPLE)
                    || (held.is(Items.POTION) && (PotionUtils.getPotion(held) == Potions.HEALING || PotionUtils.getPotion(held) == Potions.STRONG_HEALING));
            if (!cure) {
                Quest.hint(player, state() == SIEGE ? "He is badly hurt... a golden apple or a potion of healing might save him."
                        : "An old man lies wounded on the floor, barely breathing.");
                return InteractionResult.CONSUME;
            }
            if (!player.getAbilities().instabuild) {
                if (held.is(Items.POTION)) player.setItemInHand(hand, new ItemStack(Items.GLASS_BOTTLE));
                else held.shrink(1);
            }
            if (state() == WOUNDED) startSiege(sl, false);     // healed before the raiders even came
            onHealed(player);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.CONSUME;                  // he is already telling you all he can
    }

    /** Back to the wall, facing the room, on both sides (so the client never turns him). */
    @Override
    public void tick() {
        super.tick();
        setYBodyRot(getYRot()); setYHeadRot(getYRot()); yBodyRotO = getYRot(); yHeadRotO = getYRot();
    }

    // ------------------------------------------------------------------ the siege
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        ServerLevel sl = (ServerLevel) level();
        getNavigation().stop();
        setYBodyRot(getYRot()); setYHeadRot(getYRot());
        if (state() == HEALED && talk < 0) talk = 0;                    // reloaded mid-farewell: he starts again
        if (cooldown > 0) cooldown--;

        // a faint bell from the chapel draws anyone passing: once a player hears it, a hint tells them to look for him
        if (state() == WOUNDED && tickCount % 20 == 0) {
            boolean near = false;
            for (net.minecraft.server.level.ServerPlayer pl : sl.players()) {
                if (pl.isSpectator() || pl.distanceToSqr(this) > 56 * 56) continue;
                near = true;
                if (heardBell.add(pl.getUUID())) {
                    pl.playNotifySound(SoundEvents.BELL_BLOCK, SoundSource.AMBIENT, 0.35f, 0.55f);
                    pl.sendSystemMessage(Component.literal("You hear a faint bell tolling somewhere nearby... someone may be in need. Search the chapel and help them.")
                            .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
                }
            }
            if (near && tickCount % 200 == 0) sl.playSound(null, blockPosition().above(6), SoundEvents.BELL_BLOCK, SoundSource.BLOCKS, 2.5f, 0.55f);
        }
        if (state() == WOUNDED && cooldown == 0 && tickCount % 10 == 0) {
            Player p = sl.getNearestPlayer(getX(), getY(), getZ(), 18, pl -> !pl.isSpectator() && !((Player) pl).isCreative());
            if (p != null) startSiege(sl, true);
        }
        if (state() == SIEGE) {
            timer--;
            bar.setProgress(Mth.clamp(timer / (float) SIEGE_TICKS, 0, 1));
            if (tickCount % 20 == 0) updateBar(sl);
            if (--waveIn <= 0 && waves < MAX_WAVES) { spawnWave(sl); waves++; waveIn = WAVE_TICKS; }
            if (timer % 400 == 0 && timer > 0) sl.sendParticles(ParticleTypes.SOUL, getX(), getY() + 0.3, getZ(), 6, 0.4, 0.1, 0.4, 0.01);
            boolean anyone = sl.getNearestPlayer(this, 64) != null;
            if (timer <= 0 || !anyone) fail(sl, anyone);
        }
        if (talk >= 0) dialogue(sl);
    }

    private void startSiege(ServerLevel sl, boolean announce) {
        setState(SIEGE);
        timer = SIEGE_TICKS; waves = 0; waveIn = announce ? 100 : WAVE_TICKS;
        bar.setProgress(1); bar.setVisible(true); updateBar(sl);
        if (announce) {
            Quest.say(sl, position(), 40, "Merlin", ChatFormatting.LIGHT_PURPLE, "...you... you can hear me? Then hear this: they are coming back for the old man.");
            Quest.say(sl, position(), 40, "Merlin", ChatFormatting.LIGHT_PURPLE, "Their blades found me... I have not long. A golden apple, a draught of healing... anything...");
            sl.playSound(null, blockPosition(), SoundEvents.RAID_HORN.get(), SoundSource.HOSTILE, 4.0f, 1.0f);
        }
    }

    private void updateBar(ServerLevel sl) {
        for (ServerPlayer p : List.copyOf(bar.getPlayers())) if (p.distanceToSqr(this) > 48 * 48 || !p.isAlive()) bar.removePlayer(p);
        if (bar.isVisible()) for (ServerPlayer p : sl.players()) if (p.distanceToSqr(this) <= 48 * 48) bar.addPlayer(p);
    }

    /** Raiders close in from every side, more each wave, all after the nearest player. */
    private void spawnWave(ServerLevel sl) {
        Player target = sl.getNearestPlayer(this, 64);
        int n = 2 + waves;
        for (int i = 0; i < n; i++) {
            double a = random.nextDouble() * Math.PI * 2, r = 14 + random.nextDouble() * 8;
            int x = Mth.floor(getX() + Math.cos(a) * r), z = Mth.floor(getZ() + Math.sin(a) * r);
            int y = sl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            EntityType<? extends Mob> type = waves >= 3 && i == 0 ? EntityType.VINDICATOR : i % 3 == 2 ? EntityType.SKELETON : EntityType.ZOMBIE;
            Mob m = type.create(sl);
            if (m == null) continue;
            m.moveTo(x + 0.5, y, z + 0.5, random.nextFloat() * 360, 0);
            m.finalizeSpawn(sl, sl.getCurrentDifficultyAt(m.blockPosition()), MobSpawnType.EVENT, null, null);
            m.setItemSlot(EquipmentSlot.HEAD, new ItemStack(i % 2 == 0 ? Items.CHAINMAIL_HELMET : Items.LEATHER_HELMET));
            m.setDropChance(EquipmentSlot.HEAD, 0);
            m.setCustomName(Component.literal("Raider"));
            m.addTag(BESIEGER);
            m.setPersistenceRequired();
            if (target != null) m.setTarget(target);
            sl.addFreshEntity(m);
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, x + 0.5, y + 1, z + 0.5, 8, 0.3, 0.5, 0.3, 0.01);
        }
    }

    private void fail(ServerLevel sl, boolean anyoneThere) {
        setState(WOUNDED);
        bar.setVisible(false); bar.removeAllPlayers();
        cooldown = 20 * 60;
        if (anyoneThere) Quest.say(sl, position(), 48, "Merlin", ChatFormatting.LIGHT_PURPLE, "...the dark... takes me... come back... when you are ready...");
        for (Mob m : besiegers(sl)) { sl.sendParticles(ParticleTypes.POOF, m.getX(), m.getY() + 1, m.getZ(), 10, 0.3, 0.5, 0.3, 0.02); m.discard(); }
    }

    private List<Mob> besiegers(ServerLevel sl) {
        return sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(80), m -> m.getTags().contains(BESIEGER));
    }

    private void onHealed(Player by) {
        if (state() == HEALED) return;
        ServerLevel sl = (ServerLevel) level();
        setState(HEALED);
        setHealth(getMaxHealth());
        healer = by == null ? null : by.getUUID();
        bar.setVisible(false); bar.removeAllPlayers();
        sl.playSound(null, blockPosition(), SoundEvents.ZOMBIE_VILLAGER_CURE, SoundSource.NEUTRAL, 1.0f, 1.0f);
        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1, getZ(), 30, 0.6, 0.8, 0.6, 0.1);
        talk = 0;
    }

    /** What he says, lying where he fell, before he fades away. (A camera move can follow along here later.) */
    private void dialogue(ServerLevel sl) {
        talk++;
        Player p = healer == null ? null : sl.getPlayerByUUID(healer);
        if (p == null) p = sl.getNearestPlayer(this, 24);
        switch (talk) {
            case 1 -> {                                         // the last of his strength drives the raiders off
                sl.playSound(null, blockPosition(), SoundEvents.EVOKER_CAST_SPELL, SoundSource.NEUTRAL, 2.0f, 0.8f);
                for (Mob b : besiegers(sl)) {
                    sl.sendParticles(ParticleTypes.ENCHANT, b.getX(), b.getY() + 1, b.getZ(), 40, 0.4, 0.8, 0.4, 1.0);
                    sl.sendParticles(ParticleTypes.WITCH, b.getX(), b.getY() + 1, b.getZ(), 15, 0.3, 0.6, 0.3, 0.05);
                    b.hurt(damageSources().indirectMagic(this, this), 1000);
                }
            }
            case 10 -> LoreNet.playCutscene(sl, "merlin", position(), getYRot(), 32);   // ~400 ticks from here
            case 310 -> {                                       // "Take my map..."
                for (Player q : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(32))) {
                    Quest.set(q, Quest.BLESSED, true);
                    Quest.hint(q, "Merlin's blessing is upon you.");
                }
                if (p != null) giveMap(sl, p);
            }
            case 370 -> vanish(sl);
            case 400 -> vanish(sl);                             // (never stays behind, whatever happened above)
            default -> {
                if (talk > 10 && talk % 10 == 0) sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.0, getZ(), 2, 0.3, 0.5, 0.3, 0.01);
            }
        }
    }

    /** He fades into light and is gone. */
    private void vanish(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 0.5, getZ(), 60, 0.5, 0.5, 0.5, 0.08);
        sl.sendParticles(ParticleTypes.ENCHANT, getX(), getY() + 0.5, getZ(), 120, 0.6, 0.8, 0.6, 1.2);
        sl.sendParticles(ParticleTypes.SOUL, getX(), getY() + 0.3, getZ(), 20, 0.5, 0.2, 0.5, 0.02);
        sl.playSound(null, blockPosition(), SoundEvents.ILLUSIONER_MIRROR_MOVE, SoundSource.NEUTRAL, 2.0f, 0.7f);
        sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.NEUTRAL, 1.5f, 1.2f);
        talk = -1;
        LoreNet.endCutscene(sl, position(), 48);
        discard();
    }

    // ------------------------------------------------------------------ his map
    /** An explorer's map centred on the nearest gateway (or the nearest island, if no gateway is found), marked with an X. */
    void giveMap(ServerLevel sl, Player p) {
        BlockPos target = nearestGateway(sl, blockPosition());
        if (target == null) target = nearestIsland(sl);
        ItemStack map;
        if (target != null) {
            map = net.minecraft.world.item.MapItem.create(sl, target.getX(), target.getZ(), (byte) 2, true, true);
            net.minecraft.world.item.MapItem.renderBiomePreviewMap(sl, map);
            net.minecraft.world.level.saveddata.maps.MapItemSavedData.addTargetDecoration(map, target, "+",
                    net.minecraft.world.level.saveddata.maps.MapDecoration.Type.RED_X);
        } else {
            map = new ItemStack(Items.MAP);
        }
        map.setHoverName(Component.literal("Merlin's Map").withStyle(ChatFormatting.LIGHT_PURPLE).withStyle(s -> s.withItalic(false)));
        CompoundTag display = map.getOrCreateTagElement("display");
        ListTag lore = new ListTag();
        lore.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal("The old gate across the water.").withStyle(ChatFormatting.GRAY))));
        display.put("Lore", lore);
        map.getOrCreateTag().putBoolean("ancientpeaks_lore_map", true);
        if (!p.addItem(map)) p.drop(map, false);
    }

    /**
     * Where the nearest Highland Gateway really stands. Candidates come straight from the gateways' placement grid (one
     * chunk per 44x44-chunk cell), nearest first; each is confirmed by working out that chunk's structure starts (cheap:
     * no terrain is built), so the X always marks a portal that is actually there.
     */
    static BlockPos nearestGateway(ServerLevel sl, BlockPos near) {
        try {
            var set = sl.registryAccess().registryOrThrow(Registries.STRUCTURE_SET).get(new ResourceLocation("ancientpeaks", "highland_gateways"));
            if (set == null || set.structures().isEmpty()
                    || !(set.placement() instanceof net.minecraft.world.level.levelgen.structure.placement.RandomSpreadStructurePlacement rsp)) return null;
            Structure st = set.structures().get(0).structure().value();
            int spacing = rsp.spacing(), cx = Math.floorDiv(near.getX() >> 4, spacing), cz = Math.floorDiv(near.getZ() >> 4, spacing);
            java.util.List<net.minecraft.world.level.ChunkPos> cand = new java.util.ArrayList<>();
            for (int dx = -5; dx <= 5; dx++) for (int dz = -5; dz <= 5; dz++)
                cand.add(rsp.getPotentialStructureChunk(sl.getSeed(), cx + dx, cz + dz));
            cand.sort(java.util.Comparator.comparingDouble(c -> Math.hypot(c.getMiddleBlockX() - near.getX(), c.getMiddleBlockZ() - near.getZ())));
            int tried = 0;
            for (var cp : cand) {
                if (tried++ >= 24) break;
                var chunk = sl.getChunk(cp.x, cp.z, net.minecraft.world.level.chunk.ChunkStatus.STRUCTURE_STARTS);
                var start = chunk.getStartForStructure(st);
                if (start == null || !start.isValid()) continue;
                var box = start.getBoundingBox();
                return new BlockPos((box.minX() + box.maxX()) / 2, box.minY(), (box.minZ() + box.maxZ()) / 2);
            }
            return null;
        } catch (RuntimeException e) {
            AncientPeaksLore.LOGGER.warn("[ancientpeaks_lore] couldn't work out where the gateways are", e);
            return null;
        }
    }

    private BlockPos nearestIsland(ServerLevel sl) {
        IslandSampler s = ((HighlandsAccess) (Object) sl.getChunkSource().randomState()).ancientpeaks$sampler();
        if (s == null) return null;
        int sx = Math.floorDiv(getBlockX(), IslandSampler.SECTOR), sz = Math.floorDiv(getBlockZ(), IslandSampler.SECTOR);
        Island best = null; double bd = Double.MAX_VALUE;
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            Island is = s.islandInSector(sx + dx, sz + dz);
            if (is == null) continue;
            double d = Math.hypot(is.cx - getX(), is.cz - getZ());
            if (d < bd) { bd = d; best = is; }
        }
        return best == null ? null : new BlockPos(best.cx, 64, best.cz);
    }

    // ------------------------------------------------------------------ saving
    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putInt("QuestState", state() == SIEGE ? WOUNDED : state());       // a siege doesn't survive a reload
        if (healer != null) t.putUUID("Healer", healer);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        setState(t.getInt("QuestState"));
        if (t.hasUUID("Healer")) healer = t.getUUID("Healer");
    }

    @Override
    public void remove(RemovalReason reason) {
        bar.removeAllPlayers();
        super.remove(reason);
    }

    // ------------------------------------------------------------------ animation: only ever lying wounded
    static final RawAnimation LYING = RawAnimation.begin().thenLoop("injured_leaning");

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar c) {
        c.add(new AnimationController<>(this, "main", 0, s -> s.setAndContinue(LYING)));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
