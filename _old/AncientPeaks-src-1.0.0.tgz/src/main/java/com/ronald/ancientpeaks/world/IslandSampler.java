package com.ronald.ancientpeaks.world;

import java.util.Optional;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Places one Ancient Highlands island per 20,000 x 20,000 sector (deep ocean only, away from spawn)
 * and evaluates its terrain, water and zones. Pure Java so the offline preview tool can run it too.
 */
public final class IslandSampler {
    public interface Continents { double at(int x, int z); }

    public static final int SECTOR = 20000, MARGIN = 2000, SPAWN_EXCLUSION = 5000;
    public static final double DEEP_OCEAN = -0.36;

    public static final double TUNNEL_END = 0.68;

    // one sampler per world seed, shared by every density function and hook of that world
    private static final ConcurrentHashMap<Long, IslandSampler> BY_SEED = new ConcurrentHashMap<>();
    public static IslandSampler forSeed(long seed) { return ACTIVE = BY_SEED.computeIfAbsent(seed, k -> new IslandSampler(k, false)); }
    /** The sampler of the world being generated (for hooks that are not handed a level, like Streams Reflowing's). */
    public static volatile IslandSampler ACTIVE;

    private final long[] calmCache = new long[8192];
    /**
     * True where Streams Reflowing must not veto vegetation: the plains (no streams start there) and the tarns.
     * Cached per 4x4 column.
     */
    public boolean calmGround(int x, int z) {
        if (islandAt(x, z) == null) return false;
        int qx = x >> 2, qz = z >> 2;
        long key = (1L << 61) | ((long) (qx & 0xFFFFFF) << 26) | ((long) (qz & 0xFFFFFF) << 2);
        int slot = (int) ((qx * 73856093L ^ qz * 19349663L) & 8191);
        long e = calmCache[slot];
        if ((e & ~3L) == key) return (e & 3) == 1;
        Column c = new Column();
        fill(c, (qx << 2) + 2, (qz << 2) + 2);
        Zone zn = zone(c, 64);
        boolean calm = zn == Zone.PLAINS || zn == Zone.TARN || (c.tarn >= 0 && c.td < c.is.tarns.get(c.tarn)[2] + 10);
        calmCache[slot] = key | (calm ? 1 : 2);
        return calm;
    }

    public enum Zone { NONE, CLIFFS, MEADOW, FOREST, PLAINS, GORGE, SHORE, PEAKS, TARN }

    private final long seed;
    private volatile Continents continents;
    private final boolean preview;
    private final ConcurrentHashMap<Long, Optional<Island>> sectors = new ConcurrentHashMap<>();

    public IslandSampler(long seed, boolean preview) { this.seed = seed; this.preview = preview; }
    public void setContinents(Continents c) { this.continents = c; }
    public boolean ready() { return preview || continents != null; }

    // ------------------------------------------------------------------ placement
    public Island islandAt(int x, int z) {
        Island is = islandInSector(Math.floorDiv(x, SECTOR), Math.floorDiv(z, SECTOR));
        if (is == null) return null;
        double dx = x - is.cx, dz = z - is.cz;
        return dx * dx + dz * dz < is.boundR * is.boundR ? is : null;
    }

    public Island islandInSector(int sx, int sz) {
        if (!ready()) return null;
        return sectors.computeIfAbsent(((long) sx << 32) ^ (sz & 0xFFFFFFFFL), k -> Optional.ofNullable(find(sx, sz))).orElse(null);
    }

    private Island find(int sx, int sz) {
        Random r = new Random(seed ^ (sx * 341873128712L) ^ (sz * 132897987541L));
        if (DEBUG) {
            StringBuilder sb = new StringBuilder("[ancientpeaks] sector " + sx + "," + sz + " continents:");
            Random q = new Random(sx * 31L + sz);
            for (int i = 0; i < 12; i++) sb.append(String.format(" %.2f", continents.at(sx * SECTOR + q.nextInt(SECTOR), sz * SECTOR + q.nextInt(SECTOR))));
            System.out.println(sb);
        }
        for (int attempt = 0; attempt < 48; attempt++) {
            int x = sx * SECTOR + MARGIN + r.nextInt(SECTOR - 2 * MARGIN);
            int z = sz * SECTOR + MARGIN + r.nextInt(SECTOR - 2 * MARGIN);
            long islandSeed = r.nextLong();
            if (Math.hypot(x, z) < SPAWN_EXCLUSION) continue;
            if (preview) return new Island(x, z, islandSeed);
            if (!ocean(x, z, 0.04)) continue;
            Island is = new Island(x, z, islandSeed);
            if (footprintIsOcean(is)) return is;
            if (DEBUG) System.out.println("[ancientpeaks]   reject footprint at " + x + "," + z + " why=" + lastWhy);
        }
        return null;
    }

    /** Deep ocean only - and never next to mushroom fields (they sit at even lower continentalness). */
    public static boolean DEBUG = Boolean.getBoolean("ancientpeaks.debug");
    private String lastWhy = "";
    private boolean ocean(int x, int z, double slack) {
        double c = continents.at(x, z);
        boolean ok = c < DEEP_OCEAN + slack && c > -1.04;
        if (!ok) lastWhy = String.format("%.2f", c);
        return ok;
    }

    private boolean footprintIsOcean(Island is) {
        for (int i = 0; i <= 20; i++) {
            double s = i / 20.0;
            for (double side : new double[]{-1.9, -1.2, 0, 1.2, 1.9}) {
                double[] p = is.pointAt(s, side);
                int[] w = is.toWorld(p[0], p[1]);
                if (!ocean(w[0], w[1], 0.15)) return false;
            }
        }
        double ring = is.boundR - Island.SHELF * 0.2;
        for (int i = 0; i < 40; i++) {
            double a = i * Math.PI * 2 / 40;
            if (!ocean((int) (is.cx + Math.cos(a) * ring), (int) (is.cz + Math.sin(a) * ring), 0.23)) return false;
        }
        return true;
    }

    // ------------------------------------------------------------------ helpers
    static double smooth(double a, double b, double x) { return Island.smooth(a, b, x); }
    private static double clamp1(double v) { return v < -1 ? -1 : (v > 1 ? 1 : v); }

    // ------------------------------------------------------------------ per-column fields
    public static final class Column {
        public int x = Integer.MIN_VALUE, z = Integer.MIN_VALUE;
        public Island is;
        public double m, u, v, h, hHi, coast, stackH, jitterAmp, widN;
        final Island.Base b = new Island.Base();
        final double[] rd = new double[4], rs = new double[4], rl = new double[4];
        double sd, ss;
        int tarn = -1; double td, islet;
    }

    public void fill(Column c, int x, int z) {
        fillIsland(c, islandAt(x, z), x, z);
    }

    void fillIsland(Column c, Island is, int x, int z) {
        c.x = x; c.z = z;
        c.is = is;
        if (is == null) { c.m = 0; return; }
        double u = is.localU(x, z), v = is.localV(x, z);
        c.u = u; c.v = v;
        Island.Base b = c.b;
        is.baseAt(u, v, b, true);
        c.m = 1 - smooth(1.06, 1.0 + (Island.SHELF + 30) / b.wBlocks, b.e);
        if (c.m <= 0) return;
        c.coast = smooth(1, 1 + b.coastK, b.e);
        c.stackH = -1e9;
        for (double[] s : is.stacks) {
            double d = Math.hypot(u - s[0], v - s[1]);
            double rad = s[2] * (1 + 0.25 * is.n[11].get(u / 9, v / 9));
            if (d < rad) c.stackH = Math.max(c.stackH, s[3] - Math.pow(d / rad, 6) * 20);
        }
        c.h = Math.max(is.heightAt(b, b.e), c.stackH);
        c.hHi = Math.max(is.heightAt(b, b.e - Island.LEAN * 254 / b.wBlocks), c.h);
        c.jitterAmp = 2.6 * b.hw * (1 - b.shelfM) + 1.8 * c.coast;
        c.widN = 2.0 * is.n[12].get(u / 80, v / 80);
        double[] o = new double[3];
        for (int i = 0; i < is.rivers.size() && i < 4; i++) {
            Island.pathDist(is.rivers.get(i), u, v, o);
            c.rd[i] = o[0]; c.rs[i] = o[1]; c.rl[i] = o[2];
        }
        Island.pathDist(is.strait, u, v, o);
        c.sd = o[0]; c.ss = o[1];
        c.tarn = -1; c.td = 1e9; c.islet = 1e9;
        for (int i = 0; i < is.tarns.size(); i++) {
            double[] t = is.tarns.get(i);
            double du = u - t[0], dv = v - t[1];
            // distance warped by the tarn's outline, so "td < radius" traces an irregular shore
            double d = Math.hypot(du, dv) / Island.tarnShape(t, Math.atan2(dv, du));
            if (d < c.td) {
                c.td = d; c.tarn = i;
                c.islet = Double.isNaN(t[13]) ? 1e9
                        : Math.hypot(du - Math.cos(t[13]) * t[2] * 0.38, dv - Math.sin(t[13]) * t[2] * 0.38) / (t[2] * 0.2);
            }
        }
    }

    // ------------------------------------------------------------------ density
    /** Carve amount for a river/strait channel: > 0 means air. */
    private double channelCarve(Island.Path p, double d, double frac, double level, double y, double terrain, double widN) {
        double wc = p.width0 + (p.width1 - p.width0) * frac + widN;
        double depth = p.depth0 + (p.depth1 - p.depth0) * frac;
        double bed = d < wc ? level - depth * (1 - (d / wc) * (d / wc)) : level + (d - wc) * p.bankSlope;
        double carve = y - bed;
        if (p.gorge) {
            // walls lean inward above the lower gorge: overhanging rock over the river
            double hh = y - level;
            double allowed = wc + Math.min(hh, 26) / p.bankSlope * 1.0 + 3 - 0.07 * Math.max(0, hh - 26)
                    + 0.7 * Math.max(0, y - (terrain - 9));
            allowed = Math.max(allowed, wc * 0.7);
            carve = Math.min(carve, allowed - d);
        }
        return carve;
    }

    /** Island terrain density at a block: > 0 solid. Only meaningful where c.m > 0. */
    public double density(Column c, int x, int y, int z) {
        Island is = c.is;
        Island.Base b = c.b;
        double j = 0;
        if (c.jitterAmp > 0 && y > c.h - 50) j = is.n[13].get(x / 14.0 + y / 10.0, z / 14.0) + is.n[12].get(x / 14.0, z / 14.0 - y / 10.0);
        double dens;
        if (y < c.h - 6) dens = 1;
        else if (y > c.hHi + 6) dens = -1;
        else {
            double lean = Island.LEAN * Math.max(0, Math.min(y, 175) - 66) * (0.35 + 0.65 * Math.max(b.hw, c.coast)) / b.wBlocks;
            double h = Math.max(is.heightAt(b, b.e - lean), c.stackH);
            dens = clamp1((h + j * c.jitterAmp - y) / 3.0);
        }
        boolean anyGround = dens > -1;

        // rivers
        for (int i = 0; anyGround && i < is.rivers.size() && i < 4; i++) {
            if (c.rd[i] > 90) continue;
            Island.Path p = is.rivers.get(i);
            double carve = channelCarve(p, c.rd[i], c.rs[i], c.rl[i], y, c.h, c.widN);
            if (carve > 0 && p.gorge) {
                for (double bf : p.bridges) {
                    if (Math.abs(c.rs[i] - bf) * p.len < 7 + 3 * is.n[11].get(x / 20.0, z / 20.0)) {
                        double top = c.h - 22, thick = 5 + 12 * Math.min(1, c.rd[i] / 16);
                        double arch = Math.min(top - y, y - (top - thick));
                        if (arch > 0 && top - c.rl[i] > 20) carve = Math.min(carve, -arch);
                    }
                }
            }
            if (carve > 0) dens = Math.min(dens, clamp1(-carve / 2.0));
        }
        // sea strait: a great sea tunnel through the island, open to the sky only for its last quarter
        if (anyGround && c.sd < 70) {
            Island.Path p = is.strait;
            double carve;
            if (c.ss < TUNNEL_END) {
                double wt = 13 + c.widN + 2.5 * is.n[11].get(x / 18.0 + y / 14.0, z / 18.0);
                double q = c.sd / wt;
                double ceiling = Math.min(62 + 24 * Math.sqrt(Math.max(0, 1 - q * q)), Math.max(c.h - 10, 64));
                double bed = 38 + 12 * q * q;
                carve = Math.min(Math.min(y - bed, ceiling - y), wt - c.sd);
                // the tunnel mouth at the closed end opens as a sea cave in the cliff
            } else {
                carve = channelCarve(p, c.sd, c.ss, 40, y, c.h, c.widN);
                for (double bf : p.bridges) {
                    if (Math.abs(c.ss - bf) * p.len < 8 + 3 * is.n[11].get(x / 20.0, z / 20.0)) {
                        double top = c.h - 14, thick = 7 + 10 * Math.min(1, c.sd / 14);
                        double arch = Math.min(top - y, y - (top - thick));
                        if (arch > 0) carve = Math.min(carve, -arch);
                    }
                }
            }
            if (carve > 0) dens = Math.min(dens, clamp1(-carve / 2.0));
        }
        // tarn bowls
        if (anyGround && c.tarn >= 0) {
            double[] t = is.tarns.get(c.tarn);
            double r = t[2] * (1 + 0.12 * is.n[9].get(x / 9.0, z / 9.0));
            if (c.td < r) {
                double q = c.td / r;
                double bottom = t[3] - 8 * Math.sqrt(Math.max(0, 1 - q * q));          // a bowl
                if (c.islet < 1.6) bottom = Math.max(bottom, t[3] + 1.5 - c.islet * c.islet * 4);   // a small grassy islet
                if (y > bottom) dens = Math.min(dens, clamp1(-(y - bottom) / 2.0));
            }
            // settle the ground around the tarn into a gentle basin so it is never a pit
            if (c.td < r + 34) {
                double cap = t[3] + 2 + Math.max(0, c.td - r) * 0.75;
                dens = Math.min(dens, clamp1((cap - y) / 3.0));
            }
            // a lip all round: the lake is still and never spills
            if (c.td >= r * 0.96 && c.td < r + 4 && y > t[3] - 7) {
                double lip = t[3] + 1.5 - Math.max(0, c.td - r - 1.5) * 0.6;
                dens = Math.max(dens, clamp1((lip - y) / 1.5));
            }
        }
        // great arch: springs from the hillside and lands in the lake
        double au = is.aHiU - is.aLoU, av = is.aHiV - is.aLoV, al2 = au * au + av * av, al = Math.sqrt(al2);
        double pu = c.u - is.aLoU, pv = c.v - is.aLoV;
        double t = (pu * au + pv * av) / al2;
        if (t > -0.12 && t < 1.12) {
            double w = Math.abs(pu * av - pv * au) / al;
            if (w < 26) {
                double tc = Math.max(0, Math.min(1, t)), sn = Math.sin(Math.PI * tc);
                double yc = is.aLoH + (is.aHiH - is.aLoH) * tc + is.aRise * sn;
                double wob = 2.5 * is.n[11].get(x / 12.0 + y / 10.0, z / 12.0);
                double thV = 6 + 8 * (1 - sn) + wob, thW = 8 + 6 * (1 - sn) + wob;
                boolean solid = Math.abs(y - yc) < thV && w < thW;
                if (tc < 0.12 && t > -0.12 && y < yc && y > 20 && w < thW * 1.25) solid = true;   // lake-side leg
                if (solid) dens = Math.max(dens, 0.8);
            }
        }
        return dens;
    }

    /** Water that the island itself holds: rivers, tarns and anything below sea level. */
    public boolean isWater(Column c, int x, int y, int z) {
        if (c.is == null || c.m <= 0.5) return false;
        Island is = c.is;
        if (y <= 62) return density(c, x, y, z) < 0;
        for (int i = 0; i < is.rivers.size() && i < 4; i++) {
            if (c.rd[i] > 30) continue;
            Island.Path p = is.rivers.get(i);
            double wc = p.width0 + (p.width1 - p.width0) * c.rs[i] + c.widN;
            if (c.rd[i] < wc + 1 && y <= Math.floor(c.rl[i]) && density(c, x, y, z) < 0) return true;
        }
        if (c.tarn >= 0) {
            double[] t = is.tarns.get(c.tarn);
            if (c.td < t[2] * 0.97 && y <= Math.floor(t[3]) && density(c, x, y, z) < 0) return true;
        }
        return false;
    }

    /** Tarn the column belongs to (or -1), its outline-relative distance from the centre, and the tarn's radius. */
    public int tarnOf(Column c) { return c.is == null ? -1 : c.tarn; }
    public double tarnDist(Column c) { return c.td; }
    public double tarnRadius(Column c) { return c.tarn < 0 ? 0 : c.is.tarns.get(c.tarn)[2]; }
    public int tarnLevel(Column c) { return c.tarn < 0 ? 0 : (int) Math.floor(c.is.tarns.get(c.tarn)[3]); }

    /** Inside the inner part of a tarn (where springs bubble up from the floor)? */
    public boolean inTarnCore(Column c) {
        return c.is != null && c.tarn >= 0 && c.td < c.is.tarns.get(c.tarn)[2] * 0.75;
    }

    public int waterTop(Column c) {
        double top = 62;
        if (c.is == null) return (int) top;
        for (int i = 0; i < c.is.rivers.size() && i < 4; i++) if (c.rd[i] < 30) top = Math.max(top, c.rl[i]);
        if (c.tarn >= 0 && c.td < c.is.tarns.get(c.tarn)[2]) top = Math.max(top, c.is.tarns.get(c.tarn)[3]);
        return (int) Math.floor(top);
    }

    public boolean nearRiver(Column c, double reach) {
        if (c.is == null) return false;
        for (int i = 0; i < c.is.rivers.size() && i < 4; i++) if (c.rd[i] < reach) return true;
        return c.sd < reach;
    }

    /**
     * A dry, fairly flat spot on the island's lowland coast where arrivals land: searched along the island's
     * shore away from rivers, the strait and the megalake.
     */
    public int[] findLanding(Island is) { return findLandings(is, 1).get(0); }

    /** Up to n dry, fairly flat coastal spots, best first, at least 70 blocks apart. */
    public java.util.List<int[]> findLandings(Island is, int n) {
        Column c = new Column(), d = new Column();
        java.util.List<double[]> cands = new java.util.ArrayList<>();
        for (int i = 0; i <= 90; i++) {
            double s = 0.05 + 0.9 * i / 90.0;
            for (double side : new double[]{-0.9, -0.82, -0.74, 0.74, 0.82, 0.9}) {
                double[] p = is.pointAt(s, side);
                int[] w = is.toWorld(p[0], p[1]);
                fill(c, w[0], w[1]);
                if (c.m < 1 || c.h < 65.5 || c.h > 96 || nearRiver(c, 22)) continue;
                if (c.tarn >= 0 && c.td < 40) continue;
                double slope = 0;
                for (int[] o : new int[][]{{4, 0}, {-4, 0}, {0, 4}, {0, -4}}) { fill(d, w[0] + o[0], w[1] + o[1]); slope += Math.abs(d.h - c.h); }
                cands.add(new double[]{slope + Math.abs(c.h - 70) * 0.3, w[0], Math.ceil(c.h), w[1]});
            }
        }
        cands.sort((x, y) -> Double.compare(x[0], y[0]));
        java.util.List<int[]> out = new java.util.ArrayList<>();
        for (double[] k : cands) {
            boolean far = true;
            for (int[] o : out) if (Math.hypot(o[0] - k[1], o[2] - k[3]) < 70) { far = false; break; }
            if (far) out.add(new int[]{(int) k[1], (int) k[2], (int) k[3]});
            if (out.size() >= n) break;
        }
        if (out.isEmpty()) { int[] w = is.landingCove(); out.add(new int[]{w[0], 80, w[1]}); }
        return out;
    }

    /** Which island biome a position belongs to. */
    public Zone zone(Column c, int y) {
        if (c.is == null || c.m <= 0.5 || c.coast > 0.5) return Zone.NONE;
        Island.Base b = c.b;
        if (c.tarn >= 0) {
            double[] t = c.is.tarns.get(c.tarn);
            // the whole tarn surroundings, at every height, so Streams Reflowing (which reads biomes at sea level) leaves it alone
            if (c.td < t[2] + 18 && y < t[3] + 16) return Zone.TARN;
        }
        if (c.h > 232 && y > 226) return Zone.PEAKS;
        for (int i = 0; i < c.is.rivers.size() && i < 4; i++) {
            Island.Path p = c.is.rivers.get(i);
            double reach = (p.gorge ? 26 : 16) + p.width1;
            if (c.rd[i] < reach && y > c.rl[i] - 8 && y < c.rl[i] + (p.gorge ? 200 : 14)) return Zone.GORGE;
        }
        if (c.sd < 34 && y > 30 && (c.ss >= TUNNEL_END || y < 90)) return Zone.GORGE;
        if (b.shelfM > 0.5 && y > c.h - 14) return Zone.MEADOW;
        if (b.marshW > 0.5 && c.h < 90) return Zone.PLAINS;
        if (b.e > 0.8 && c.h < 70) return Zone.SHORE;
        if (c.h < 150 && b.hw < 0.75) return Zone.FOREST;
        return Zone.CLIFFS;
    }
}
