package com.ronald.ancientpeaks.world;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.material.Fluids;

import java.util.ArrayList;
import java.util.List;

/** Fills the island's rivers, tarns, strait and megalake; water spilling over each river step becomes a waterfall. */
public class GorgeRiverFeature extends Feature<NoneFeatureConfiguration> {
    public GorgeRiverFeature(Codec<NoneFeatureConfiguration> codec) { super(codec); }

    static IslandSampler sampler(WorldGenLevel level) {
        if (!(level instanceof WorldGenRegion region)) return null;
        RandomState rs = region.getLevel().getChunkSource().randomState();
        return ((HighlandsAccess) (Object) rs).ancientpeaks$sampler();
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        return run(ctx.level(), new ChunkPos(ctx.origin()), ctx.random());
    }

    /** Runs straight after the chunk's decoration pass (see ChunkGeneratorMixin), outside the feature system. */
    public static boolean run(WorldGenLevel level, ChunkPos cp, net.minecraft.util.RandomSource random) {
        IslandSampler sampler = sampler(level);
        if (sampler == null) return false;
        IslandSampler.Column col = new IslandSampler.Column();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        List<BlockPos> placed = new ArrayList<>();
        java.util.Map<Long, IslandSampler.Column> cols = new java.util.HashMap<>();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = cp.getMinBlockX() + dx, z = cp.getMinBlockZ() + dz;
                if (sampler.islandAt(x, z) == null) continue;
                sampler.fill(col, x, z);
                if (col.m <= 0.5) continue;
                int top = sampler.waterTop(col);
                for (int y = 28; y <= top; y++) {
                    if (!sampler.isWater(col, x, y, z)) continue;
                    pos.set(x, y, z);
                    if (!level.getBlockState(pos).isAir()) continue;
                    if (level.getBlockState(pos.below()).isAir()) continue;       // never leave water floating
                    if (y > 62 && leaks(level, sampler, cols, x, y, z, pos)) continue;   // nor standing against open air
                    level.setBlock(pos, Blocks.WATER.defaultBlockState(), 2);
                    if (y > 62) placed.add(pos.immutable());
                }
                if (sampler.tarnOf(col) >= 0) decorateTarn(level, sampler, col, x, z, top, random, pos);
                boolean way = col.p1d < 4 || col.p2d < 4 || col.hxd < 4;
                if (col.chq < 1 || (col.cvd < 3.5 && col.cvs > 0.15) || way) decorateMere(level, x, z, random, pos, col.chq < 1, (int) Math.min(col.h, 250));
            }
        }
        for (BlockPos p : placed) {
            for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
                if (level.getBlockState(p.relative(d)).isAir()) { level.scheduleTick(p, Fluids.WATER, 1 + (p.hashCode() & 7)); break; }
            }
        }
        if (IslandSampler.DEBUG && !placed.isEmpty()) System.out.println("[ancientpeaks] chunk " + cp + " placed " + placed.size() + " water above sea level");
        return !placed.isEmpty();
    }

    /** Lake life: springs, seagrass, kelp and sea pickles on the floor; tall grass and ferns along the shore. */
    private static void decorateTarn(WorldGenLevel level, IslandSampler s, IslandSampler.Column col, int x, int z, int top,
                                     net.minecraft.util.RandomSource random, BlockPos.MutableBlockPos pos) {
        double td = s.tarnDist(col), r = s.tarnRadius(col);
        int lvl = s.tarnLevel(col);
        if (td < r * 0.97) {
            int y = lvl;
            while (y > lvl - 12 && level.getBlockState(pos.set(x, y, z)).is(Blocks.WATER)) y--;
            int depth = lvl - y;                                  // water blocks above the floor block at y
            if (depth < 1) return;
            BlockPos floor = new BlockPos(x, y, z);
            if (!level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP)) return;
            float f = random.nextFloat();
            if (s.inTarnCore(col) && f < 0.04f) {                 // a spring: soul sand sending up bubbles
                level.setBlock(floor, Blocks.SOUL_SAND.defaultBlockState(), 2);
                for (int yy = y + 1; yy <= lvl; yy++)
                    level.setBlock(pos.set(x, yy, z), Blocks.BUBBLE_COLUMN.defaultBlockState().setValue(net.minecraft.world.level.block.BubbleColumnBlock.DRAG_DOWN, false), 2);
            } else if (f < 0.10f && depth >= 4) {                 // kelp
                int h = 1 + random.nextInt(depth - 2);
                for (int k = 1; k <= h; k++)
                    level.setBlock(pos.set(x, y + k, z), k == h ? Blocks.KELP.defaultBlockState().setValue(net.minecraft.world.level.block.KelpBlock.AGE, 20 + random.nextInt(4))
                            : Blocks.KELP_PLANT.defaultBlockState(), 2);
            } else if (f < 0.14f) {                               // sea pickles, glowing on the floor
                level.setBlock(pos.set(x, y + 1, z), Blocks.SEA_PICKLE.defaultBlockState()
                        .setValue(net.minecraft.world.level.block.SeaPickleBlock.PICKLES, 1 + random.nextInt(4))
                        .setValue(net.minecraft.world.level.block.SeaPickleBlock.WATERLOGGED, true), 2);
            } else if (f < 0.24f && depth >= 3) {                 // tall seagrass
                level.setBlock(pos.set(x, y + 1, z), Blocks.TALL_SEAGRASS.defaultBlockState()
                        .setValue(net.minecraft.world.level.block.TallSeagrassBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.LOWER), 2);
                level.setBlock(pos.set(x, y + 2, z), Blocks.TALL_SEAGRASS.defaultBlockState()
                        .setValue(net.minecraft.world.level.block.TallSeagrassBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER), 2);
            } else if (f < 0.55f) {                               // seagrass
                level.setBlock(pos.set(x, y + 1, z), Blocks.SEAGRASS.defaultBlockState(), 2);
            }
        } else if (td < r + 8) {
            // the shore: tall grass, grass and ferns, thinning out away from the water
            if (random.nextFloat() > 0.75f - (float) ((td - r) / 8) * 0.45f) return;
            int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE_WG, x, z);
            BlockPos at = new BlockPos(x, y, z);
            if (!level.getBlockState(at).isAir() || !level.getBlockState(at.above()).isAir()) return;
            var ground = level.getBlockState(at.below());
            if (!(ground.is(Blocks.GRASS_BLOCK) || ground.is(Blocks.MOSS_BLOCK) || ground.is(Blocks.DIRT) || ground.is(Blocks.PODZOL))) return;
            float f = random.nextFloat();
            if (f < 0.55f) {
                var tall = random.nextFloat() < 0.8f ? Blocks.TALL_GRASS : Blocks.LARGE_FERN;
                level.setBlock(at, tall.defaultBlockState().setValue(net.minecraft.world.level.block.DoublePlantBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.LOWER), 2);
                level.setBlock(at.above(), tall.defaultBlockState().setValue(net.minecraft.world.level.block.DoublePlantBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER), 2);
            } else {
                level.setBlock(at, (f < 0.85f ? Blocks.GRASS : Blocks.FERN).defaultBlockState(), 2);
            }
        }
    }

    /** Would water here stand with open air beside it (air that isn't going to be water too)? */
    private static boolean leaks(WorldGenLevel level, IslandSampler sampler, java.util.Map<Long, IslandSampler.Column> cols, int x, int y, int z,
                                 BlockPos.MutableBlockPos pos) {
        for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            int nx = x + d.getStepX(), nz = z + d.getStepZ();
            BlockPos n = new BlockPos(nx, y, nz);
            var st = level.getBlockState(n);
            if (!st.isAir()) continue;
            IslandSampler.Column c = cols.computeIfAbsent(net.minecraft.world.level.ChunkPos.asLong(nx, nz), k -> {
                IslandSampler.Column cc = new IslandSampler.Column(); sampler.fill(cc, nx, nz); return cc;
            });
            if (c.m <= 0.5 || !sampler.isWater(c, nx, y, nz)) return true;
        }
        return false;
    }

    /**
     * The mere cave, grown lush: moss over the floors, azalea and ferns, glow berries hanging from the roof (the light
     * to find your way by), spore blossoms, dripleaf in the shallows; the great chamber keeps its dripstone too, and
     * old bones lie by the water.
     */
    static void decorateMere(WorldGenLevel level, int x, int z, net.minecraft.util.RandomSource r, BlockPos.MutableBlockPos pos, boolean chamber, int top) {
        for (int y = 48; y < top; y++) {
            pos.set(x, y, z);
            var here = level.getBlockState(pos);
            if (!here.isAir()) continue;
            BlockPos up = pos.above(), down = pos.below();
            var above = level.getBlockState(up);
            var below = level.getBlockState(down);
            boolean roof = above.isSolidRender(level, up), floor = below.isSolidRender(level, down);
            boolean wetBeside = false;
            for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST})
                if (level.getFluidState(down.relative(d)).is(net.minecraft.tags.FluidTags.WATER)) wetBeside = true;
            if (roof) {
                float k = r.nextFloat();
                if (k < 0.13) vines(level, pos.immutable(), 1 + r.nextInt(5), r);
                else if (k < 0.145) level.setBlock(pos, Blocks.SPORE_BLOSSOM.defaultBlockState(), 2);
                else if (chamber && k < 0.24) {
                    if (r.nextFloat() < 0.5) level.setBlock(up, Blocks.DRIPSTONE_BLOCK.defaultBlockState(), 2);
                    hang(level, pos.immutable(), 1 + r.nextInt(r.nextFloat() < 0.3 ? 5 : 3), Direction.DOWN);
                } else if (r.nextFloat() < 0.35) level.setBlock(up, Blocks.MOSS_BLOCK.defaultBlockState(), 2);
                continue;
            }
            if (floor && level.getFluidState(pos).isEmpty()) {
                if (wetBeside && r.nextFloat() < 0.5) {
                    level.setBlock(down, Blocks.CLAY.defaultBlockState(), 2);
                    if (r.nextFloat() < 0.25) placeDripleaf(level, pos.immutable(), r);
                    continue;
                }
                if (r.nextFloat() < 0.75) level.setBlock(down, Blocks.MOSS_BLOCK.defaultBlockState(), 2);
                float k = r.nextFloat();
                if (k < 0.18) level.setBlock(pos, Blocks.MOSS_CARPET.defaultBlockState(), 2);
                else if (k < 0.22) level.setBlock(pos, Blocks.AZALEA.defaultBlockState(), 2);
                else if (k < 0.25) level.setBlock(pos, Blocks.FLOWERING_AZALEA.defaultBlockState(), 2);
                else if (k < 0.31) level.setBlock(pos, (r.nextBoolean() ? Blocks.GRASS : Blocks.FERN).defaultBlockState(), 2);
                else if (chamber && k < 0.345) {
                    if (r.nextFloat() < 0.6) level.setBlock(down, Blocks.DRIPSTONE_BLOCK.defaultBlockState(), 2);
                    hang(level, pos.immutable(), 1 + r.nextInt(3), Direction.UP);
                } else if (chamber && k < 0.355) {
                    level.setBlock(pos, Blocks.BONE_BLOCK.defaultBlockState().setValue(net.minecraft.world.level.block.RotatedPillarBlock.AXIS,
                            r.nextBoolean() ? Direction.Axis.X : Direction.Axis.Z), 2);
                }
            }
        }
        // glow lichen on the walls here and there
        for (int y = 52; y < top; y++) {
            pos.set(x, y, z);
            if (!level.getBlockState(pos).isAir() || r.nextFloat() > 0.025) continue;
            for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
                BlockPos w = pos.relative(d);
                if (level.getBlockState(w).isSolidRender(level, w)) {
                    level.setBlock(pos, Blocks.GLOW_LICHEN.defaultBlockState().setValue(net.minecraft.world.level.block.MultifaceBlock.getFaceProperty(d), true), 2);
                    break;
                }
            }
        }
    }

    /** Glow berry vines hanging down from pos, about half of them in fruit (and so alight). */
    private static void vines(WorldGenLevel level, BlockPos start, int len, net.minecraft.util.RandomSource r) {
        int n = 0;
        while (n < len && level.getBlockState(start.below(n)).isAir()) n++;
        for (int k = 0; k < n; k++) {
            boolean end = k == n - 1, berries = r.nextFloat() < 0.45;
            var st = end ? Blocks.CAVE_VINES.defaultBlockState().setValue(net.minecraft.world.level.block.CaveVines.BERRIES, berries)
                    : Blocks.CAVE_VINES_PLANT.defaultBlockState().setValue(net.minecraft.world.level.block.CaveVines.BERRIES, berries);
            level.setBlock(start.below(k), st, 2);
        }
    }

    /** Big dripleaf by the water: a stem or two, then the leaf. */
    private static void placeDripleaf(WorldGenLevel level, BlockPos pos, net.minecraft.util.RandomSource r) {
        Direction f = Direction.Plane.HORIZONTAL.getRandomDirection(r);
        int h = r.nextInt(3);
        for (int k = 0; k < h; k++) {
            if (!level.getBlockState(pos.above(k)).isAir()) return;
            level.setBlock(pos.above(k), Blocks.BIG_DRIPLEAF_STEM.defaultBlockState().setValue(net.minecraft.world.level.block.BigDripleafStemBlock.FACING, f), 2);
        }
        if (level.getBlockState(pos.above(h)).isAir())
            level.setBlock(pos.above(h), Blocks.BIG_DRIPLEAF.defaultBlockState().setValue(net.minecraft.world.level.block.BigDripleafBlock.FACING, f), 2);
    }

    /** A dripstone spike of the given length from pos, pointing the given way (each block's thickness set by hand). */
    private static void hang(WorldGenLevel level, BlockPos start, int len, Direction dir) {
        int n = 0;
        for (int k = 0; k < len; k++) {
            if (!level.getBlockState(start.relative(dir, k)).isAir() || !level.getFluidState(start.relative(dir, k)).isEmpty()) break;
            n++;
        }
        if (n == 0) return;
        for (int k = 0; k < n; k++) {
            var th = k == n - 1 ? net.minecraft.world.level.block.state.properties.DripstoneThickness.TIP
                    : k == n - 2 ? net.minecraft.world.level.block.state.properties.DripstoneThickness.FRUSTUM
                    : k == 0 ? net.minecraft.world.level.block.state.properties.DripstoneThickness.BASE
                    : net.minecraft.world.level.block.state.properties.DripstoneThickness.MIDDLE;
            level.setBlock(start.relative(dir, k), Blocks.POINTED_DRIPSTONE.defaultBlockState()
                    .setValue(net.minecraft.world.level.block.PointedDripstoneBlock.TIP_DIRECTION, dir)
                    .setValue(net.minecraft.world.level.block.PointedDripstoneBlock.THICKNESS, th), 2);
        }
    }
}
