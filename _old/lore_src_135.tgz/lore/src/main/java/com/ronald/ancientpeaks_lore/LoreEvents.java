package com.ronald.ancientpeaks_lore;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

/** Game rules for the quest that live outside the entities. */
final class LoreEvents {
    private LoreEvents() {}
    /** The most one of Vortigern's blows can deal, before armour (6 hearts): he must never one-shot a well-armed player. */
    static final float MAX_BLOW = 12.0f;

    static void register() {
        MinecraftForge.EVENT_BUS.addListener((LivingHurtEvent e) -> {
            if (e.getSource().getEntity() instanceof Vortigern && e.getAmount() > MAX_BLOW) e.setAmount(MAX_BLOW);
        });
        // nobody can be hurt while a cutscene is playing for them
        MinecraftForge.EVENT_BUS.addListener((LivingAttackEvent e) -> {
            if (e.getEntity().getTags().contains(LoreNet.IN_CUTSCENE)) e.setCanceled(true);
        });
        // a cutscene cut short by leaving the game doesn't leave you untouchable
        MinecraftForge.EVENT_BUS.addListener((PlayerEvent.PlayerLoggedInEvent e) -> e.getEntity().removeTag(LoreNet.IN_CUTSCENE));
    }
}
