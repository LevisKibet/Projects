package com.ronald.ancientpeaks_lore;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;

import java.util.List;

/** The sword of kings: a little better than netherite, never burns, and the only blade that bites Vortigern fully. */
public class ExcaliburItem extends SwordItem {
    static final Tier TIER = new Tier() {
        @Override public int getUses() { return 3000; }
        @Override public float getSpeed() { return 9.0f; }
        @Override public float getAttackDamageBonus() { return 5.0f; }
        @Override public int getLevel() { return 4; }
        @Override public int getEnchantmentValue() { return 22; }
        @Override public Ingredient getRepairIngredient() { return Ingredient.of(Items.NETHERITE_INGOT); }
    };

    public ExcaliburItem() {
        super(TIER, 4, -2.4f, new Item.Properties().rarity(Rarity.EPIC).fireResistant());
    }

    @Override public boolean isFoil(ItemStack stack) { return true; }

    /** Held, the blade sheds a faint light: now and then a mote of white fire drifts off it. */
    @Override
    public void inventoryTick(ItemStack stack, Level level, net.minecraft.world.entity.Entity holder, int slot, boolean selected) {
        if (!level.isClientSide || !(holder instanceof net.minecraft.world.entity.LivingEntity le)) return;
        boolean held = le.getMainHandItem() == stack || le.getOffhandItem() == stack;
        if (!held || level.random.nextInt(3) != 0) return;
        float yaw = le.yBodyRot * ((float) Math.PI / 180f);
        double side = le.getMainHandItem() == stack ? -0.38 : 0.38;
        double x = le.getX() + Math.cos(yaw) * side * (le.getMainArm() == net.minecraft.world.entity.HumanoidArm.RIGHT ? 1 : -1);
        double z = le.getZ() + Math.sin(yaw) * side * (le.getMainArm() == net.minecraft.world.entity.HumanoidArm.RIGHT ? 1 : -1);
        double y = le.getY() + le.getBbHeight() * 0.45 + level.random.nextDouble() * 0.8;
        level.addParticle(level.random.nextInt(4) == 0 ? net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK : net.minecraft.core.particles.ParticleTypes.END_ROD,
                x + (level.random.nextDouble() - 0.5) * 0.3, y, z + (level.random.nextDouble() - 0.5) * 0.3, 0, 0.01, 0);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.literal("Drawn from the stone on the high meadow.").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tip.add(Component.literal("Full damage against the usurper.").withStyle(ChatFormatting.GOLD));
        tip.add(Component.literal("Judgement of Avalon: lightning strikes twice every foe you wounded in the last minute.").withStyle(ChatFormatting.AQUA));
    }
}
