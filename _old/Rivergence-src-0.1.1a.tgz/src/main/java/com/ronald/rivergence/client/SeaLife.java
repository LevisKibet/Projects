package com.ronald.rivergence.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.ronald.rivergence.Rivergence;
import com.ronald.rivergence.RivergenceConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * More life in the sea, drawn only on this screen like the schools of fish: drifting clusters of glowing jellyfish over
 * coral reefs; and, very rarely in the deep cold seas, two sightings - a great dark shape far off in the gloom that
 * lifts its head to look at you before turning and sliding away into the deep, and a big tuna that tears past you.
 */
@Mod.EventBusSubscriber(modid = Rivergence.MODID, value = Dist.CLIENT)
public final class SeaLife {
    private SeaLife() {}

    private static final ResourceLocation TEX = new ResourceLocation(Rivergence.MODID, "textures/misc/fish.png");
    private static final Random RND = new Random();
    /** For testing: sightings on demand. */
    static boolean forceSerpent, forceTuna;

    // ------------------------------------------------------------------ jellyfish

    static final class Jelly {
        float x, y, z, px, py, pz, vx, vy, vz;
        float size, phase, rate;
        int r, g, b, cr, cg, cb;
        int strands;
    }

    static final class Bloom {
        double cx, cz;
        int floorY, topY;
        float alpha, palpha;
        boolean leaving;
        Jelly[] jellies;
    }

    private static final List<Bloom> blooms = new ArrayList<>();

    // ------------------------------------------------------------------ the deep: a sea serpent's shadow, a tuna

    static final class Serpent {
        final List<float[]> path = new ArrayList<>();     // head first, a block apart
        float hx, hy, hz, yaw, pitch, speed, lift;
        int age, seenAt = -1;
        float alpha, palpha, eyes, peyes;
    }

    static final class Tuna {
        float x, y, z, px, py, pz, dx, dy, dz, speed, yaw, turn, beat, pyaw;
        int age, life;
        float alpha, palpha;
    }

    private static Serpent serpent;
    private static final List<Tuna> tunas = new ArrayList<>();
    private static long serpentRest, tunaRest;
    private static ClientLevel lastLevel;
    private static int clock;

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        Player p = mc.player;
        if (level != lastLevel) { blooms.clear(); serpent = null; tunas.clear(); lastLevel = level; }
        if (level == null || p == null || mc.isPaused()) return;
        if (!RivergenceConfig.schools()) { blooms.clear(); serpent = null; tunas.clear(); return; }
        clock++;
        if (clock % 40 == 7) tryBloom(level, p);
        for (int i = blooms.size() - 1; i >= 0; i--) {
            Bloom b = blooms.get(i);
            updateBloom(p, b);
            if (b.leaving && b.alpha <= 0) blooms.remove(i);
        }
        boolean deepCold = clock % 20 == 0 && deepCold(level, p);
        if (serpent == null && (forceSerpent || deepCold && clock > serpentRest && clock % 200 == 0 && RND.nextInt(45) == 0)) {
            forceSerpent = false;
            spawnSerpent(level, p);
        }
        // a few tuna tearing past: a one-in-ten chance every half minute out there, then a few minutes' rest
        if (tunas.isEmpty() && (forceTuna || deepCold && clock > tunaRest && clock % 600 == 0 && RND.nextInt(10) == 0)) {
            forceTuna = false;
            spawnTuna(p);
        }
        if (serpent != null && updateSerpent(p)) { serpent = null; serpentRest = clock + 20 * 60 * 15; }
        if (!tunas.isEmpty()) {
            tunas.removeIf(SeaLife::updateTuna);
            if (tunas.isEmpty()) tunaRest = clock + 20 * 60 * 4;
        }
    }

    /** Swimming in a cold or frozen sea with deep water under you. */
    private static boolean deepCold(ClientLevel level, Player p) {
        if (!p.isEyeInFluid(FluidTags.WATER)) return false;
        BlockPos at = p.blockPosition();
        String id = level.getBiome(at).unwrapKey().map(k -> k.location().getPath()).orElse("");
        if (!(id.contains("frozen") || id.contains("cold")) || !id.contains("ocean")) return false;
        int d = 0;
        BlockPos.MutableBlockPos m = at.mutable();
        while (d < 40 && level.getFluidState(m.move(0, -1, 0)).is(FluidTags.WATER)) d++;
        return d >= 10 || id.contains("deep");
    }

    // ---- jellyfish over reefs

    private static void tryBloom(ClientLevel level, Player p) {
        if (blooms.size() >= 3) return;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int attempt = 0; attempt < 3; attempt++) {
            double a = RND.nextDouble() * Math.PI * 2, d = 18 + RND.nextDouble() * 30;
            int x = Mth.floor(p.getX() + Math.cos(a) * d), z = Mth.floor(p.getZ() + Math.sin(a) * d);
            int top = Integer.MIN_VALUE;
            for (int y = Mth.floor(p.getY()) + 20; y >= Mth.floor(p.getY()) - 30; y--)
                if (level.getFluidState(m.set(x, y, z)).is(FluidTags.WATER)) { if (level.getFluidState(m.set(x, y + 1, z)).isEmpty()) top = y; break; }
            if (top == Integer.MIN_VALUE) continue;
            int floor = top;
            while (floor > top - 30 && level.getFluidState(m.set(x, floor - 1, z)).is(FluidTags.WATER)) floor--;
            if (top - floor < 5) continue;
            // a reef: coral on the bed round about
            int coral = 0;
            for (int dx = -4; dx <= 4; dx += 2) for (int dz = -4; dz <= 4; dz += 2) for (int dy = -1; dy <= 2; dy++) {
                var st = level.getBlockState(m.set(x + dx, floor + dy, z + dz));
                if (st.is(BlockTags.CORALS) || st.is(BlockTags.CORAL_BLOCKS) || st.is(BlockTags.WALL_CORALS)) coral++;
            }
            if (coral < 3) continue;
            boolean near = false;
            for (Bloom o : blooms) if (Math.hypot(o.cx - x, o.cz - z) < 20) near = true;
            if (near) continue;
            blooms.add(makeBloom(x, z, floor, top));
            return;
        }
    }

    /** Jellyfish colours as they come in the sea: amber, peach, pink, pale moon-jelly blue and white, violet. */
    private static final int[][] JELLY = {
            {235, 135, 60}, {245, 170, 110}, {235, 125, 200}, {245, 160, 215}, {150, 205, 245}, {175, 220, 250},
            {215, 225, 245}, {170, 140, 235}, {245, 205, 120}};

    static Bloom makeBloom(int x, int z, int floor, int top) {
        Bloom b = new Bloom();
        b.cx = x + 0.5; b.cz = z + 0.5; b.floorY = floor; b.topY = top;
        // a drift of many small ones, mostly up near the light; one or two colours lead, a few others among them
        int lead = RND.nextInt(JELLY.length), second = RND.nextInt(JELLY.length);
        int n = 20 + RND.nextInt(26);
        b.jellies = new Jelly[n];
        for (int i = 0; i < n; i++) {
            Jelly j = new Jelly();
            double a = RND.nextDouble() * Math.PI * 2, r = Math.sqrt(RND.nextDouble()) * 7;
            j.x = j.px = (float) (b.cx + Math.cos(a) * r);
            j.z = j.pz = (float) (b.cz + Math.sin(a) * r);
            float deep = RND.nextFloat();
            j.y = j.py = Math.max(floor + 1.5f, top - 0.7f - deep * deep * Math.min(5, top - floor - 1.5f));
            float big = RND.nextFloat();
            j.size = 0.18f + big * big * 0.32f;
            j.phase = RND.nextFloat() * 6.283f;
            j.rate = 0.08f + RND.nextFloat() * 0.05f;
            j.strands = 4;
            float pick = RND.nextFloat();
            int[] c = JELLY[pick < 0.55f ? lead : pick < 0.8f ? second : RND.nextInt(JELLY.length)];
            float v = 0.9f + RND.nextFloat() * 0.15f;
            j.r = Math.min(255, (int) (c[0] * v)); j.g = Math.min(255, (int) (c[1] * v)); j.b = Math.min(255, (int) (c[2] * v));
            // the rim and heart glow paler and brighter
            j.cr = Math.min(255, j.r + 40); j.cg = Math.min(255, j.g + 50); j.cb = Math.min(255, j.b + 40);
            b.jellies[i] = j;
        }
        return b;
    }

    private static void updateBloom(Player p, Bloom b) {
        b.palpha = b.alpha;
        if (Math.hypot(b.cx - p.getX(), b.cz - p.getZ()) > 80) b.leaving = true;
        b.alpha = Mth.clamp(b.alpha + (b.leaving ? -0.04f : 0.02f), 0, 1);
        for (Jelly j : b.jellies) {
            j.px = j.x; j.py = j.y; j.pz = j.z;
            j.phase += j.rate;
            // each beat of the bell lifts it a little; between beats it sinks slowly
            float beat = Math.max(0, Mth.sin(j.phase));
            j.vy = j.vy * 0.9f + beat * 0.006f - 0.0022f;
            j.vx = j.vx * 0.96f + (RND.nextFloat() - 0.5f) * 0.002f;
            j.vz = j.vz * 0.96f + (RND.nextFloat() - 0.5f) * 0.002f;
            // drifting gently aside from a swimmer
            double qx = j.x - p.getX(), qy = j.y - p.getEyeY(), qz = j.z - p.getZ(), qd = Math.sqrt(qx * qx + qy * qy + qz * qz);
            if (qd < 2.5 && qd > 1e-3) { j.vx += qx / qd * 0.004f; j.vy += qy / qd * 0.003f; j.vz += qz / qd * 0.004f; }
            // kept loosely together over the reef
            j.vx += (float) (b.cx - j.x) * 0.00015f; j.vz += (float) (b.cz - j.z) * 0.00015f;
            j.x += j.vx; j.z += j.vz;
            j.y = Mth.clamp(j.y + j.vy, b.floorY + 1.5f, b.topY - 0.25f - j.size * 0.6f);
        }
    }

    // ---- the serpent's shadow

    private static final int SPINE = 90;

    /**
     * The leviathan: out at the very edge of what you can see, where the water's own murk nearly swallows it. It lies
     * there, barely moving, eyes shut, until you look its way; then its great eyes open, it lifts its head and watches
     * you a while, and turns and goes down into the deep. If you never look, it slips away unseen.
     */
    private static void spawnSerpent(ClientLevel level, Player p) {
        Serpent s = new Serpent();
        float fogEnd = RenderSystem.getShaderFogEnd();
        float d = devDist > 0 ? devDist : Mth.clamp(fogEnd * 0.8f, 30, 150);
        float look = p.getYRot() * Mth.DEG_TO_RAD;
        float a = devDist > 0 ? look : look + (RND.nextFloat() - 0.5f) * 2.0f;   // somewhere ahead or off to one side
        s.hx = (float) (p.getX() - Mth.sin(a) * d);
        s.hz = (float) (p.getZ() + Mth.cos(a) * d);
        s.hy = (float) (devDist > 0 ? p.getEyeY() - 0.3 : p.getEyeY() - 2 - RND.nextFloat() * 5);
        // well under the surface, with room for the head to lift
        for (int k = 0; k < 12 && !level.getFluidState(BlockPos.containing(s.hx, s.hy + 5, s.hz)).is(FluidTags.WATER); k++) s.hy -= 1;
        s.yaw = (float) Math.atan2(p.getZ() - s.hz, p.getX() - s.hx) + (devDist > 0 ? 0.9f : (RND.nextFloat() - 0.5f) * 1.2f);
        float bx = -Mth.cos(s.yaw), bz = -Mth.sin(s.yaw);
        float side = RND.nextBoolean() ? 1 : -1;
        float x = s.hx, y = s.hy, z = s.hz;
        for (int i = 0; i < SPINE; i++) {
            s.path.add(new float[]{x, y, z});
            float curve = Mth.sin(i * 0.07f) * 0.8f * side;
            float dx = bx * Mth.cos(curve) - bz * Mth.sin(curve), dz = bz * Mth.cos(curve) + bx * Mth.sin(curve);
            x += dx; z += dz;
            y -= i < 8 ? 0.05f : 0.18f;                                    // the long body falling away into the dark below
        }
        serpent = s;
    }

    /** True when it's gone. */
    private static boolean updateSerpent(Player p) {
        Serpent s = serpent;
        s.age++;
        s.palpha = s.alpha; s.peyes = s.eyes;
        Vec3 eye = p.getEyePosition();
        double tx = s.hx - eye.x, ty = s.hy - eye.y, tz = s.hz - eye.z, td = Math.sqrt(tx * tx + ty * ty + tz * tz);
        if (s.seenAt < 0) {
            // waiting, all but still in the murk, for you to look its way
            s.alpha = Math.min(1, s.alpha + 0.02f);
            s.path.get(0)[1] = s.hy + Mth.sin(s.age * 0.02f) * 0.2f;
            Vec3 look = p.getLookAngle();
            boolean seen = (look.x * tx + look.y * ty + look.z * tz) / td > 0.93 && td < RenderSystem.getShaderFogEnd() + 8;
            if (seen && s.alpha > 0.5f) s.seenAt = s.age;
            else if (s.age > 20 * 40) { s.alpha -= 0.03f; return s.alpha <= 0; }        // never noticed: it slips away
            return false;
        }
        int since = s.age - s.seenAt;
        if (since < 90) {
            // its eyes open, the head lifts and turns to follow you
            s.eyes = Math.min(1, s.eyes + 0.06f);
            s.alpha = Math.min(1, s.alpha + 0.03f);
            s.lift = Math.min(2.5f, s.lift + 0.04f);
            float want = (float) Math.atan2(eye.z - s.hz, eye.x - s.hx);
            s.yaw += Mth.clamp(Mth.wrapDegrees((want - s.yaw) * Mth.RAD_TO_DEG) * Mth.DEG_TO_RAD, -0.015f, 0.015f);
            s.path.get(0)[1] = s.hy + s.lift;
            s.path.get(1)[1] = s.hy + s.lift * 0.7f;
            s.path.get(2)[1] = s.hy + s.lift * 0.35f;
            // the head turned toward you
            float[] h0 = s.path.get(0), h1 = s.path.get(1);
            h0[0] = h1[0] + Mth.cos(s.yaw); h0[2] = h1[2] + Mth.sin(s.yaw);
            return false;
        }
        // then it turns away and goes down, the body following the way the head went
        float away = (float) Math.atan2(s.hz - eye.z, s.hx - eye.x);
        s.yaw += Mth.clamp(Mth.wrapDegrees((away - s.yaw) * Mth.RAD_TO_DEG) * Mth.DEG_TO_RAD, -0.07f, 0.07f);
        s.pitch = Math.max(-0.8f, s.pitch - 0.015f);
        s.speed = Math.min(0.9f, s.speed + 0.025f);
        s.eyes = Math.max(0, s.eyes - 0.04f);
        float[] head = s.path.get(0);
        float nx = head[0] + Mth.cos(s.yaw) * Mth.cos(s.pitch) * s.speed, ny = head[1] + Mth.sin(s.pitch) * s.speed, nz = head[2] + Mth.sin(s.yaw) * Mth.cos(s.pitch) * s.speed;
        head[0] = nx; head[1] = ny; head[2] = nz;
        float[] next = s.path.get(1);
        float mx = nx - next[0], my = ny - next[1], mz = nz - next[2];
        if (mx * mx + my * my + mz * mz >= 1f) { s.path.add(0, new float[]{nx, ny, nz}); s.path.remove(s.path.size() - 1); }
        s.hx = nx; s.hy = ny; s.hz = nz;
        if (since > 90 + 50) s.alpha -= 0.035f;
        return s.alpha <= 0;
    }

    // ---- the tuna

    /** One to three of them together, out of the murk on one side, sweeping past a few blocks ahead, gone into the other. */
    private static void spawnTuna(Player p) {
        Vec3 look = p.getLookAngle();
        double lx = look.x, lz = look.z, ll = Math.sqrt(lx * lx + lz * lz);
        if (ll < 1e-3) { lx = 1; lz = 0; ll = 1; }
        lx /= ll; lz /= ll;
        double sx = -lz, sz = lx, dir = RND.nextBoolean() ? 1 : -1;
        double ahead = 5 + RND.nextDouble() * 4;
        float turn = (RND.nextFloat() - 0.5f) * 0.012f;
        float speed = 1.1f + RND.nextFloat() * 0.35f;
        int n = 1 + RND.nextInt(3);
        for (int i = 0; i < n; i++) {
            Tuna t = new Tuna();
            double back = i * (2.5 + RND.nextDouble() * 2), off = i == 0 ? 0 : (RND.nextDouble() - 0.5) * 3;
            t.x = t.px = (float) (p.getX() + lx * (ahead + off) - sx * dir * (34 + back));
            t.z = t.pz = (float) (p.getZ() + lz * (ahead + off) - sz * dir * (34 + back));
            t.y = t.py = (float) (p.getEyeY() - 0.8 + RND.nextDouble() * 1.6 + i * 0.4);
            t.yaw = t.pyaw = (float) Math.atan2(sz * dir, sx * dir) - turn * 30;  // aimed so the curve brings it across in front of you
            t.turn = turn;
            t.speed = speed * (0.95f + RND.nextFloat() * 0.1f);
            t.beat = RND.nextFloat() * 6;
            t.life = (int) ((68 + back) / t.speed) + 6;
            tunas.add(t);
        }
    }

    private static boolean updateTuna(Tuna t) {
        t.age++;
        t.px = t.x; t.py = t.y; t.pz = t.z; t.palpha = t.alpha; t.pyaw = t.yaw;
        // a long sweeping curve, the body rolling from side to side with every fast beat of the tail
        t.yaw += t.turn;
        t.dx = Mth.cos(t.yaw); t.dz = Mth.sin(t.yaw);
        float surge = 1 + 0.08f * Mth.sin(t.age * 0.9f + t.beat);
        t.x += t.dx * t.speed * surge; t.z += t.dz * t.speed * surge;
        t.y += Mth.sin(t.age * 0.25f + t.beat) * 0.02f;
        t.alpha = t.age < 8 ? t.age / 8f : t.age > t.life - 8 ? Math.max(0, (t.life - t.age) / 8f) : 1;
        return t.age >= t.life;
    }

    // ------------------------------------------------------------------ drawing

    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_CUTOUT_BLOCKS) return;
        if (blooms.isEmpty() && serpent == null && tunas.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        float pt = e.getPartialTick();
        Vec3 cam = e.getCamera().getPosition();
        Matrix4f mat = e.getPoseStack().last().pose();
        RenderSystem.setShader(GameRenderer::getParticleShader);
        RenderSystem.setShaderTexture(0, TEX);
        mc.gameRenderer.lightTexture().turnOnLightLayer();
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        BufferBuilder bb = Tesselator.getInstance().getBuilder();

        // solid bodies first (they hide what's behind them)
        if (serpent != null || !tunas.isEmpty()) {
            RenderSystem.depthMask(true);
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
            if (serpent != null) drawSerpent(bb, mat, cam, pt, level);
            for (Tuna t : tunas) drawTuna(bb, mat, cam, pt, level, t);
            BufferUploader.drawWithShader(bb.end());
        }
        // the jellyfish: see-through and glowing, so drawn without hiding one another
        if (!blooms.isEmpty()) {
            RenderSystem.depthMask(false);
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
            int n = 0;
            for (Bloom b : blooms) {
                float a = Mth.lerp(pt, b.palpha, b.alpha);
                if (a <= 0.01f) continue;
                for (Jelly j : b.jellies) { drawJelly(bb, mat, cam, pt, j, a); n++; }
            }
            if (n > 0) BufferUploader.drawWithShader(bb.end()); else bb.end().release();
            RenderSystem.depthMask(true);
        }
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        mc.gameRenderer.lightTexture().turnOffLightLayer();
    }

    private static final float SU0 = 0.02f, SU1 = 0.1f, SV0 = 0.52f, SV1 = 0.98f;   // the plain white patch of the texture
    private static final int GLOW = 0xF000F0;

    private static void quad(BufferBuilder bb, Matrix4f m, float[] a, float[] b, float[] c, float[] d, int r, int g, int bl, int al, int light) {
        FishSchools.v(bb, m, a[0], a[1], a[2], SU0, SV0, r, g, bl, al, light);
        FishSchools.v(bb, m, b[0], b[1], b[2], SU1, SV0, r, g, bl, al, light);
        FishSchools.v(bb, m, c[0], c[1], c[2], SU1, SV1, r, g, bl, al, light);
        FishSchools.v(bb, m, d[0], d[1], d[2], SU0, SV1, r, g, bl, al, light);
    }

    private static void drawJelly(BufferBuilder bb, Matrix4f m, Vec3 cam, float pt, Jelly j, float fade) {
        float x = (float) (Mth.lerp(pt, j.px, j.x) - cam.x), y = (float) (Mth.lerp(pt, j.py, j.y) - cam.y), z = (float) (Mth.lerp(pt, j.pz, j.z) - cam.z);
        if (x * x + y * y + z * z > 64 * 64) return;
        float ph = j.phase + j.rate * pt;
        // a square bell that squeezes in and stretches tall with each beat, then eases out wide and low
        float beat = Mth.sin(ph);
        float half = j.size * 0.5f * (1 - 0.18f * beat), tall = j.size * 0.85f * (1 + 0.28f * beat);
        float rim = half * 0.82f;                                         // the bottom edge turned in a little
        float yt = y + tall * 0.55f, yb = y - tall * 0.45f;
        int A = (int) (fade * 155), AR = (int) (fade * 205);
        float[] t0 = {x - half, yt, z - half}, t1 = {x + half, yt, z - half}, t2 = {x + half, yt, z + half}, t3 = {x - half, yt, z + half};
        float[] b0 = {x - rim, yb, z - rim}, b1 = {x + rim, yb, z - rim}, b2 = {x + rim, yb, z + rim}, b3 = {x - rim, yb, z + rim};
        quad(bb, m, t0, t1, t2, t3, j.r, j.g, j.b, A, GLOW);                                        // top
        quad(bb, m, t0, t1, b1, b0, (int) (j.r * 0.9f), (int) (j.g * 0.9f), (int) (j.b * 0.9f), A, GLOW);
        quad(bb, m, t1, t2, b2, b1, (int) (j.r * 0.82f), (int) (j.g * 0.82f), (int) (j.b * 0.82f), A, GLOW);
        quad(bb, m, t2, t3, b3, b2, (int) (j.r * 0.9f), (int) (j.g * 0.9f), (int) (j.b * 0.9f), A, GLOW);
        quad(bb, m, t3, t0, b0, b3, (int) (j.r * 0.82f), (int) (j.g * 0.82f), (int) (j.b * 0.82f), A, GLOW);
        // a bright band round the rim, and the glowing heart inside
        float rb = yb + tall * 0.12f;
        float[] r0 = {x - rim * 1.02f, rb, z - rim * 1.02f}, r1 = {x + rim * 1.02f, rb, z - rim * 1.02f}, r2 = {x + rim * 1.02f, rb, z + rim * 1.02f}, r3 = {x - rim * 1.02f, rb, z + rim * 1.02f};
        float[] q0 = {x - rim * 1.02f, yb, z - rim * 1.02f}, q1 = {x + rim * 1.02f, yb, z - rim * 1.02f}, q2 = {x + rim * 1.02f, yb, z + rim * 1.02f}, q3 = {x - rim * 1.02f, yb, z + rim * 1.02f};
        quad(bb, m, r0, r1, q1, q0, j.cr, j.cg, j.cb, AR, GLOW);
        quad(bb, m, r1, r2, q2, q1, j.cr, j.cg, j.cb, AR, GLOW);
        quad(bb, m, r2, r3, q3, q2, j.cr, j.cg, j.cb, AR, GLOW);
        quad(bb, m, r3, r0, q0, q3, j.cr, j.cg, j.cb, AR, GLOW);
        float hc = half * 0.35f, hy = y + tall * 0.1f;
        quad(bb, m, new float[]{x - hc, hy, z - hc}, new float[]{x + hc, hy, z - hc}, new float[]{x + hc, hy, z + hc}, new float[]{x - hc, hy, z + hc}, j.cr, j.cg, j.cb, (int) (fade * 140), GLOW);
        // threads from the four corners and frilly arms from the middle, trailing behind the beat
        float len = j.size * 2.2f;
        float[][] roots = {{x - rim, z - rim}, {x + rim, z - rim}, {x + rim, z + rim}, {x - rim, z + rim}, {x - rim * 0.2f, z}, {x + rim * 0.2f, z}};
        for (int s2 = 0; s2 < roots.length; s2++) {
            boolean arm = s2 >= 4;
            float l = arm ? len * 0.6f : len * (0.85f + 0.25f * Mth.sin(s2 * 2.1f + j.size * 10));
            float w = arm ? j.size * 0.11f : j.size * 0.03f + 0.006f;
            float sx = roots[s2][0], sz = roots[s2][1];
            float px0 = sx, py0 = yb, pz0 = sz;
            for (int k = 1; k <= 5; k++) {
                float t = k / 5f;
                float sway = Mth.sin(ph * 0.9f - t * 3f + s2) * 0.1f * j.size * t;
                float px1 = sx + sway, pz1 = sz + sway * 0.6f, py1 = yb - l * t * (1 + 0.12f * beat);
                float vx = (px0 + px1) / 2, vy = (py0 + py1) / 2, vz = (pz0 + pz1) / 2;
                float dx = px1 - px0, dy = py1 - py0, dz = pz1 - pz0;
                float ox = dy * vz - dz * vy, oy = dz * vx - dx * vz, oz = dx * vy - dy * vx;
                float ol = Mth.sqrt(ox * ox + oy * oy + oz * oz);
                if (ol < 1e-5f) continue;
                float ww = w * (1 - t * 0.6f) / ol;
                ox *= ww; oy *= ww; oz *= ww;
                int al = (int) (fade * (arm ? 120 : 150) * (1 - t * 0.75f));
                int r = arm ? j.cr : j.r, g = arm ? j.cg : j.g, b = arm ? j.cb : j.b;
                quad(bb, m, new float[]{px0 - ox, py0 - oy, pz0 - oz}, new float[]{px0 + ox, py0 + oy, pz0 + oz},
                        new float[]{px1 + ox, py1 + oy, pz1 + oz}, new float[]{px1 - ox, py1 - oy, pz1 - oz}, r, g, b, al, GLOW);
                px0 = px1; py0 = py1; pz0 = pz1;
            }
        }
    }

    /**
     * A body along a spine (camera-relative points, head first): a four-sided section, wider than tall, the back in
     * one colour and the belly in another.
     */
    private static void tube(BufferBuilder bb, Matrix4f m, float[][] p, float[] w, float[] h, int[] back, int[] belly, int A, int light) {
        int n = p.length;
        float[][][] ring = new float[n][4][];
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - 1), b = Math.min(n - 1, i + 1);
            float tx = p[a][0] - p[b][0], ty = p[a][1] - p[b][1], tz = p[a][2] - p[b][2];
            float sx = -tz, sz = tx, sl = Mth.sqrt(sx * sx + sz * sz);
            if (sl < 1e-5f) { sx = 1; sz = 0; sl = 1; }
            sx /= sl; sz /= sl;
            // up: square to the spine and the side
            float ux = -sz * ty, uy = sz * tx - sx * tz, uz = sx * ty;
            float ul = Mth.sqrt(ux * ux + uy * uy + uz * uz);
            if (ul < 1e-5f) { ux = 0; uy = 1; uz = 0; ul = 1; }
            ux /= ul; uy /= ul; uz /= ul;
            if (uy < 0) { ux = -ux; uy = -uy; uz = -uz; }
            float[] c = p[i];
            ring[i][0] = new float[]{c[0] + sx * w[i], c[1], c[2] + sz * w[i]};
            ring[i][1] = new float[]{c[0] + ux * h[i], c[1] + uy * h[i], c[2] + uz * h[i]};
            ring[i][2] = new float[]{c[0] - sx * w[i], c[1], c[2] - sz * w[i]};
            ring[i][3] = new float[]{c[0] - ux * h[i] * 0.85f, c[1] - uy * h[i] * 0.85f, c[2] - uz * h[i] * 0.85f};
        }
        for (int i = 0; i + 1 < n; i++) for (int q = 0; q < 4; q++) {
            int q2 = (q + 1) % 4;
            int[] c = q < 2 ? back : belly;
            float sh = q == 0 || q == 3 ? 0.85f : 1;
            quad(bb, m, ring[i][q], ring[i + 1][q], ring[i + 1][q2], ring[i][q2], (int) (c[0] * sh), (int) (c[1] * sh), (int) (c[2] * sh), A, light);
        }
    }

    private static void drawSerpent(BufferBuilder bb, Matrix4f m, Vec3 cam, float pt, ClientLevel level) {
        Serpent s = serpent;
        float a = Mth.lerp(pt, s.palpha, s.alpha);
        if (a <= 0.01f) return;
        int n = Math.min(s.path.size(), SPINE);
        float[][] p = new float[n][];
        float[] w = new float[n], h = new float[n];
        float t = s.age + pt;
        for (int i = 0; i < n; i++) {
            float[] q = s.path.get(i);
            float u = i / (float) (n - 1);
            float rip = Mth.sin(t * 0.04f - i * 0.12f) * 0.6f * u;      // a slow swell travelling down it
            p[i] = new float[]{(float) (q[0] - cam.x) + rip * Mth.sin(s.yaw), (float) (q[1] - cam.y), (float) (q[2] - cam.z) - rip * Mth.cos(s.yaw)};
            // a great blunt head, a thick neck, the bulk of the body, then a long taper
            float prof = u < 0.03f ? 0.8f + u / 0.03f * 0.2f : u < 0.08f ? 1 - (u - 0.03f) / 0.05f * 0.2f : u < 0.3f ? 0.8f + (u - 0.08f) / 0.22f * 0.4f : 1.2f * (1 - (u - 0.3f) / 0.7f) + 0.06f;
            w[i] = 3.0f * prof; h[i] = 2.3f * prof;
        }
        int light = LevelRenderer.getLightColor(level, BlockPos.containing(s.hx, s.hy, s.hz));
        int A = (int) (a * 245);
        int[] back = {10, 16, 22}, belly = {22, 30, 36};
        tube(bb, m, p, w, h, back, belly, A, light);
        // a ridge of spines down its back
        for (int i = 6; i + 2 < n * 0.8f; i += 4) {
            float[] c0 = p[i], c1 = p[i + 2];
            float s0 = h[i], s1 = h[i + 2];
            quad(bb, m, new float[]{c0[0], c0[1] + s0, c0[2]}, new float[]{c0[0], c0[1] + s0 * 1.7f, c0[2]},
                    new float[]{c1[0], c1[1] + s1 * 1.05f, c1[2]}, new float[]{c1[0], c1[1] + s1, c1[2]}, 8, 12, 18, A, light);
        }
        // the eyes: huge and pale, glowing out of the dark, opening as it notices you
        float open = Mth.lerp(pt, s.peyes, s.eyes);
        if (open > 0.02f && n > 3) {
            float[] hd = p[0], nk = p[3];
            float fx = hd[0] - nk[0], fy = hd[1] - nk[1], fz = hd[2] - nk[2], fl = Mth.sqrt(fx * fx + fy * fy + fz * fz);
            if (fl > 1e-4f) {
                fx /= fl; fy /= fl; fz /= fl;
                float sx = -fz, sz = fx, sl = Mth.sqrt(sx * sx + sz * sz);
                sx /= sl; sz /= sl;
                for (int side = -1; side <= 1; side += 2) {
                    float ex = hd[0] - fx * 0.6f + sx * side * w[0] * 0.75f, ey = hd[1] + h[0] * 0.45f, ez = hd[2] - fz * 0.6f + sz * side * w[0] * 0.75f;
                    // turned to face you
                    float vx = ex, vy = ey, vz = ez, vl = Mth.sqrt(vx * vx + vy * vy + vz * vz);
                    float rx = -vz / vl, rz = vx / vl, rl = Mth.sqrt(rx * rx + rz * rz);
                    if (rl < 1e-4f) continue;
                    rx /= rl; rz /= rl;
                    float ux = -rz * vy / vl, uy = rz * vx / vl - rx * vz / vl, uz = rx * vy / vl;
                    float ul = Mth.sqrt(ux * ux + uy * uy + uz * uz);
                    ux /= ul; uy /= ul; uz /= ul;
                    if (uy < 0) { ux = -ux; uy = -uy; uz = -uz; }
                    float ew = 0.75f, eh = 0.55f * open;
                    int al = (int) (a * Math.min(1, open * 1.3f) * 255);
                    // pull them a little toward you so the head doesn't hide them
                    float px = ex - vx / vl * 0.4f, py = ey - vy / vl * 0.4f, pz = ez - vz / vl * 0.4f;
                    eyeQuad(bb, m, px, py, pz, rx, rz, ux, uy, uz, ew, eh, 235, 228, 150, al);
                    // a dark slit of a pupil
                    eyeQuad(bb, m, px - vx / vl * 0.05f, py - vy / vl * 0.05f, pz - vz / vl * 0.05f, rx, rz, ux, uy, uz, 0.12f, eh * 0.9f, 20, 18, 10, al);
                }
            }
        }
    }

    private static void eyeQuad(BufferBuilder bb, Matrix4f m, float x, float y, float z, float rx, float rz, float ux, float uy, float uz, float w, float h, int r, int g, int b, int a) {
        quad(bb, m, new float[]{x - rx * w - ux * h, y - uy * h, z - rz * w - uz * h}, new float[]{x + rx * w - ux * h, y - uy * h, z + rz * w - uz * h},
                new float[]{x + rx * w + ux * h, y + uy * h, z + rz * w + uz * h}, new float[]{x - rx * w + ux * h, y + uy * h, z - rz * w + uz * h}, r, g, b, a, GLOW);
    }

    private static void drawTuna(BufferBuilder bb, Matrix4f m, Vec3 cam, float pt, ClientLevel level, Tuna t) {
        float a = Mth.lerp(pt, t.palpha, t.alpha);
        if (a <= 0.01f) return;
        float x = (float) (Mth.lerp(pt, t.px, t.x) - cam.x), y = (float) (Mth.lerp(pt, t.py, t.y) - cam.y), z = (float) (Mth.lerp(pt, t.pz, t.z) - cam.z);
        final int N = 10;
        float L = 2.4f;
        float sx = -t.dz, sz = t.dx;
        float[][] p = new float[N + 1][];
        float[] w = new float[N + 1], h = new float[N + 1];
        float time = t.age + pt;
        for (int i = 0; i <= N; i++) {
            float u = i / (float) N;
            // a tuna swims with its tail: the front stays stiff, the back half sweeps hard and fast; the body bends a
            // little into the curve it's following
            float back = u * L - L * 0.5f;
            float wig = Mth.sin(time * 2.4f + t.beat - u * 2.2f) * 0.2f * u * u * u - t.turn / t.speed * back * back * 0.5f;
            float roll = Mth.sin(time * 2.4f + t.beat) * 0.03f;
            p[i] = new float[]{x + t.dx * (L * 0.5f - u * L) + sx * wig, y + roll * (1 - u), z + t.dz * (L * 0.5f - u * L) + sz * wig};
            // a torpedo: blunt nose, deepest a third back, a thin wrist before the tail
            float prof = u < 0.3f ? 0.45f + 0.55f * Mth.sqrt(u / 0.3f) : 1 - (u - 0.3f) / 0.7f * 0.92f;
            w[i] = 0.3f * prof; h[i] = 0.38f * prof;
        }
        int light = LevelRenderer.getLightColor(level, BlockPos.containing(t.x, t.y, t.z));
        int A = (int) (a * 255);
        tube(bb, m, p, w, h, new int[]{28, 44, 86}, new int[]{205, 212, 222}, A, light);
        // the sickle tail: two swept lobes
        float[] tw = p[N];
        float bx = -t.dx, bz = -t.dz;
        float sw = Mth.sin(time * 2.4f + t.beat - 2.2f) * 0.22f;
        float[] tip1 = {tw[0] + bx * 0.45f + sx * sw, tw[1] + 0.55f, tw[2] + bz * 0.45f + sz * sw};
        float[] tip2 = {tw[0] + bx * 0.45f + sx * sw, tw[1] - 0.55f, tw[2] + bz * 0.45f + sz * sw};
        float[] mid = {tw[0] + bx * 0.22f + sx * sw * 0.5f, tw[1], tw[2] + bz * 0.22f + sz * sw * 0.5f};
        quad(bb, m, tw, tip1, mid, tw, 40, 55, 95, A, light);
        quad(bb, m, tw, mid, tip2, tw, 40, 55, 95, A, light);
        // a dorsal fin and yellow finlets toward the tail
        float[] d0 = p[3], d1 = p[5];
        quad(bb, m, new float[]{d0[0], d0[1] + h[3], d0[2]}, new float[]{d0[0], d0[1] + h[3] + 0.22f, d0[2]},
                new float[]{d1[0], d1[1] + h[5] + 0.08f, d1[2]}, new float[]{d1[0], d1[1] + h[5], d1[2]}, 32, 48, 90, A, light);
        for (int i = 6; i <= 8; i++) {
            float[] f = p[i];
            quad(bb, m, new float[]{f[0], f[1] + h[i], f[2]}, new float[]{f[0], f[1] + h[i] + 0.09f, f[2]},
                    new float[]{f[0] + bx * 0.08f, f[1] + h[i] + 0.05f, f[2] + bz * 0.08f}, new float[]{f[0] + bx * 0.08f, f[1] + h[i], f[2] + bz * 0.08f}, 240, 210, 40, A, light);
            quad(bb, m, new float[]{f[0], f[1] - h[i] * 0.85f, f[2]}, new float[]{f[0], f[1] - h[i] * 0.85f - 0.09f, f[2]},
                    new float[]{f[0] + bx * 0.08f, f[1] - h[i] * 0.85f - 0.05f, f[2] + bz * 0.08f}, new float[]{f[0] + bx * 0.08f, f[1] - h[i] * 0.85f, f[2] + bz * 0.08f}, 240, 210, 40, A, light);
        }
    }

    // ------------------------------------------------------------------ testing

    public static void devBloom(int x, int z, int floor, int top) { Bloom b = makeBloom(x, z, floor, top); b.alpha = b.palpha = 1; blooms.add(b); }
    public static String devInfo() {
        return "blooms " + blooms.size() + (serpent == null ? " no serpent" : String.format(" serpent %.1f,%.1f,%.1f a%.2f age%d path%d", serpent.hx, serpent.hy, serpent.hz, serpent.alpha, serpent.age, serpent.path.size()))
                + (tunas.isEmpty() ? " no tuna" : String.format(" %d tuna %.1f,%.1f,%.1f", tunas.size(), tunas.get(0).x, tunas.get(0).y, tunas.get(0).z));
    }
    public static float devDist = 0;
    public static void devSerpent(float d) { devDist = d; forceSerpent = true; }
    public static void devTuna() { forceTuna = true; }
}
