Put merlin.ogg and vortigern.ogg here (Ogg Vorbis).
