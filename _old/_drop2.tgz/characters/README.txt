ANCIENT PEAKS LORE - CHARACTERS
===============================
The game reads this folder while you test (F3+T reloads it). Files starting with "_" are ignored.

MERLIN  (GeckoLib model, one animation)
  characters/merlin/merlin.geo.json          the model (player-skin layout, 64x64)
  characters/merlin/merlin.animation.json    ONE animation: "injured_leaning" (loop) - slumped against a chapel wall
  characters/merlin/merlin.png               his skin
  He is placed with his back to a wall, facing the room. Heal him (golden apple / potion of healing) and his
  cutscene plays (20 s); he gives you his map to the gateway and vanishes in light.

VORTIGERN  (Epic Fight humanoid)
  characters/vortigern/vortigern.png                 his skin (64x64 player-skin layout)
  characters/vortigern_statue/vortigern_statue.png   his stone form, frozen reaching for the sword (same layout)
  Moveset: Epic Fight longsword, Liechtenauer stance (data/ancientpeaks_lore/epicfight_mobpatch/vortigern.json).
  His blows are capped at 6 hearts before armour.

SHADES  (his phase-two summons - vexes)
  characters/saxon_shade/saxon_shade.png   (vex layout)     saxon_shade_charging.png when it lunges

ITEMS   items/excalibur.png  items/crown_of_vortigern.png (16x16 icons)   items/crown_layer_1.png (crown as worn)

MUSIC   music/merlin.ogg  music/vortigern.ogg  - the cutscene music. Must be Ogg Vorbis (send me any format and I
        will convert it). Merlin's scene is 20 s long, Vortigern's 16 s; longer tracks are cut off at the end.

CUTSCENES (lines and camera shots live in the mod: client/Cutscenes.java)
  merlin     20 s: push-in from the floor -> close on his face -> over his shoulder -> pull away as he fades
  vortigern  16 s: low orbit as the stone cracks -> tight on the stone face -> he breaks free, pull back -> wide shot
