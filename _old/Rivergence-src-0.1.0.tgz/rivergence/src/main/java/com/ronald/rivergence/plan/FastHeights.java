package com.ronald.rivergence.plan;

import net.minecraft.world.level.levelgen.DensityFunction;
import net.minecraft.world.level.levelgen.RandomState;

/**
 * A quick estimate of the land's surface height, for planning where water goes: the terrain's own shaping function
 * before its fine jagged detail (the part the game itself uses to judge heights early), searched top-down for where
 * the ground begins. Works with whatever terrain the world uses (vanilla, Terralith, Tectonic) because it asks the
 * world's own function.
 */
public final class FastHeights implements Drainage.Heights {
    private final DensityFunction f;
    private final int minY, maxY;

    public FastHeights(RandomState rs, int minY, int maxY) {
        this.f = rs.router().initialDensityWithoutJaggedness();
        this.minY = minY; this.maxY = maxY;
    }

    /** Where the last search ended: neighbouring columns are close, so the next search starts there. */
    private int last = 80;

    @Override
    public double at(int x, int z) {
        int step = 8, y = Math.max(minY + 8, Math.min(maxY - 8, last));
        // step up while it's ground, or down while it's air, until the surface lies between y and y + step
        if (d(x, y, z) > 0) {
            while (y + step < maxY && d(x, y + step, z) > 0) y += step;
        } else {
            do { y -= step; } while (y > minY && d(x, y, z) <= 0);
            if (y <= minY) { last = 80; return minY; }
        }
        double lo = y, hi = y + step;                     // ground at lo, air at hi
        for (int i = 0; i < 3; i++) {
            double mid = (lo + hi) / 2;
            if (d(x, (int) Math.round(mid), z) > 0) lo = mid; else hi = mid;
        }
        last = (int) lo;
        return lo;
    }

    private double d(int x, int y, int z) { return f.compute(new DensityFunction.SinglePointContext(x, y, z)); }
}
