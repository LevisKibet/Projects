package com.ronald.rivergence.plan;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.PriorityQueue;

/**
 * Where the water goes across one square of land.
 *
 * The land is sampled on a coarse grid (one height per cell). Every hollow is filled up to the level where it would
 * spill (a priority flood from the sea and the square's edges inward), so each cell then has a way downhill: the
 * filled hollows are where lakes lie, and everything else drains toward the sea. Each cell sends its water on to its
 * steepest lower neighbour, and the water gathered from everything upstream ("accumulation", in cells) says how big
 * the stream there is: a trickle where a few cells drain, a river where thousands do.
 *
 * Pure Java on purpose: the heights come in through {@link Heights}, so it runs the same in the game and in tools.
 */
public final class Drainage {
    /** Terrain surface height at a block column (for columns under the sea, the sea floor). */
    public interface Heights { double at(int x, int z); }

    public static final double SEA = 62.5;
    /** Smallest rise given to the water surface across a flat, so it always has a way to flow. */
    private static final double EPS = 0.001;
    /** Lakes: hollows at least this deep (blocks) and this big (cells). */
    private static final double LAKE_DEPTH = 1.5;
    private static final int LAKE_CELLS = 4;

    static final int[] DX = {1, 1, 0, -1, -1, -1, 0, 1}, DZ = {0, 1, 1, 1, 0, -1, -1, -1};
    static final double[] DL = {1, Math.sqrt(2), 1, Math.sqrt(2), 1, Math.sqrt(2), 1, Math.sqrt(2)};

    /** The square: its north-west corner (blocks), cell size (blocks) and cells per side. */
    public final int x0, z0, cell, n;
    /** Per cell: land height, the filled water surface, the way water leaves (0-7, -1 into the sea, -2 off the edge). */
    public final float[] h, fill;
    public final byte[] dir;
    /** Per cell: cells draining through it (itself included). */
    public final float[] acc;
    /** Per cell: the lake it lies in (index into {@link #lakeLevel}) or -1. */
    public final int[] lake;
    public float[] lakeLevel = new float[0];
    public int[] lakeArea = new int[0];
    public long sampleNanos;

    public Drainage(int x0, int z0, int cell, int n, Heights hs) {
        this.x0 = x0; this.z0 = z0; this.cell = cell; this.n = n;
        int N = n * n;
        h = new float[N]; fill = new float[N]; dir = new byte[N]; acc = new float[N]; lake = new int[N];
        long t0 = System.nanoTime();
        for (int j = 0; j < n; j++) for (int i = 0; i < n; i++) h[i + j * n] = (float) hs.at(x0 + i * cell + cell / 2, z0 + j * cell + cell / 2);
        sampleNanos = System.nanoTime() - t0;
        flood();
        directions();
        accumulate();
        findLakes();
    }

    public boolean sea(int k) { return dir[k] == -1; }

    /** Fill every hollow to its spill level, working inward from the sea and the square's edges. */
    private void flood() {
        int N = n * n;
        boolean[] done = new boolean[N];
        PriorityQueue<long[]> q = new PriorityQueue<>((a, b) -> Long.compare(a[0], b[0]));
        for (int k = 0; k < N; k++) {
            int i = k % n, j = k / n;
            boolean edge = i == 0 || j == 0 || i == n - 1 || j == n - 1;
            if (h[k] < SEA) { fill[k] = (float) SEA; dir[k] = -1; }
            else if (edge) { fill[k] = h[k]; dir[k] = -2; }
            else continue;
            done[k] = true;
            q.add(new long[]{key(fill[k]), k});
        }
        while (!q.isEmpty()) {
            int c = (int) q.poll()[1];
            int ci = c % n, cj = c / n;
            for (int d = 0; d < 8; d++) {
                int i = ci + DX[d], j = cj + DZ[d];
                if (i < 0 || j < 0 || i >= n || j >= n) continue;
                int k = i + j * n;
                if (done[k]) continue;
                done[k] = true;
                fill[k] = (float) Math.max(h[k], fill[c] + EPS * DL[d]);
                q.add(new long[]{key(fill[k]), k});
            }
        }
    }

    private static long key(double f) { return (long) ((f + 1000) * 100000); }

    /** Each cell drains to its steepest lower neighbour on the filled surface. */
    private void directions() {
        for (int k = 0; k < n * n; k++) {
            if (dir[k] < 0) continue;
            int ci = k % n, cj = k / n;
            double best = 0; int bd = -2;
            for (int d = 0; d < 8; d++) {
                int i = ci + DX[d], j = cj + DZ[d];
                if (i < 0 || j < 0 || i >= n || j >= n) continue;
                double s = (fill[k] - fill[i + j * n]) / DL[d];
                if (s > best) { best = s; bd = d; }
            }
            dir[k] = (byte) bd;
        }
    }

    /** Downstream cell of k, or -1. */
    public int down(int k) {
        if (dir[k] < 0) return -1;
        int i = k % n + DX[dir[k]], j = k / n + DZ[dir[k]];
        return i + j * n;
    }

    /** Gather the water downhill, highest cells first. */
    private void accumulate() {
        int N = n * n;
        Integer[] order = new Integer[N];
        for (int k = 0; k < N; k++) order[k] = k;
        Arrays.sort(order, (a, b) -> Float.compare(fill[b], fill[a]));
        Arrays.fill(acc, 1);
        for (int k : order) {
            int d = down(k);
            if (d >= 0) acc[d] += acc[k];
        }
    }

    /** Filled hollows that are deep and big enough become lakes, at the level they fill to. */
    private void findLakes() {
        int N = n * n;
        Arrays.fill(lake, -1);
        float[] lv = new float[64]; int[] ar = new int[64]; int count = 0;
        boolean[] seen = new boolean[N];
        ArrayDeque<Integer> q = new ArrayDeque<>();
        java.util.List<Integer> cells = new java.util.ArrayList<>();
        for (int s = 0; s < N; s++) {
            if (seen[s] || dir[s] == -1 || fill[s] - h[s] < 0.8) continue;
            cells.clear(); q.add(s); seen[s] = true;
            float level = 0, depth = 0;
            while (!q.isEmpty()) {
                int c = q.poll(); cells.add(c);
                level = Math.max(level, fill[c]); depth = Math.max(depth, fill[c] - h[c]);
                int ci = c % n, cj = c / n;
                for (int d = 0; d < 8; d += 2) {
                    int i = ci + DX[d], j = cj + DZ[d];
                    if (i < 0 || j < 0 || i >= n || j >= n) continue;
                    int k = i + j * n;
                    if (seen[k] || dir[k] == -1 || fill[k] - h[k] < 0.8) continue;
                    seen[k] = true; q.add(k);
                }
            }
            if (cells.size() < LAKE_CELLS || depth < LAKE_DEPTH) continue;
            if (count == lv.length) { lv = Arrays.copyOf(lv, count * 2); ar = Arrays.copyOf(ar, count * 2); }
            lv[count] = (float) Math.floor(level); ar[count] = cells.size();
            for (int c : cells) lake[c] = count;
            count++;
        }
        lakeLevel = Arrays.copyOf(lv, count); lakeArea = Arrays.copyOf(ar, count);
    }
}
