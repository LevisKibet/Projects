package com.ronald.rivergence.dev;

import com.ronald.rivergence.plan.Drainage;
import com.ronald.rivergence.plan.DrainageMap;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;

import javax.imageio.ImageIO;
import java.io.File;

/** Development only (-Drivergence.probe=map on a dedicated server): draws drainage plans of the land round spawn, then stops. */
public final class DevProbe {
    private DevProbe() {}

    public static void init() {
        String mode = System.getProperty("rivergence.probe", "");
        if (mode.isEmpty()) return;
        MinecraftForge.EVENT_BUS.addListener(DevProbe::tick);
    }

    private static int t = -1;

    private static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || ++t != 3) return;
        MinecraftServer srv = e.getServer();
        try {
            ServerLevel lvl = srv.overworld();
            ChunkGenerator gen = lvl.getChunkSource().getGenerator();
            RandomState rs = lvl.getChunkSource().randomState();
            Drainage.Heights exact = (x, z) -> gen.getBaseHeight(x, z, Heightmap.Types.OCEAN_FLOOR_WG, lvl, rs) - 1;
            com.ronald.rivergence.plan.FastHeights fast = new com.ronald.rivergence.plan.FastHeights(rs, lvl.getMinBuildHeight(), lvl.getMaxBuildHeight());
            // how close the quick estimate comes to the real surface
            java.util.Random rnd = new java.util.Random(1);
            double err = 0, worst = 0, bias = 0; int coast = 0; long te = 0, tf = 0;
            for (int s = 0; s < 200; s++) {
                int x = rnd.nextInt(4000) - 2000, z = rnd.nextInt(4000) - 2000;
                long a = System.nanoTime(); double he = exact.at(x, z); long b = System.nanoTime(); double hf = fast.at(x, z); long c = System.nanoTime();
                te += b - a; tf += c - b;
                if (he < 62 && hf < 62) continue;
                err += Math.abs(he - hf); worst = Math.max(worst, Math.abs(he - hf));
                if (he > 55 && he < 80) { bias += hf - he; coast++; }
            }
            System.out.println(String.format("[probe] exact %.0f us, fast %.0f us per sample; mean error %.1f, worst %.1f; near the coast the estimate is off by %.1f on average (%d samples)", te / 200e3, tf / 200e3, err / 200, worst, bias / Math.max(1, coast), coast));
            com.ronald.rivergence.plan.PlanHeights hs = new com.ronald.rivergence.plan.PlanHeights(fast, exact);
            File dir = new File("probe");
            dir.mkdirs();
            int cx = lvl.getSharedSpawnPos().getX(), cz = lvl.getSharedSpawnPos().getZ();
            // a wide view (4096 blocks, 16-block cells) and a close one (1024 blocks, 4-block cells)
            int[][] views = {{4096, 16, 3, 24}, {1024, 4, 3, 40}};
            for (int[] v : views) {
                int size = v[0], cell = v[1], n = size / cell;
                long t0 = System.nanoTime();
                Drainage p = new Drainage(cx - size / 2, cz - size / 2, cell, n, hs);
                long t1 = System.nanoTime();
                ImageIO.write(DrainageMap.draw(p, v[2], v[3]), "png", new File(dir, "drainage_" + size + ".png"));
                System.out.println(String.format("[probe] %d blocks at %d: %d samples, sampling %.1fs, planning %.2fs, %d lakes",
                        size, cell, n * n, p.sampleNanos / 1e9, (t1 - t0 - p.sampleNanos) / 1e9, p.lakeLevel.length) + ", exact samples " + hs.exactCalls);
                hs.exactCalls = 0;
            }
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
        srv.halt(false);
    }
}
