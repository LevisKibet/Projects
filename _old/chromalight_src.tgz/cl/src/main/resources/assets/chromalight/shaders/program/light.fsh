#version 150

// Chroma Light: coloured light on top of vanilla's. Each light is a point (camera-relative), a radius and a colour.
//   "tint" lights (light-giving blocks): vanilla already lights the area around them, so they only colour that
//      light - torches warm, soul fire cyan - without making anything brighter.
//   "emit" lights (things vanilla doesn't light: a held torch, a burning mob, a glowing sword): they add light,
//      falling off smoothly to nothing at their radius.
// The surface facing comes from the depth buffer (Minecraft's faces are flat, so this is clean), and the colour of
// what's lit is estimated from the image so dark corners take on the light's hue rather than turning grey.

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;
uniform sampler2D LightSampler;   // 64 x 2: row 0 = position (xyz) + radius, row 1 = colour * intensity + kind
uniform mat4 InvViewProj;
uniform float LightCount;
uniform float Strength;

in vec2 texCoord;
out vec4 fragColor;

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    vec3 scene = texture(DiffuseSampler, texCoord).rgb;
    float d = texture(DepthSampler, texCoord).r;
    if (d >= 1.0) { fragColor = vec4(scene, 1.0); return; }          // sky
    vec4 p = InvViewProj * vec4(texCoord * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    vec3 P = p.xyz / p.w;                                              // camera-relative position of this surface
    vec3 N = cross(dFdx(P), dFdy(P));
    float nl = length(N);
    N = nl > 1e-6 ? N / nl : vec3(0.0, 1.0, 0.0);
    if (dot(N, P) > 0.0) N = -N;                                       // face the camera

    vec3 tintSum = vec3(0.0); float tintW = 0.0;
    vec3 emit = vec3(0.0);
    int count = int(LightCount + 0.5);
    for (int i = 0; i < count; i++) {
        vec4 a = texelFetch(LightSampler, ivec2(i, 0), 0);
        vec3 L = a.xyz - P;
        float r2 = a.w * a.w, d2 = dot(L, L);
        if (d2 >= r2) continue;                                        // out of reach: the cheap test first
        vec4 b = texelFetch(LightSampler, ivec2(i, 1), 0);
        float dist = sqrt(d2);
        float att = 1.0 - dist / a.w;
        att *= att;                                                    // smooth fall-off to zero at the radius
        float facing = dist < 0.7 ? 1.0 : clamp(dot(N, L / dist) * 0.65 + 0.35, 0.0, 1.0);
        float w = att * facing;
        if (b.a < 0.5) { tintSum += b.rgb * w; tintW += w; }
        else emit += b.rgb * w;
    }

    vec3 color = scene;
    if (tintW > 0.0005) {
        vec3 tint = tintSum / tintW;
        tint /= max(luma(tint), 0.05);                                 // a hue, at the light's own brightness
        color = mix(color, color * tint, clamp(tintW, 0.0, 1.0) * 0.8 * Strength);
    }
    if (emit.r + emit.g + emit.b > 0.0005) {
        float l = luma(color);
        vec3 albedo = color / max(max(color.r, max(color.g, color.b)), 0.06) * 0.55;   // the surface's own hue
        color += (albedo * emit + emit * 0.03) * (1.0 - clamp(l, 0.0, 0.9)) * Strength;
    }
    fragColor = vec4(color, 1.0);
}
