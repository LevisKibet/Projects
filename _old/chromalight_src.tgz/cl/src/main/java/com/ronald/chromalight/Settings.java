package com.ronald.chromalight;

import net.minecraftforge.common.ForgeConfigSpec;

/** config/chromalight-client.toml */
public final class Settings {
    private Settings() {}
    static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED, BLOCKS, DYNAMIC;
    public static final ForgeConfigSpec.IntValue STRENGTH, MAX_LIGHTS, SCAN_RADIUS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        ENABLED = b.comment("Coloured light on or off.").define("enabled", true);
        STRENGTH = b.comment("How strongly lights colour the world, 0 to 100.").defineInRange("strength", 70, 0, 100);
        BLOCKS = b.comment("Light-giving blocks (torches, soul fire, lanterns, glowstone...) tint the light around them.").define("block_lights", true);
        DYNAMIC = b.comment("Held lights, burning mobs and glowing creatures cast light as they move.").define("dynamic_lights", true);
        MAX_LIGHTS = b.comment("Most lights drawn at once (the nearest win). Fewer is faster.").defineInRange("max_lights", 32, 4, 64);
        SCAN_RADIUS = b.comment("How far (in blocks) to look for light-giving blocks.").defineInRange("block_radius", 24, 8, 48);
        SPEC = b.build();
    }

    static boolean on(ForgeConfigSpec.BooleanValue v) { try { return v.get(); } catch (IllegalStateException e) { return false; } }
    static int num(ForgeConfigSpec.IntValue v, int d) { try { return v.get(); } catch (IllegalStateException e) { return d; } }
    public static boolean enabled() { return on(ENABLED); }
    public static boolean blocks() { return on(BLOCKS); }
    public static boolean dynamic() { return on(DYNAMIC); }
    public static float strength() { return num(STRENGTH, 70) / 100f; }
    public static int maxLights() { return num(MAX_LIGHTS, 32); }
    public static int scanRadius() { return num(SCAN_RADIUS, 24); }
}
