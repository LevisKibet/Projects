package com.ronald.chromalight;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.IdentityHashMap;
import java.util.Map;

/** The colour each light source gives off (linear RGB, 0..1), and whether it flickers like a flame. */
public final class LightColors {
    private LightColors() {}

    public record Tone(float r, float g, float b, boolean flame) {}
    static final Tone FIRE = new Tone(1.0f, 0.55f, 0.22f, true);
    static final Tone SOUL = new Tone(0.25f, 0.80f, 1.0f, true);
    static final Tone REDSTONE = new Tone(1.0f, 0.15f, 0.10f, false);
    static final Tone GLOW = new Tone(1.0f, 0.80f, 0.45f, false);
    static final Tone SEA = new Tone(0.55f, 0.90f, 1.0f, false);
    static final Tone PURPLE = new Tone(0.70f, 0.35f, 1.0f, false);
    static final Tone LAVA = new Tone(1.0f, 0.38f, 0.10f, true);

    private static final Map<Block, Tone> BLOCKS = new IdentityHashMap<>();
    static {
        for (Block b : new Block[]{Blocks.TORCH, Blocks.WALL_TORCH, Blocks.LANTERN, Blocks.CAMPFIRE, Blocks.FIRE, Blocks.JACK_O_LANTERN,
                Blocks.CANDLE, Blocks.FURNACE, Blocks.SMOKER, Blocks.BLAST_FURNACE}) BLOCKS.put(b, FIRE);
        for (Block b : new Block[]{Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH, Blocks.SOUL_LANTERN, Blocks.SOUL_CAMPFIRE, Blocks.SOUL_FIRE}) BLOCKS.put(b, SOUL);
        for (Block b : new Block[]{Blocks.REDSTONE_TORCH, Blocks.REDSTONE_WALL_TORCH, Blocks.REDSTONE_LAMP, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE}) BLOCKS.put(b, REDSTONE);
        for (Block b : new Block[]{Blocks.GLOWSTONE, Blocks.SHROOMLIGHT}) BLOCKS.put(b, GLOW);
        for (Block b : new Block[]{Blocks.SEA_LANTERN, Blocks.BEACON, Blocks.CONDUIT, Blocks.SEA_PICKLE}) BLOCKS.put(b, SEA);
        for (Block b : new Block[]{Blocks.AMETHYST_CLUSTER, Blocks.LARGE_AMETHYST_BUD, Blocks.CRYING_OBSIDIAN, Blocks.NETHER_PORTAL,
                Blocks.END_ROD, Blocks.RESPAWN_ANCHOR, Blocks.ENCHANTING_TABLE, Blocks.ENDER_CHEST}) BLOCKS.put(b, PURPLE);
        for (Block b : new Block[]{Blocks.LAVA, Blocks.MAGMA_BLOCK, Blocks.LAVA_CAULDRON}) BLOCKS.put(b, LAVA);
        BLOCKS.put(Blocks.GLOW_LICHEN, new Tone(0.45f, 1.0f, 0.75f, false));
        BLOCKS.put(Blocks.OCHRE_FROGLIGHT, new Tone(1.0f, 0.85f, 0.35f, false));
        BLOCKS.put(Blocks.VERDANT_FROGLIGHT, new Tone(0.55f, 1.0f, 0.45f, false));
        BLOCKS.put(Blocks.PEARLESCENT_FROGLIGHT, new Tone(1.0f, 0.55f, 0.85f, false));
        BLOCKS.put(Blocks.SCULK_CATALYST, new Tone(0.25f, 0.9f, 0.95f, false));
        BLOCKS.put(Blocks.BREWING_STAND, new Tone(1.0f, 0.85f, 0.4f, false));
    }

    /** The tone of a light-giving block, or null to leave its light as vanilla made it. */
    public static Tone of(BlockState s) {
        Tone t = BLOCKS.get(s.getBlock());
        if (t != null) return t;
        if (s.getBlock() instanceof net.minecraft.world.level.block.CandleBlock || s.getBlock() instanceof net.minecraft.world.level.block.CandleCakeBlock) return FIRE;
        return null;
    }

    /** The tone and light level of something held, or null. */
    public static Object[] held(ItemStack st) {
        if (st.isEmpty()) return null;
        if (st.is(Items.LAVA_BUCKET)) return new Object[]{LAVA, 15};
        if (st.is(Items.BLAZE_ROD) || st.is(Items.FIRE_CHARGE)) return new Object[]{FIRE, 10};
        if (st.is(Items.GLOWSTONE_DUST)) return new Object[]{GLOW, 8};
        if (st.getItem() instanceof BlockItem bi) {
            BlockState s = bi.getBlock().defaultBlockState();
            int lvl = s.getLightEmission();
            Tone t = of(s);
            if (lvl > 0 && t != null) return new Object[]{t, lvl};
        }
        return null;
    }

    /** Creatures that glow, and their light, or null. */
    public static Object[] creature(Entity e) {
        EntityType<?> t = e.getType();
        if (t == EntityType.BLAZE || t == EntityType.MAGMA_CUBE) return new Object[]{FIRE, 10};
        if (t == EntityType.GLOW_SQUID) return new Object[]{new Tone(0.3f, 1.0f, 0.85f, false), 8};
        if (t == EntityType.ALLAY) return new Object[]{new Tone(0.4f, 0.75f, 1.0f, false), 7};
        if (t == EntityType.VEX) return new Object[]{new Tone(0.75f, 0.85f, 1.0f, false), 5};
        return null;
    }
}
