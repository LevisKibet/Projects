package com.ronald.ancientpeaks;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModList;

/**
 * Highland Gateways are optional: they need the Immersive Gateways mod, and even with it installed a server can turn
 * them off in config/ancientpeaks-common.toml. Without them there are no gateway ruins: the island is reached by sea.
 */
public final class Gateways {
    private Gateways() {}
    public static final String MOD = "immersive_gateways";

    static final ForgeConfigSpec SPEC;
    static final ForgeConfigSpec.BooleanValue ENABLED;
    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("gateways");
        ENABLED = b.comment("Highland Gateways: ancient portals in the overworld that lead to the island (needs the Immersive Gateways mod).",
                        "Set to false to skip them: no gateway ruins generate and the island is reached by sea.",
                        "Only affects terrain generated after the change.")
                .define("enabled", true);
        b.pop();
        SPEC = b.build();
    }

    /** Is Immersive Gateways installed? */
    public static boolean modPresent() { return ModList.get() != null && ModList.get().isLoaded(MOD); }

    /** Do Highland Gateways exist in this game (mod installed and not switched off)? */
    public static boolean enabled() {
        if (!modPresent()) return false;
        try { return ENABLED.get(); } catch (IllegalStateException notLoadedYet) { return true; }
    }
}
