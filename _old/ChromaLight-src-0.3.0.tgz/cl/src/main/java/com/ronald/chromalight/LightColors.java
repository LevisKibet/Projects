package com.ronald.chromalight;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.IdentityHashMap;
import java.util.Map;

/** The colour each light source gives off (linear RGB, 0..1), and whether it flickers like a flame. */
public final class LightColors {
    private LightColors() {}

    public record Tone(float r, float g, float b, boolean flame) {}
    static final Tone FIRE = new Tone(1.0f, 0.55f, 0.22f, true);
    static final Tone SOUL = new Tone(0.25f, 0.80f, 1.0f, true);
    static final Tone REDSTONE = new Tone(1.0f, 0.15f, 0.10f, false);
    static final Tone GLOW = new Tone(1.0f, 0.80f, 0.45f, false);
    static final Tone SEA = new Tone(0.55f, 0.90f, 1.0f, false);
    static final Tone PURPLE = new Tone(0.70f, 0.35f, 1.0f, false);
    static final Tone LAVA = new Tone(1.0f, 0.38f, 0.10f, true);

    private static final Map<Block, Tone> BLOCKS = new IdentityHashMap<>();
    static {
        for (Block b : new Block[]{Blocks.TORCH, Blocks.WALL_TORCH, Blocks.LANTERN, Blocks.CAMPFIRE, Blocks.FIRE, Blocks.JACK_O_LANTERN,
                Blocks.CANDLE, Blocks.FURNACE, Blocks.SMOKER, Blocks.BLAST_FURNACE}) BLOCKS.put(b, FIRE);
        for (Block b : new Block[]{Blocks.SOUL_TORCH, Blocks.SOUL_WALL_TORCH, Blocks.SOUL_LANTERN, Blocks.SOUL_CAMPFIRE, Blocks.SOUL_FIRE}) BLOCKS.put(b, SOUL);
        for (Block b : new Block[]{Blocks.REDSTONE_TORCH, Blocks.REDSTONE_WALL_TORCH, Blocks.REDSTONE_LAMP, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE}) BLOCKS.put(b, REDSTONE);
        for (Block b : new Block[]{Blocks.GLOWSTONE, Blocks.SHROOMLIGHT}) BLOCKS.put(b, GLOW);
        for (Block b : new Block[]{Blocks.SEA_LANTERN, Blocks.BEACON, Blocks.CONDUIT, Blocks.SEA_PICKLE}) BLOCKS.put(b, SEA);
        for (Block b : new Block[]{Blocks.AMETHYST_CLUSTER, Blocks.LARGE_AMETHYST_BUD, Blocks.CRYING_OBSIDIAN, Blocks.NETHER_PORTAL,
                Blocks.END_ROD, Blocks.RESPAWN_ANCHOR, Blocks.ENCHANTING_TABLE, Blocks.ENDER_CHEST}) BLOCKS.put(b, PURPLE);
        for (Block b : new Block[]{Blocks.LAVA, Blocks.MAGMA_BLOCK, Blocks.LAVA_CAULDRON}) BLOCKS.put(b, LAVA);
        BLOCKS.put(Blocks.GLOW_LICHEN, new Tone(0.45f, 1.0f, 0.75f, false));
        BLOCKS.put(Blocks.OCHRE_FROGLIGHT, new Tone(1.0f, 0.85f, 0.35f, false));
        BLOCKS.put(Blocks.VERDANT_FROGLIGHT, new Tone(0.55f, 1.0f, 0.45f, false));
        BLOCKS.put(Blocks.PEARLESCENT_FROGLIGHT, new Tone(1.0f, 0.55f, 0.85f, false));
        BLOCKS.put(Blocks.SCULK_CATALYST, new Tone(0.25f, 0.9f, 0.95f, false));
        BLOCKS.put(Blocks.BREWING_STAND, new Tone(1.0f, 0.85f, 0.4f, false));
    }

    static final Tone WHITE = new Tone(1.0f, 0.92f, 0.8f, false);

    /** Colours from the config (block id or "modid:*" -> colour), rebuilt when the config changes. */
    private static volatile Map<String, Tone> overrides = Map.of();
    private static volatile Object overridesFrom;
    /** Colours worked out from block textures, for blocks we don't know (modded ones included). */
    private static final Map<Block, Tone> AUTO = new java.util.concurrent.ConcurrentHashMap<>();
    /** Blocks waiting for their texture colour (only worked out on the render thread). */
    static final java.util.Set<Block> PENDING = java.util.concurrent.ConcurrentHashMap.newKeySet();

    /** The tone of a light-giving block: config first, then the built-in table, then its texture. Never null. */
    public static Tone of(BlockState s) {
        Block b = s.getBlock();
        Map<String, Tone> o = configured();
        if (!o.isEmpty()) {
            var id = net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(b);
            if (id != null) {
                Tone t = o.get(id.toString());
                if (t == null) t = o.get(id.getNamespace() + ":*");
                if (t != null) return t;
            }
        }
        Tone t = BLOCKS.get(b);
        if (t != null) return t;
        if (b instanceof net.minecraft.world.level.block.CandleBlock || b instanceof net.minecraft.world.level.block.CandleCakeBlock) return FIRE;
        if (!Settings.autoColors()) return WHITE;
        t = AUTO.get(b);
        if (t != null) return t;
        if (com.mojang.blaze3d.systems.RenderSystem.isOnRenderThread()) { t = fromTexture(s); AUTO.put(b, t); return t; }
        PENDING.add(b);
        return WHITE;
    }

    /** Work out the colours of blocks the light volume met off the render thread. Returns true if any were new. */
    static boolean resolvePending() {
        if (PENDING.isEmpty()) return false;
        for (Block b : PENDING.toArray(new Block[0])) { AUTO.put(b, fromTexture(b.defaultBlockState())); PENDING.remove(b); }
        return true;
    }

    static void clearAuto() { AUTO.clear(); }

    /** The colour a block glows: the average of the brightest, most colourful pixels of its texture. */
    private static Tone fromTexture(BlockState s) {
        try {
            var sprite = net.minecraft.client.Minecraft.getInstance().getBlockRenderer().getBlockModelShaper().getParticleIcon(s);
            var img = sprite.contents().getOriginalImage();
            int w = sprite.contents().width(), h = Math.min(sprite.contents().height(), img.getHeight());
            // pass 1: how bright is the brightest part
            float top = 0;
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int c = img.getPixelRGBA(x, y);                         // ABGR
                if ((c >>> 24) < 128) continue;
                top = Math.max(top, Math.max(c & 255, Math.max((c >> 8) & 255, (c >> 16) & 255)));
            }
            if (top <= 0) return WHITE;
            // pass 2: average the glowing pixels, the colourful ones counting most
            float r = 0, g = 0, bl = 0, wsum = 0;
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int c = img.getPixelRGBA(x, y);
                if ((c >>> 24) < 128) continue;
                float pr = (c & 255) / 255f, pg = ((c >> 8) & 255) / 255f, pb = ((c >> 16) & 255) / 255f;
                float mx = Math.max(pr, Math.max(pg, pb)), mn = Math.min(pr, Math.min(pg, pb));
                if (mx * 255f < top * 0.7f) continue;
                float wt = 0.25f + (mx > 0 ? (mx - mn) / mx : 0) * 2f;
                r += pr * pr * wt; g += pg * pg * wt; bl += pb * pb * wt; wsum += wt;   // squared: linear light
            }
            if (wsum <= 0) return WHITE;
            r /= wsum; g /= wsum; bl /= wsum;
            float m = Math.max(r, Math.max(g, bl));
            if (m <= 0.001f) return WHITE;
            r /= m; g /= m; bl /= m;
            float sat = 1f - Math.min(r, Math.min(g, bl));
            if (sat < 0.12f) return WHITE;                                // near-white textures: keep the light neutral
            boolean flame = s.getBlock() instanceof net.minecraft.world.level.block.TorchBlock || s.getBlock() instanceof net.minecraft.world.level.block.BaseFireBlock;
            return new Tone(r, g, bl, flame);
        } catch (RuntimeException ex) {
            return WHITE;
        }
    }

    private static Map<String, Tone> configured() {
        java.util.List<? extends String> list = Settings.colorList();
        if (list == overridesFrom) return overrides;
        Map<String, Tone> m = new java.util.HashMap<>();
        for (String e : list) {
            int eq = e.indexOf('=');
            if (eq < 0) continue;
            float[] c = parseColour(e.substring(eq + 1).trim());
            if (c != null) m.put(e.substring(0, eq).trim(), new Tone(c[0], c[1], c[2], false));
        }
        overrides = m; overridesFrom = list;
        return m;
    }

    /** "#ff8800", "ff8800" or a name. */
    public static float[] parseColour(String s) {
        String h = s.startsWith("#") ? s.substring(1) : s;
        if (h.matches("[0-9a-fA-F]{6}")) {
            int v = Integer.parseInt(h, 16);
            return new float[]{((v >> 16) & 255) / 255f, ((v >> 8) & 255) / 255f, (v & 255) / 255f};
        }
        return switch (s.toLowerCase(java.util.Locale.ROOT)) {
            case "red" -> new float[]{1f, 0.15f, 0.1f};
            case "orange" -> new float[]{1f, 0.5f, 0.15f};
            case "gold", "yellow" -> new float[]{1f, 0.82f, 0.3f};
            case "green" -> new float[]{0.3f, 1f, 0.35f};
            case "lime" -> new float[]{0.6f, 1f, 0.2f};
            case "cyan" -> new float[]{0.25f, 0.9f, 1f};
            case "blue" -> new float[]{0.2f, 0.4f, 1f};
            case "purple" -> new float[]{0.7f, 0.3f, 1f};
            case "magenta" -> new float[]{1f, 0.3f, 0.9f};
            case "pink" -> new float[]{1f, 0.5f, 0.75f};
            case "teal" -> new float[]{0.2f, 0.85f, 0.7f};
            case "white" -> new float[]{1f, 1f, 1f};
            default -> null;
        };
    }

    /** The tone and light level of something held, or null. */
    public static Object[] held(ItemStack st) {
        if (st.isEmpty()) return null;
        if (st.is(Items.LAVA_BUCKET)) return new Object[]{LAVA, 15};
        if (st.is(Items.BLAZE_ROD) || st.is(Items.FIRE_CHARGE)) return new Object[]{FIRE, 10};
        if (st.is(Items.GLOWSTONE_DUST)) return new Object[]{GLOW, 8};
        if (st.getItem() instanceof BlockItem bi) {
            BlockState s = bi.getBlock().defaultBlockState();
            int lvl = s.getLightEmission();
            if (lvl > 0) return new Object[]{of(s), lvl};
        }
        return null;
    }

    /** Creatures that glow, and their light, or null. */
    public static Object[] creature(Entity e) {
        EntityType<?> t = e.getType();
        if (t == EntityType.BLAZE || t == EntityType.MAGMA_CUBE) return new Object[]{FIRE, 10};
        if (t == EntityType.GLOW_SQUID) return new Object[]{new Tone(0.3f, 1.0f, 0.85f, false), 8};
        if (t == EntityType.ALLAY) return new Object[]{new Tone(0.4f, 0.75f, 1.0f, false), 7};
        if (t == EntityType.VEX) return new Object[]{new Tone(0.75f, 0.85f, 1.0f, false), 5};
        return null;
    }
}
