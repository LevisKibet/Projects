package com.ronald.chromalight;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.ints.IntArrayFIFOQueue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.BeaconBeamBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.DataLayer;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.lighting.LayerLightEventListener;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Coloured light that spreads like real light. Round the player, every light-giving block floods its colour outwards
 * one block at a time, losing a level per block just like vanilla light, stopped by solid blocks and filtered by
 * stained glass. Red and blue lights that meet make purple. Each block also remembers how much sky light reaches it,
 * so the shader can let daylight win outdoors and only show the colour where the block light is the stronger one.
 *
 * The flood runs on its own thread (the game never waits for it) and the result goes to the GPU as a flat texture:
 * the 80 x 48 x 80 block volume laid out as 48 horizontal slices in an 8 x 6 grid.
 */
public final class VoxelLight {
    private VoxelLight() {}

    static final int SX = 80, SY = 48, SZ = 80, COLS = 8, ROWS = 6;
    static final int AW = SX * COLS, AH = SZ * ROWS;
    private static final int N = SX * SY * SZ;
    private static final int UNIT = 16;                       // sub-steps per light level, so colours fade smoothly

    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Chroma Light volume");
        t.setDaemon(true);
        t.setPriority(Thread.MIN_PRIORITY + 1);
        return t;
    });
    private static final AtomicBoolean BUSY = new AtomicBoolean();
    private static volatile boolean dirty = true;
    private static volatile Result ready;
    private static int texture = -1;
    private static int sinceBuild;
    private static int[] builtCentre;
    private static ClientLevel lastLevel;

    /** Where the uploaded volume starts (world block coords), or null if there's nothing to show yet. */
    static volatile int[] origin;

    private record Result(int ox, int oy, int oz, ByteBuffer data) {}

    public static void markDirty() { dirty = true; }
    static int texture() { return texture; }

    // ------------------------------------------------------------------ main thread
    static void tick() {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.player == null || !Settings.enabled() || !Settings.blocks()) { origin = null; builtCentre = null; return; }
        if (level != lastLevel) { lastLevel = level; origin = null; builtCentre = null; ready = null; }
        if (LightColors.resolvePending()) dirty = true;
        sinceBuild++;
        BlockPos p = mc.player.blockPosition();
        boolean moved = builtCentre == null || Math.abs(p.getX() - builtCentre[0]) > 8 || Math.abs(p.getY() - builtCentre[1]) > 6 || Math.abs(p.getZ() - builtCentre[2]) > 8;
        if (!(moved || (dirty && sinceBuild >= 2) || sinceBuild >= 60)) return;
        if (!BUSY.compareAndSet(false, true)) return;
        dirty = false;
        sinceBuild = 0;
        builtCentre = new int[]{p.getX(), p.getY(), p.getZ()};
        int ox = (p.getX() - SX / 2) & ~3, oy = (p.getY() - SY / 2) & ~3, oz = (p.getZ() - SZ / 2) & ~3;
        boolean glass = Settings.glass();
        WORKER.execute(() -> {
            try { ready = build(level, ox, oy, oz, glass); }
            catch (Throwable t) { ChromaLight.LOGGER.debug("Chroma Light: volume build skipped", t); dirty = true; }
            finally { BUSY.set(false); }
        });
    }

    /** Render thread: send a finished volume to the GPU. */
    static void upload() {
        Result r = ready;
        if (r == null) return;
        ready = null;
        if (texture < 0) {
            texture = GlStateManager._genTexture();
            RenderSystem.bindTexture(texture);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, 0x812F);   // clamp to edge
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, 0x812F);
            GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, AW, AH, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (ByteBuffer) null);
        }
        RenderSystem.bindTexture(texture);
        GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, 4);
        GL11.glPixelStorei(GL11.GL_UNPACK_ROW_LENGTH, 0);
        GL11.glPixelStorei(GL11.GL_UNPACK_SKIP_ROWS, 0);
        GL11.glPixelStorei(GL11.GL_UNPACK_SKIP_PIXELS, 0);
        GL11.glTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, AW, AH, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, r.data);
        MemoryUtil.memFree(r.data);
        origin = new int[]{r.ox, r.oy, r.oz};
    }

    static void reset() {
        origin = null; builtCentre = null; dirty = true;
        if (texture >= 0) { GlStateManager._deleteTexture(texture); texture = -1; }
    }

    // ------------------------------------------------------------------ worker thread
    /** What the flood needs to know about a block state. */
    private record Info(int opacity, int filter, int emission, int colour) {}
    private static final Info AIR = new Info(0, 0xFFFFFF, 0, 0);

    private static Result build(ClientLevel level, int ox, int oy, int oz, boolean glass) {
        byte[] opacity = new byte[N];
        int[] filter = null;
        int[] light = new int[N];                              // r | g << 8 | b << 16, each 0..15*UNIT
        byte[] sky = new byte[N];
        IntArrayFIFOQueue queue = new IntArrayFIFOQueue(4096);
        Map<BlockState, Info> infos = new IdentityHashMap<>();
        LayerLightEventListener skyLight = level.getLightEngine().getLayerListener(LightLayer.SKY);
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();

        // 1. read the blocks and the sky light, and seed every light source
        for (int cx = ox >> 4; cx <= (ox + SX - 1) >> 4; cx++)
            for (int cz = oz >> 4; cz <= (oz + SZ - 1) >> 4; cz++) {
                LevelChunk ch = level.getChunkSource().getChunk(cx, cz, false);
                for (int sy = oy >> 4; sy <= (oy + SY - 1) >> 4; sy++) {
                    int x0 = Math.max(ox, cx << 4), x1 = Math.min(ox + SX - 1, (cx << 4) + 15);
                    int z0 = Math.max(oz, cz << 4), z1 = Math.min(oz + SZ - 1, (cz << 4) + 15);
                    int y0 = Math.max(oy, sy << 4), y1 = Math.min(oy + SY - 1, (sy << 4) + 15);
                    LevelChunkSection sec = null;
                    if (ch != null) {
                        int si = ch.getSectionIndexFromSectionY(sy);
                        if (si >= 0 && si < ch.getSections().length) sec = ch.getSections()[si];
                    }
                    if (ch == null) {                                            // not loaded: treat as solid, no light
                        for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) for (int x = x0; x <= x1; x++)
                            opacity[idx(x - ox, y - oy, z - oz)] = 15;
                        continue;
                    }
                    DataLayer skyData = skyLight.getDataLayerData(SectionPos.of(cx, sy, cz));
                    boolean empty = sec == null || sec.hasOnlyAir();
                    for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) for (int x = x0; x <= x1; x++) {
                        int i = idx(x - ox, y - oy, z - oz);
                        int s = skyData != null ? skyData.get(x & 15, y & 15, z & 15) : skyLight.getLightValue(m.set(x, y, z));
                        sky[i] = (byte) s;
                        if (empty) continue;
                        BlockState st = sec.getBlockState(x & 15, y & 15, z & 15);
                        if (st.isAir()) continue;
                        Info in = infos.get(st);
                        if (in == null) { in = info(st, glass); infos.put(st, in); }
                        opacity[i] = (byte) in.opacity;
                        if (in.filter != 0xFFFFFF) {
                            if (filter == null) { filter = new int[N]; java.util.Arrays.fill(filter, 0xFFFFFF); }
                            filter[i] = in.filter;
                        }
                        if (in.emission > 0) {
                            int v = scale(in.colour, in.emission * UNIT);
                            light[i] = max(light[i], v);
                            queue.enqueue(i);
                        }
                    }
                }
            }

        // 2. flood: each step loses a level (plus whatever the block in the way absorbs), per colour channel
        while (!queue.isEmpty()) {
            int i = queue.dequeueInt();
            int v = light[i];
            if (v == 0) continue;
            int x = i % SX, z = (i / SX) % SZ, y = i / (SX * SZ);
            for (int dir = 0; dir < 6; dir++) {
                int nx = x, ny = y, nz = z;
                switch (dir) { case 0 -> nx--; case 1 -> nx++; case 2 -> ny--; case 3 -> ny++; case 4 -> nz--; default -> nz++; }
                if (nx < 0 || ny < 0 || nz < 0 || nx >= SX || ny >= SY || nz >= SZ) continue;
                int j = idx(nx, ny, nz);
                int op = opacity[j];
                if (op >= 15) continue;
                int loss = UNIT * (1 + op);
                int r = (v & 255) - loss, g = ((v >> 8) & 255) - loss, b = ((v >> 16) & 255) - loss;
                if (r <= 0 && g <= 0 && b <= 0) continue;
                if (filter != null && filter[j] != 0xFFFFFF) {
                    int f = filter[j];
                    r = r * (f & 255) / 255; g = g * ((f >> 8) & 255) / 255; b = b * ((f >> 16) & 255) / 255;
                }
                int nv = Math.max(r, 0) | Math.max(g, 0) << 8 | Math.max(b, 0) << 16;
                int cur = light[j];
                int merged = max(cur, nv);
                if (merged != cur) { light[j] = merged; queue.enqueue(j); }
            }
        }

        // 3. pack into the slice grid: rgb = coloured light, a = sky light
        ByteBuffer out = MemoryUtil.memAlloc(AW * AH * 4);
        for (int y = 0; y < SY; y++) {
            int tx = (y % COLS) * SX, ty = (y / COLS) * SZ;
            for (int z = 0; z < SZ; z++) {
                int row = ((ty + z) * AW + tx) * 4;
                for (int x = 0; x < SX; x++) {
                    int i = idx(x, y, z), v = light[i], o = row + x * 4;
                    out.put(o, (byte) Math.min(255, (v & 255) * 255 / (15 * UNIT)));
                    out.put(o + 1, (byte) Math.min(255, ((v >> 8) & 255) * 255 / (15 * UNIT)));
                    out.put(o + 2, (byte) Math.min(255, ((v >> 16) & 255) * 255 / (15 * UNIT)));
                    out.put(o + 3, (byte) (sky[i] * 17));
                }
            }
        }
        return new Result(ox, oy, oz, out);
    }

    private static Info info(BlockState st, boolean glass) {
        int op = Math.max(0, Math.min(15, st.getLightBlock(EmptyBlockGetter.INSTANCE, BlockPos.ZERO)));
        int filter = 0xFFFFFF;
        if (glass && st.getBlock() instanceof BeaconBeamBlock bb) {
            float[] c = bb.getColor().getTextureDiffuseColors();
            float mx = Math.max(c[0], Math.max(c[1], c[2]));
            // keep the glass's hue but don't let it swallow all the light
            int r = (int) (255 * (0.15f + 0.85f * c[0] / mx)), g = (int) (255 * (0.15f + 0.85f * c[1] / mx)), b = (int) (255 * (0.15f + 0.85f * c[2] / mx));
            filter = r | g << 8 | b << 16;
        }
        int em = st.getLightEmission();
        int colour = 0;
        if (em > 0) {
            LightColors.Tone t = LightColors.of(st);
            colour = (int) (t.r() * 255) | (int) (t.g() * 255) << 8 | (int) (t.b() * 255) << 16;
        }
        if (op == 0 && filter == 0xFFFFFF && em == 0) return AIR;
        return new Info(op, filter, em, colour);
    }

    private static int idx(int x, int y, int z) { return (y * SZ + z) * SX + x; }

    /** colour (0..255 per channel) times a level (0..15*UNIT). */
    private static int scale(int colour, int level) {
        int r = (colour & 255) * level / 255, g = ((colour >> 8) & 255) * level / 255, b = ((colour >> 16) & 255) * level / 255;
        return r | g << 8 | b << 16;
    }

    private static int max(int a, int b) {
        return Math.max(a & 255, b & 255) | Math.max((a >> 8) & 255, (b >> 8) & 255) << 8 | Math.max((a >> 16) & 255, (b >> 16) & 255) << 16;
    }
}
