package com.ronald.ancientpeaks_lore.client;

import com.ronald.ancientpeaks_lore.AncientPeaksLore;
import com.ronald.ancientpeaks_lore.LoreContent;
import com.ronald.ancientpeaks_lore.Merlin;
import com.ronald.ancientpeaks_lore.Vortigern;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/**
 * Client only. Merlin is a GeckoLib model (one animation: lying wounded). Vortigern is a plain humanoid with a
 * player-layout skin (textures/entity/vortigern.png); Epic Fight takes him over, draws him with its biped mesh in that
 * skin, and plays its greatsword moveset on him.
 */
public final class LoreClient {
    private LoreClient() {}
    static final ResourceLocation VORTIGERN_SKIN = new ResourceLocation(AncientPeaksLore.MODID, "textures/entity/vortigern.png");
    static final ResourceLocation STATUE_SKIN = new ResourceLocation(AncientPeaksLore.MODID, "textures/entity/vortigern_statue.png");
    static final ResourceLocation SHADE = new ResourceLocation(AncientPeaksLore.MODID, "textures/entity/saxon_shade.png");
    static final ResourceLocation SHADE_CHARGING = new ResourceLocation(AncientPeaksLore.MODID, "textures/entity/saxon_shade_charging.png");

    /** Frozen mid-reach for the sword: leaning in, right hand out toward the hilt, eyes on it, one foot forward. */
    static class StatueModel extends HumanoidModel<com.ronald.ancientpeaks_lore.VortigernStatue> {
        StatueModel(net.minecraft.client.model.geom.ModelPart root) { super(root); }
        @Override
        public void setupAnim(com.ronald.ancientpeaks_lore.VortigernStatue e, float limb, float limbAmt, float age, float yaw, float pitch) {
            head.xRot = 0.45f; head.yRot = -0.1f; head.zRot = 0;
            body.xRot = 0.22f; body.yRot = -0.08f;
            rightArm.xRot = -1.35f; rightArm.yRot = -0.12f; rightArm.zRot = 0.08f;
            leftArm.xRot = -0.25f; leftArm.yRot = 0.1f; leftArm.zRot = -0.35f;
            rightLeg.xRot = -0.42f; rightLeg.yRot = 0.05f;
            leftLeg.xRot = 0.32f; leftLeg.yRot = -0.05f;
            rightArm.z = 0.8f; leftArm.z = 0.6f;                       // the shoulders follow the lean
            hat.copyFrom(head);
        }
    }

    public static void init(IEventBus bus) {
        bus.addListener(LoreClient::renderers);
        bus.addListener(LoreClient::epicFightRenderer);
        Cutscenes.register();
        EpicBossBar.register();
        bus.addListener((RegisterClientReloadListenersEvent e) -> e.registerReloadListener((ResourceManagerReloadListener) rm -> ClientRes.forget()));
    }

    /**
     * Vortigern's Epic Fight renderer, registered here rather than from his mob patch: the patch's "epicfight:custom"
     * renderer comes out as the non-humanoid one (Epic Fight reads a different key on the client), which draws the
     * model almost fully transparent - he was invisible once he moved. This is the proper humanoid renderer on the
     * player-layout biped mesh, with his skin, his armour layer (the crown) and the sword in his hand.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void epicFightRenderer(yesman.epicfight.api.client.forgeevent.PatchedRenderersEvent.Add e) {
        e.addPatchedEntityRenderer(LoreContent.VORTIGERN.get(), type -> (yesman.epicfight.client.renderer.patched.entity.PatchedEntityRenderer)
                new yesman.epicfight.client.renderer.patched.entity.PCustomHumanoidEntityRenderer<>(yesman.epicfight.api.client.model.Meshes.BIPED, e.getContext(), type)
                        .initLayerLast(e.getContext(), type));
    }

    private static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(LoreContent.MERLIN.get(), ctx -> {
            GeoEntityRenderer<Merlin> r = new GeoEntityRenderer<>(ctx, new CharacterModel<>("merlin", "minecraft:textures/entity/illager/illusioner.png"));
            r.withScale(0.9375f);
            return r;
        });
        e.registerEntityRenderer(LoreContent.VORTIGERN.get(), ctx -> {
            HumanoidMobRenderer<Vortigern, HumanoidModel<Vortigern>> r = new HumanoidMobRenderer<>(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.7f) {
                @Override public ResourceLocation getTextureLocation(Vortigern v) { return VORTIGERN_SKIN; }
                @Override protected void scale(Vortigern v, PoseStack pose, float partial) { pose.scale(1.3f, 1.3f, 1.3f); }
            };
            r.addLayer(new HumanoidArmorLayer<>(r, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                    new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), ctx.getModelManager()));
            return r;
        });
        e.registerEntityRenderer(LoreContent.VORTIGERN_STATUE.get(), ctx ->
                new HumanoidMobRenderer<com.ronald.ancientpeaks_lore.VortigernStatue, StatueModel>(ctx, new StatueModel(ctx.bakeLayer(ModelLayers.PLAYER)), 0.7f) {
                    @Override public ResourceLocation getTextureLocation(com.ronald.ancientpeaks_lore.VortigernStatue v) { return STATUE_SKIN; }
                    @Override protected void scale(com.ronald.ancientpeaks_lore.VortigernStatue v, PoseStack pose, float partial) { pose.scale(1.3f, 1.3f, 1.3f); }
                });
        e.registerEntityRenderer(LoreContent.SAXON_SHADE.get(), ctx -> new net.minecraft.client.renderer.entity.VexRenderer(ctx) {
            @Override public ResourceLocation getTextureLocation(net.minecraft.world.entity.monster.Vex v) { return v.isCharging() ? SHADE_CHARGING : SHADE; }
        });
    }
}
