"""Loot tables for the chests and barrels in Logres' buildings (see LootProcessor).

    python3 tools/gen_loot.py
"""
import json, pathlib
OUT = pathlib.Path(__file__).resolve().parent.parent / "src/main/resources/data/ancientpeaks_lore/loot_tables/chests"

def item(name, w, lo=1, hi=1, ench=None, treasure=False, dmg=None):
    e = {"type": "minecraft:item", "name": name, "weight": w, "functions": []}
    if hi > 1 or lo > 1: e["functions"].append({"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}})
    if ench: e["functions"].append({"function": "minecraft:enchant_with_levels", "levels": {"type": "minecraft:uniform", "min": ench[0], "max": ench[1]}, "treasure": treasure})
    if dmg: e["functions"].append({"function": "minecraft:set_damage", "damage": {"type": "minecraft:uniform", "min": dmg[0], "max": dmg[1]}})
    if not e["functions"]: del e["functions"]
    return e

def tag(t, w, lo=1, hi=1):
    e = {"type": "minecraft:tag", "name": t, "expand": True, "weight": w}
    if hi > 1 or lo > 1: e["functions"] = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]
    return e

def table(name, w): return {"type": "minecraft:loot_table", "name": name, "weight": w}
def empty(w): return {"type": "minecraft:empty", "weight": w}
def pool(rolls, entries, bonus=0):
    p = {"rolls": rolls if isinstance(rolls, (int, float)) else {"type": "minecraft:uniform", "min": rolls[0], "max": rolls[1]}, "entries": entries}
    if bonus: p["bonus_rolls"] = bonus
    return p

IRON = [("minecraft:iron_sword", 10), ("minecraft:iron_axe", 7), ("minecraft:iron_pickaxe", 7), ("minecraft:iron_shovel", 4),
        ("minecraft:iron_helmet", 6), ("minecraft:iron_chestplate", 5), ("minecraft:iron_leggings", 5), ("minecraft:iron_boots", 6),
        ("minecraft:chainmail_chestplate", 3), ("minecraft:chainmail_helmet", 3), ("minecraft:bow", 6), ("minecraft:crossbow", 4), ("minecraft:shield", 4)]
DIAMOND = [("minecraft:diamond_sword", 3), ("minecraft:diamond_axe", 2), ("minecraft:diamond_pickaxe", 2), ("minecraft:diamond_helmet", 2),
           ("minecraft:diamond_chestplate", 1), ("minecraft:diamond_leggings", 1), ("minecraft:diamond_boots", 2)]

gear = pool([1, 2], [item(n, w, ench=(12, 22), dmg=(0.6, 1.0)) for n, w in IRON] +
                    [item(n, w, ench=(18, 30), dmg=(0.5, 0.95)) for n, w in DIAMOND] +
                    [item("minecraft:enchanted_book", 4, ench=(15, 28), treasure=True), empty(12)])
food = pool([2, 4], [item("minecraft:baked_potato", 14, 2, 6), item("minecraft:cooked_beef", 14, 2, 5), item("minecraft:bread", 10, 2, 5),
                     item("minecraft:wheat", 8, 3, 9), item("minecraft:golden_carrot", 6, 1, 4), item("minecraft:cooked_mutton", 6, 2, 4),
                     item("minecraft:apple", 6, 1, 4), item("minecraft:pumpkin_pie", 3, 1, 2), item("minecraft:golden_apple", 2),
                     item("minecraft:honey_bottle", 2, 1, 2)])
mats = pool([1, 3], [item("minecraft:iron_ingot", 14, 2, 7), item("minecraft:gold_ingot", 8, 1, 5), item("minecraft:copper_ingot", 6, 2, 8),
                     item("minecraft:raw_iron", 6, 2, 6), item("minecraft:raw_gold", 3, 1, 4), item("minecraft:coal", 8, 3, 10),
                     item("minecraft:lapis_lazuli", 5, 3, 9), item("minecraft:redstone", 4, 3, 9), item("minecraft:emerald", 5, 1, 4),
                     item("minecraft:diamond", 3, 1, 2), item("minecraft:iron_ore", 3, 1, 4), item("minecraft:gold_ore", 2, 1, 3),
                     item("minecraft:amethyst_shard", 3, 1, 5),
                     # other mods' metals and ores come in through the common forge tags
                     tag("forge:ingots", 10, 1, 5), tag("forge:ores", 5, 1, 3), tag("forge:raw_materials", 5, 1, 4), tag("forge:gems", 3, 1, 2)])
# the vanilla tables other mods add their loot to: now and then a chest holds a share of one of them
compat = pool(1, [empty(55), table("minecraft:chests/simple_dungeon", 12), table("minecraft:chests/village/village_weaponsmith", 10),
                  table("minecraft:chests/abandoned_mineshaft", 9), table("minecraft:chests/village/village_toolsmith", 7),
                  table("minecraft:chests/ruined_portal", 4), table("minecraft:chests/pillager_outpost", 3)])
misc = pool([0, 2], [item("minecraft:arrow", 8, 4, 16), item("minecraft:leather", 6, 2, 6), item("minecraft:string", 5, 2, 6),
                     item("minecraft:book", 4, 1, 3), item("minecraft:saddle", 2), item("minecraft:name_tag", 1), item("minecraft:experience_bottle", 4, 1, 4),
                     item("minecraft:torch", 6, 4, 12), item("minecraft:map", 1)])

def W(name, pools):
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"{name}.json").write_text(json.dumps({"type": "minecraft:chest", "pools": pools}, indent=2))

W("logres", [gear, food, mats, misc, compat])
# the same, with a lore book from the place's own group now and then (see LoreBooks / tools/gen_books.py)
def books(group, chance):
    return pool(1, [table(f"ancientpeaks_lore:books/{group}", int(chance * 80)), table("ancientpeaks_lore:books/all", int(chance * 20)),
                    empty(int((1 - chance) * 100))])
for g, c in (("village", 0.35), ("guard", 0.4), ("chapel", 0.6), ("harbour", 0.5), ("all", 0.3)):
    W(f"logres_{g}", [gear, food, mats, misc, compat, books(g, c)])
# a raided supply cart: what the raiders left - food, some gear, and almost always the books that tell of it
W("logres_cart", [pool([2, 4], food["entries"]), pool([0, 2], mats["entries"]), pool([0, 1], gear["entries"]),
                  pool(1, [table("ancientpeaks_lore:books/cart", 85), empty(15)]), pool(1, [table("ancientpeaks_lore:books/cart", 30), empty(70)])])
# barrels: a household's or a stall's stores - food and stuff, now and then a tool
W("logres_stores", [pool(1, [table("ancientpeaks_lore:books/village", 8), empty(92)]), pool([2, 4], food["entries"]), pool([0, 2], mats["entries"][:8] + [empty(20)]),
                    pool(1, [item(n, w, ench=(8, 16), dmg=(0.4, 0.9)) for n, w in IRON[:4]] + [empty(60)]),
                    pool(1, [empty(80), table("minecraft:chests/village/village_plains_house", 12), table("minecraft:chests/village/village_taiga_house", 8)])])
# Merlin's cabin: a scholar's stores - no lore books (his journal is on the lectern upstairs). Healing is there to be
# found by those who look: a draught of healing or a golden apple is what he needs.
def potion(p, w): return {"type": "minecraft:item", "name": "minecraft:potion", "weight": w, "functions": [{"function": "minecraft:set_potion", "id": p}]}
arcane = pool([2, 4], [item("minecraft:lapis_lazuli", 10, 3, 9), item("minecraft:amethyst_shard", 8, 2, 6), item("minecraft:glowstone_dust", 7, 2, 6),
                       item("minecraft:redstone", 6, 3, 8), item("minecraft:ender_pearl", 4, 1, 2), item("minecraft:experience_bottle", 6, 2, 5),
                       item("minecraft:paper", 6, 3, 9), item("minecraft:book", 6, 1, 3), item("minecraft:feather", 4, 2, 5), item("minecraft:ink_sac", 4, 1, 3),
                       item("minecraft:blaze_powder", 3, 1, 3), item("minecraft:nether_wart", 3, 2, 5), item("minecraft:spider_eye", 3, 1, 3),
                       item("minecraft:glass_bottle", 5, 2, 5), item("minecraft:candle", 5, 2, 4), item("minecraft:clock", 1), item("minecraft:compass", 2),
                       item("minecraft:enchanted_book", 4, ench=(18, 30), treasure=True)])
remedies = pool([1, 2], [potion("minecraft:healing", 8), potion("minecraft:strong_healing", 3), potion("minecraft:regeneration", 4),
                         potion("minecraft:fire_resistance", 3), potion("minecraft:night_vision", 3), item("minecraft:golden_apple", 4),
                         item("minecraft:glistering_melon_slice", 3, 1, 2), item("minecraft:golden_carrot", 4, 2, 5), empty(10)])
W("logres_merlin", [arcane, remedies, pool([1, 2], food["entries"]), pool([0, 1], gear["entries"])])
W("logres_merlin_stores", [pool([2, 4], food["entries"]), pool([0, 2], arcane["entries"][:12] + [empty(20)])])
print("loot tables written")
