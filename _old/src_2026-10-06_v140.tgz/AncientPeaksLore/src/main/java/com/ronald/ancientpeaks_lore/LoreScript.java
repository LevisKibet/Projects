package com.ronald.ancientpeaks_lore;

import java.util.ArrayList;
import java.util.List;

/**
 * Everything the characters say, in one place, with the timing of each cutscene's subtitles worked out from the
 * length of its lines - so the client's cutscenes (client/Cutscenes) and the server's clock (Merlin hands over his map
 * on the last line, then vanishes) always agree. 20 ticks = 1 second.
 */
public final class LoreScript {
    private LoreScript() {}

    /** One subtitle: shown from tick `from` to `to` of its scene. An empty speaker is a stage direction. */
    public record Said(int from, int to, String who, String text) {}

    /** Lines one after another from `start`: each stays up long enough to read (2 s plus about 17 letters a second). */
    static List<Said> timed(int start, String who, String... lines) {
        List<Said> out = new ArrayList<>();
        int t = start;
        for (String l : lines) {
            int len = 40 + (int) Math.round(l.length() * 1.15);
            out.add(new Said(t, t + len, who, l));
            t += len + 8;
        }
        return out;
    }
    static int end(List<Said> s) { return s.get(s.size() - 1).to(); }

    // ------------------------------------------------------------------ Merlin
    /** 1. First encounter - when you first speak to him upstairs, the raiders below cleared out. Then the siege begins. */
    public static final List<Said> MERLIN_INTRO = timed(14, "Merlin",
            "So... someone answered the bell after all.",
            "I heard the clash of steel below... thank you for clearing out those raiders. They tracked me into the chapel and cornered me up here.",
            "Their blades ran deep, and my breath grows thin. Please... if you carry a healing potion, bring it to me quickly before the rest of them breach the sanctuary!");
    public static final int MERLIN_INTRO_LENGTH = end(MERLIN_INTRO) + 24;

    /** 2. Spoken to again during the siege, without the cure. */
    public static final String MERLIN_SIEGE = "My strength is fading fast... bring me a healing potion or splash it upon my wounds! Hold them off!";
    /** 3. The siege lost: the time ran out, or everyone left. */
    public static final String MERLIN_FAIL = "The darkness... takes me... Come back... when you are ready to stand against them...";

    /** 4. Farewell - healed, he drives off the raiders, tells the tale, hands over his map and fades into light. */
    public static final List<Said> MERLIN_FAREWELL = timed(14, "Merlin",
            "Ah... the warmth of life returns, if only for a fleeting moment. Thank you, traveler.",
            "I cannot remain—my body is broken, but your kindness bought me enough breath to pass on the charge.",
            "Across the western sea lies Logres, an island forgotten by time. On its high meadow, Excalibur slumbers in stone.",
            "A hundred winters ago, King Arthur fought Vortigern on those grounds. When Vortigern struck a cowardly blow, Arthur knew the kingdom was lost if the usurper claimed the blade.",
            "Using a binding ward I had carved into the pedestal, Arthur drove Excalibur deep into the rock—sacrificing his own life to freeze Vortigern into stone beside him.",
            "Take my map. It will lead you to the gate across the water. Only someone carrying my blessing can draw the sword... and finish what Arthur started.");
    /** When he gives the map and his blessing (as the last line begins), and when he is gone. */
    public static final int MERLIN_MAP_AT = MERLIN_FAREWELL.get(MERLIN_FAREWELL.size() - 1).from() + 10;
    public static final int MERLIN_FAREWELL_LENGTH = end(MERLIN_FAREWELL) + 50;

    // ------------------------------------------------------------------ Vortigern
    /** 1. Awakening - plays when a blessed player draws Excalibur; the statue's clock (SCENE) is the scene's length. */
    public static final List<Said> VORTIGERN_WAKE = List.of(
            new Said(16, 96, "", "The heavy sound of stone cracking open under immense pressure..."),
            new Said(150, 206, "Vortigern", "Arthur! Where are you?! Show yourself!"),
            new Said(212, 266, "Vortigern", "...Gone? Dead by his own cowardly trick?"),
            new Said(272, 318, "Vortigern", "No matter. The sword is mine now, and nothing stands in my way!"));
    /** 2. At half health. */
    public static final String VORTIGERN_PHASE_TWO = "Enough!";
    /** 3. Defeated. */
    public static final String VORTIGERN_DEFEAT = "My... purpose... excal...";
}
