package com.ronald.ancientpeaks.mixin;

import com.ronald.ancientpeaks.world.IslandSampler;
import dev.streamsreflowing.core.compose.ColumnPlan;
import dev.streamsreflowing.core.plate.PlateKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * The island has its own streams (see Island.buildStreams). When Streams Reflowing is installed as well, it is kept
 * off the island entirely: every column there reports "no stream", so it carves nothing and vetoes nothing. Only
 * applied when Streams Reflowing is present (AncientPeaksMixinPlugin).
 */
@Pseudo
@Mixin(targets = "dev.streamsreflowing.core.RiverEngine", remap = false)
public class StreamsVetoMixin {
    private static final long NO_STREAM = ((long) Integer.MIN_VALUE << 32) | (Integer.MIN_VALUE & 0xFFFFFFFFL);

    private static boolean island(int x, int z) {
        IslandSampler s = IslandSampler.ACTIVE;
        return s != null && s.islandAt(x, z) != null;
    }

    @Inject(method = "vetoProbeAt(II)J", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void ancientpeaks$veto(int x, int z, CallbackInfoReturnable<Long> cir) {
        if (island(x, z)) cir.setReturnValue(NO_STREAM);
    }

    @Inject(method = {"plan(II)Ldev/streamsreflowing/core/compose/ColumnPlan;", "planLean(II)Ldev/streamsreflowing/core/compose/ColumnPlan;",
            "altPlan(II)Ldev/streamsreflowing/core/compose/ColumnPlan;"}, at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void ancientpeaks$noPlan(int x, int z, CallbackInfoReturnable<ColumnPlan> cir) {
        if (island(x, z)) cir.setReturnValue(ColumnPlan.NONE);
    }

    @Inject(method = "planWithin", at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void ancientpeaks$noPlanWithin(PlateKey key, int x, int z, CallbackInfoReturnable<ColumnPlan> cir) {
        if (island(x, z)) cir.setReturnValue(ColumnPlan.NONE);
    }

    @Inject(method = {"inAnyChannel(II)Z", "inCorridor(II)Z"}, at = @At("HEAD"), cancellable = true, remap = false, require = 0)
    private void ancientpeaks$noChannel(int x, int z, CallbackInfoReturnable<Boolean> cir) {
        if (island(x, z)) cir.setReturnValue(false);
    }
}
