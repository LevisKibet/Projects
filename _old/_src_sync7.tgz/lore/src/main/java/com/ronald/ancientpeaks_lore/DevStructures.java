package com.ronald.ancientpeaks_lore;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.metadata.MetadataSectionSerializer;
import net.minecraft.server.packs.metadata.pack.PackMetadataSection;
import net.minecraft.server.packs.resources.IoSupplier;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

/**
 * A data pack backed by a plain folder of structure files:
 *   FOLDER/village/houses/farmer_cottage.nbt  ->  ancientpeaks_lore:village/houses/farmer_cottage
 * The folder is set in config/ancientpeaks_lore-dev.txt (first non-# line). With no file, ~/Desktop/Schematics/ancient_peaks
 * is used if it exists. Delete the file's path (or the folder) and the structures baked into the jar are used instead.
 */
public final class DevStructures implements PackResources {
    private static final String PREFIX = "structures/";
    private final String id;
    private final Path root;

    DevStructures(String id, Path root) { this.id = id; this.root = root; }

    public static Path folder() {
        Path cfg = FMLPaths.CONFIGDIR.get().resolve("ancientpeaks_lore-dev.txt");
        Path fallback = Paths.get(System.getProperty("user.home"), "Desktop", "Schematics", "ancient_peaks");
        try {
            if (!Files.exists(cfg)) {
                Files.writeString(cfg, "# Folder of .nbt structures to load instead of the ones inside the mod (testing only).\n"
                        + "# Sub-folders become part of the name: <folder>/village/houses/x.nbt -> ancientpeaks_lore:village/houses/x\n"
                        + "# Leave no path here to use the structures baked into the jar.\n" + fallback + "\n");
            }
            for (String line : Files.readAllLines(cfg)) {
                line = line.strip();
                if (line.isEmpty() || line.startsWith("#")) continue;
                if (line.startsWith("~")) line = System.getProperty("user.home") + line.substring(1);
                Path p = Paths.get(line);
                return Files.isDirectory(p) ? p : null;
            }
        } catch (IOException e) {
            AncientPeaksLore.LOGGER.warn("Could not read {}", cfg, e);
        }
        return null;
    }

    private Path fileFor(ResourceLocation rl) {
        if (!rl.getNamespace().equals(AncientPeaksLore.MODID) || !rl.getPath().startsWith(PREFIX)) return null;
        Path p = root.resolve(rl.getPath().substring(PREFIX.length())).normalize();
        return p.startsWith(root) && Files.isRegularFile(p) ? p : null;
    }

    @Override public IoSupplier<InputStream> getRootResource(String... path) { return null; }

    @Override
    public IoSupplier<InputStream> getResource(PackType type, ResourceLocation rl) {
        if (type != PackType.SERVER_DATA) return null;
        Path p = fileFor(rl);
        return p == null ? null : IoSupplier.create(p);
    }

    @Override
    public void listResources(PackType type, String namespace, String path, ResourceOutput out) {
        if (type != PackType.SERVER_DATA || !namespace.equals(AncientPeaksLore.MODID)) return;
        if (!(path + "/").startsWith(PREFIX) && !PREFIX.startsWith(path + "/")) return;
        try (Stream<Path> s = Files.walk(root)) {
            for (Path f : (Iterable<Path>) s.filter(Files::isRegularFile)::iterator) {
                String rel = root.relativize(f).toString().replace('\\', '/');
                if (!rel.endsWith(".nbt")) continue;
                String rp = PREFIX + rel;
                if (!rp.startsWith(path)) continue;
                if (!rp.equals(rp.toLowerCase(Locale.ROOT)) || !ResourceLocation.isValidPath(rp)) {
                    AncientPeaksLore.LOGGER.warn("Skipping {}: names must be lowercase with no spaces", f);
                    continue;
                }
                out.accept(new ResourceLocation(AncientPeaksLore.MODID, rp), IoSupplier.create(f));
            }
        } catch (IOException e) {
            AncientPeaksLore.LOGGER.warn("Could not list {}", root, e);
        }
    }

    @Override public Set<String> getNamespaces(PackType type) { return type == PackType.SERVER_DATA ? Set.of(AncientPeaksLore.MODID) : Set.of(); }

    @SuppressWarnings("unchecked")
    @Override
    public <T> T getMetadataSection(MetadataSectionSerializer<T> s) {
        if (s.getMetadataSectionName().equals("pack")) return (T) new PackMetadataSection(Component.literal("Ancient Peaks dev structures"), 15);
        return null;
    }

    @Override public String packId() { return id; }
    @Override public boolean isBuiltin() { return true; }
    @Override public void close() { }

    /** All template ids currently in the folder (for the gallery). */
    public static List<ResourceLocation> listIds(net.minecraft.server.MinecraftServer server, String under) {
        String base = PREFIX + (under == null ? "" : under);
        return server.getResourceManager().listResources("structures", rl -> rl.getPath().endsWith(".nbt")).keySet().stream()
                .filter(rl -> rl.getNamespace().equals(AncientPeaksLore.MODID) && rl.getPath().startsWith(base))
                .map(rl -> new ResourceLocation(rl.getNamespace(), rl.getPath().substring(PREFIX.length(), rl.getPath().length() - 4)))
                .sorted((a, b) -> a.getPath().compareTo(b.getPath())).toList();
    }
}
