package com.ronald.ancientpeaks.world;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.material.Fluids;

import java.util.ArrayList;
import java.util.List;

/** Fills the island's rivers, tarns, strait and megalake; water spilling over each river step becomes a waterfall. */
public class GorgeRiverFeature extends Feature<NoneFeatureConfiguration> {
    public GorgeRiverFeature(Codec<NoneFeatureConfiguration> codec) { super(codec); }

    static IslandSampler sampler(WorldGenLevel level) {
        if (!(level instanceof WorldGenRegion region)) return null;
        RandomState rs = region.getLevel().getChunkSource().randomState();
        return ((HighlandsAccess) (Object) rs).ancientpeaks$sampler();
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        return run(ctx.level(), new ChunkPos(ctx.origin()), ctx.random());
    }

    /** Runs straight after the chunk's decoration pass (see ChunkGeneratorMixin), outside the feature system. */
    public static boolean run(WorldGenLevel level, ChunkPos cp, net.minecraft.util.RandomSource random) {
        IslandSampler sampler = sampler(level);
        if (sampler == null) return false;
        IslandSampler.Column col = new IslandSampler.Column();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        List<BlockPos> placed = new ArrayList<>();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = cp.getMinBlockX() + dx, z = cp.getMinBlockZ() + dz;
                if (sampler.islandAt(x, z) == null) continue;
                sampler.fill(col, x, z);
                if (col.m <= 0.5) continue;
                int top = sampler.waterTop(col);
                for (int y = 28; y <= top; y++) {
                    if (!sampler.isWater(col, x, y, z)) continue;
                    pos.set(x, y, z);
                    if (!level.getBlockState(pos).isAir()) continue;
                    if (level.getBlockState(pos.below()).isAir()) continue;       // never leave water floating
                    level.setBlock(pos, Blocks.WATER.defaultBlockState(), 2);
                    if (y > 62) placed.add(pos.immutable());
                }
                if (sampler.tarnOf(col) >= 0) decorateTarn(level, sampler, col, x, z, top, random, pos);
            }
        }
        for (BlockPos p : placed) {
            for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
                if (level.getBlockState(p.relative(d)).isAir()) { level.scheduleTick(p, Fluids.WATER, 1 + (p.hashCode() & 7)); break; }
            }
        }
        if (IslandSampler.DEBUG && !placed.isEmpty()) System.out.println("[ancientpeaks] chunk " + cp + " placed " + placed.size() + " water above sea level");
        return !placed.isEmpty();
    }

    /** Lake life: springs, seagrass, kelp and sea pickles on the floor; tall grass and ferns along the shore. */
    private static void decorateTarn(WorldGenLevel level, IslandSampler s, IslandSampler.Column col, int x, int z, int top,
                                     net.minecraft.util.RandomSource random, BlockPos.MutableBlockPos pos) {
        double td = s.tarnDist(col), r = s.tarnRadius(col);
        int lvl = s.tarnLevel(col);
        if (td < r * 0.97) {
            int y = lvl;
            while (y > lvl - 12 && level.getBlockState(pos.set(x, y, z)).is(Blocks.WATER)) y--;
            int depth = lvl - y;                                  // water blocks above the floor block at y
            if (depth < 1) return;
            BlockPos floor = new BlockPos(x, y, z);
            if (!level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP)) return;
            float f = random.nextFloat();
            if (s.inTarnCore(col) && f < 0.04f) {                 // a spring: soul sand sending up bubbles
                level.setBlock(floor, Blocks.SOUL_SAND.defaultBlockState(), 2);
                for (int yy = y + 1; yy <= lvl; yy++)
                    level.setBlock(pos.set(x, yy, z), Blocks.BUBBLE_COLUMN.defaultBlockState().setValue(net.minecraft.world.level.block.BubbleColumnBlock.DRAG_DOWN, false), 2);
            } else if (f < 0.10f && depth >= 4) {                 // kelp
                int h = 1 + random.nextInt(depth - 2);
                for (int k = 1; k <= h; k++)
                    level.setBlock(pos.set(x, y + k, z), k == h ? Blocks.KELP.defaultBlockState().setValue(net.minecraft.world.level.block.KelpBlock.AGE, 20 + random.nextInt(4))
                            : Blocks.KELP_PLANT.defaultBlockState(), 2);
            } else if (f < 0.14f) {                               // sea pickles, glowing on the floor
                level.setBlock(pos.set(x, y + 1, z), Blocks.SEA_PICKLE.defaultBlockState()
                        .setValue(net.minecraft.world.level.block.SeaPickleBlock.PICKLES, 1 + random.nextInt(4))
                        .setValue(net.minecraft.world.level.block.SeaPickleBlock.WATERLOGGED, true), 2);
            } else if (f < 0.24f && depth >= 3) {                 // tall seagrass
                level.setBlock(pos.set(x, y + 1, z), Blocks.TALL_SEAGRASS.defaultBlockState()
                        .setValue(net.minecraft.world.level.block.TallSeagrassBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.LOWER), 2);
                level.setBlock(pos.set(x, y + 2, z), Blocks.TALL_SEAGRASS.defaultBlockState()
                        .setValue(net.minecraft.world.level.block.TallSeagrassBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER), 2);
            } else if (f < 0.55f) {                               // seagrass
                level.setBlock(pos.set(x, y + 1, z), Blocks.SEAGRASS.defaultBlockState(), 2);
            }
        } else if (td < r + 8) {
            // the shore: tall grass, grass and ferns, thinning out away from the water
            if (random.nextFloat() > 0.75f - (float) ((td - r) / 8) * 0.45f) return;
            int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.WORLD_SURFACE_WG, x, z);
            BlockPos at = new BlockPos(x, y, z);
            if (!level.getBlockState(at).isAir() || !level.getBlockState(at.above()).isAir()) return;
            var ground = level.getBlockState(at.below());
            if (!(ground.is(Blocks.GRASS_BLOCK) || ground.is(Blocks.MOSS_BLOCK) || ground.is(Blocks.DIRT) || ground.is(Blocks.PODZOL))) return;
            float f = random.nextFloat();
            if (f < 0.55f) {
                var tall = random.nextFloat() < 0.8f ? Blocks.TALL_GRASS : Blocks.LARGE_FERN;
                level.setBlock(at, tall.defaultBlockState().setValue(net.minecraft.world.level.block.DoublePlantBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.LOWER), 2);
                level.setBlock(at.above(), tall.defaultBlockState().setValue(net.minecraft.world.level.block.DoublePlantBlock.HALF, net.minecraft.world.level.block.state.properties.DoubleBlockHalf.UPPER), 2);
            } else {
                level.setBlock(at, (f < 0.85f ? Blocks.GRASS : Blocks.FERN).defaultBlockState(), 2);
            }
        }
    }
}
