package com.ronald.rivergence.mixin;

import com.ronald.rivergence.world.WeatherHook;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** On the client, a local shower near the player counts as rain (see WeatherHook). */
@Mixin(Level.class)
public abstract class LevelRainMixin {
    @Shadow public abstract boolean isClientSide();

    @Inject(method = "getRainLevel", at = @At("RETURN"), cancellable = true)
    private void rivergence$localRain(float pt, CallbackInfoReturnable<Float> cir) {
        if (!isClientSide()) return;
        float v = cir.getReturnValue();
        WeatherHook.vanilla = v;
        float l = WeatherHook.local;
        if (l > v) cir.setReturnValue(l);
    }
}
