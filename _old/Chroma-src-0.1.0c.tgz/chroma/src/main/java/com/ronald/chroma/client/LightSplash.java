package com.ronald.chroma.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.ronald.chroma.content.Curve;
import com.ronald.chroma.content.LineEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Coloured light thrown onto the surfaces round a line, added on top of the world like real light (the way Luxium
 * does it). The ordinary coloured lighting only tints the light that's already there, which is subtle; this adds a
 * soft wash of the line's own colour that fades with distance and faces toward it. Worked out once per line (and
 * again when the line or the blocks round it change), then drawn each frame. Off when Luxium is installed, since
 * Luxium's own lights already do this.
 */
public final class LightSplash {
    private LightSplash() {}

    static final boolean ON = !net.minecraftforge.fml.ModList.get().isLoaded("luxium");

    /** Each face: 4 corners of x, y, z, r, g, b (world space, colour already scaled by distance and facing). */
    private record Cache(int revision, long built, float[] quads) {}
    private static final Map<LineEntity, Cache> CACHE = new WeakHashMap<>();

    static void render(LineEntity line, List<Curve.Sample> samples, BlockPos o, PoseStack.Pose pose, MultiBufferSource buf, double t) {
        if (!ON || samples.size() < 2) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) return;
        Cache c = CACHE.get(line);
        long now = level.getGameTime();
        if (c == null || c.revision != line.revision || now - c.built > 100) {
            c = new Cache(line.revision, now, build(level, line, samples));
            CACHE.put(line, c);
        }
        if (c.quads.length == 0) return;
        // fade out where daylight is strong: only the dark lets the colour show
        float daylight = Math.max(0, 1f - level.getSkyDarken() / 11f);
        float pulse = line.kind() == Curve.STRIP ? Curve.stripBrightness(line.mode(), Curve.SPEEDS[line.speed()], 0, t) : 1f;
        VertexConsumer vc = buf.getBuffer(RenderType.lightning());
        Matrix4f m = pose.pose();
        float[] q = c.quads;
        for (int i = 0; i < q.length; i += 24) {
            for (int pass = 0; pass < 2; pass++) {            // both windings, so it shows whichever way the face is wound
                for (int k = 0; k < 4; k++) {
                    int v = i + (pass == 0 ? k : 3 - k) * 6;
                    vc.vertex(m, q[v] - o.getX(), q[v + 1] - o.getY(), q[v + 2] - o.getZ())
                            .color(q[v + 3], q[v + 4], q[v + 5], pulse * (1f - daylight * 0.85f)).endVertex();
                }
            }
        }
    }

    /** Find the faces round the line's light and how much of its colour reaches each corner. */
    private static float[] build(ClientLevel level, LineEntity line, List<Curve.Sample> samples) {
        int colour = Curve.castColour(line.colours());
        float cr = ((colour >> 16) & 255) / 255f, cg = ((colour >> 8) & 255) / 255f, cb = (colour & 255) / 255f;
        float mx = Math.max(0.01f, Math.max(cr, Math.max(cg, cb)));
        cr /= mx; cg /= mx; cb /= mx;
        boolean bright = line.kind() == Curve.STRIP;
        double radius = bright ? 5.0 : 4.0;
        float strength = bright ? 0.42f : 0.32f;

        // light sources along the line, a block apart
        java.util.List<Vec3> lights = new java.util.ArrayList<>();
        double next = 0;
        for (Curve.Sample s : samples) {
            if (s.s() < next) continue;
            next = s.s() + 1.0;
            lights.add(s.pos().add(s.normal().scale(0.25)));
        }
        if (lights.size() > 64) lights = lights.subList(0, 64);

        Map<Long, float[]> faces = new HashMap<>();    // key: block pos + face -> 4 corner intensities
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos(), n = new BlockPos.MutableBlockPos();
        int r = (int) Math.ceil(radius);
        for (Vec3 l : lights) {
            BlockPos c = BlockPos.containing(l);
            for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
                m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                BlockState st = level.getBlockState(m);
                if (!st.canOcclude()) continue;
                for (Direction d : Direction.values()) {
                    n.setWithOffset(m, d);
                    if (level.getBlockState(n).canOcclude()) continue;          // hidden face
                    Vec3[] corners = corners(m, d);
                    Vec3 centre = corners[0].add(corners[2]).scale(0.5);
                    Vec3 nrm = Vec3.atLowerCornerOf(d.getNormal());
                    if (nrm.dot(l.subtract(centre)) <= -0.05) continue;         // faces away from the light
                    long key = m.asLong() * 6 + d.ordinal();
                    float[] acc = faces.computeIfAbsent(key, k -> new float[4]);
                    for (int i = 0; i < 4; i++) {
                        Vec3 to = l.subtract(corners[i]);
                        double dist = to.length();
                        if (dist >= radius) continue;
                        double fall = 1 - dist / radius;
                        double facing = dist < 1e-4 ? 1 : 0.35 + 0.65 * Math.max(0, nrm.dot(to) / dist);
                        acc[i] += (float) (fall * fall * facing);
                    }
                }
            }
        }
        float[] out = new float[faces.size() * 24];
        int k = 0;
        for (Map.Entry<Long, float[]> e : faces.entrySet()) {
            long key = e.getKey();
            BlockPos p = BlockPos.of(Math.floorDiv(key, 6));
            Direction d = Direction.values()[(int) Math.floorMod(key, 6)];
            float[] a = e.getValue();
            if (a[0] + a[1] + a[2] + a[3] < 0.02f) continue;
            float sky = level.getBrightness(LightLayer.SKY, p.relative(d)) / 15f;
            Vec3[] cs = corners(p, d);
            Vec3 lift = Vec3.atLowerCornerOf(d.getNormal()).scale(0.003);
            for (int i = 0; i < 4; i++) {
                float v = Math.min(1f, a[i]) * strength * (1f - sky * 0.5f);
                Vec3 q = cs[i].add(lift);
                out[k++] = (float) q.x; out[k++] = (float) q.y; out[k++] = (float) q.z;
                out[k++] = cr * v; out[k++] = cg * v; out[k++] = cb * v;
            }
        }
        return java.util.Arrays.copyOf(out, k);
    }

    /** The four corners of a block face, in order round it. */
    private static Vec3[] corners(BlockPos p, Direction d) {
        double x = p.getX(), y = p.getY(), z = p.getZ();
        return switch (d) {
            case UP -> new Vec3[]{new Vec3(x, y + 1, z), new Vec3(x, y + 1, z + 1), new Vec3(x + 1, y + 1, z + 1), new Vec3(x + 1, y + 1, z)};
            case DOWN -> new Vec3[]{new Vec3(x, y, z), new Vec3(x + 1, y, z), new Vec3(x + 1, y, z + 1), new Vec3(x, y, z + 1)};
            case NORTH -> new Vec3[]{new Vec3(x, y, z), new Vec3(x, y + 1, z), new Vec3(x + 1, y + 1, z), new Vec3(x + 1, y, z)};
            case SOUTH -> new Vec3[]{new Vec3(x, y, z + 1), new Vec3(x + 1, y, z + 1), new Vec3(x + 1, y + 1, z + 1), new Vec3(x, y + 1, z + 1)};
            case WEST -> new Vec3[]{new Vec3(x, y, z), new Vec3(x, y, z + 1), new Vec3(x, y + 1, z + 1), new Vec3(x, y + 1, z)};
            case EAST -> new Vec3[]{new Vec3(x + 1, y, z), new Vec3(x + 1, y + 1, z), new Vec3(x + 1, y + 1, z + 1), new Vec3(x + 1, y, z + 1)};
        };
    }
}
