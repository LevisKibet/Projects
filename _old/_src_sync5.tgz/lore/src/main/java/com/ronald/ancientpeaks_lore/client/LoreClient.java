package com.ronald.ancientpeaks_lore.client;

import com.ronald.ancientpeaks_lore.AncientPeaksLore;
import com.ronald.ancientpeaks_lore.LoreContent;
import com.ronald.ancientpeaks_lore.Merlin;
import com.ronald.ancientpeaks_lore.Vortigern;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/**
 * Client only. Merlin is a GeckoLib model (one animation: lying wounded). Vortigern is a plain humanoid with a
 * player-layout skin (textures/entity/vortigern.png); Epic Fight takes him over, draws him with its biped mesh in that
 * skin, and plays its greatsword moveset on him.
 */
public final class LoreClient {
    private LoreClient() {}
    static final ResourceLocation VORTIGERN_SKIN = new ResourceLocation(AncientPeaksLore.MODID, "textures/entity/vortigern.png");

    public static void init(IEventBus bus) {
        bus.addListener(LoreClient::renderers);
        bus.addListener((RegisterClientReloadListenersEvent e) -> e.registerReloadListener((ResourceManagerReloadListener) rm -> ClientRes.forget()));
    }

    private static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(LoreContent.MERLIN.get(), ctx -> {
            GeoEntityRenderer<Merlin> r = new GeoEntityRenderer<>(ctx, new CharacterModel<>("merlin", "minecraft:textures/entity/illager/illusioner.png"));
            r.withScale(0.9375f);
            return r;
        });
        e.registerEntityRenderer(LoreContent.VORTIGERN.get(), ctx -> {
            HumanoidMobRenderer<Vortigern, HumanoidModel<Vortigern>> r = new HumanoidMobRenderer<>(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.7f) {
                @Override public ResourceLocation getTextureLocation(Vortigern v) { return VORTIGERN_SKIN; }
                @Override protected void scale(Vortigern v, PoseStack pose, float partial) { pose.scale(1.3f, 1.3f, 1.3f); }
            };
            r.addLayer(new HumanoidArmorLayer<>(r, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                    new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), ctx.getModelManager()));
            return r;
        });
    }
}
