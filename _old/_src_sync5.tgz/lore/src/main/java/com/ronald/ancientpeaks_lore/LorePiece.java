package com.ronald.ancientpeaks_lore;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.TemplateStructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.levelgen.structure.templatesystem.BlockIgnoreProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

import java.util.Map;

/**
 * One structure template placed whole, rotated about its own centre. Its air only clears ground inside the building
 * (see {@link OutsideAirProcessor}); with "fill" on, the ground floor gets a rough cobble footing down to the ground
 * wherever the land falls away beneath it, so nothing hangs in the air and no box is cut into the hill.
 */
public class LorePiece extends TemplateStructurePiece {
    private final boolean fill;

    static StructurePlaceSettings settings(StructureTemplateManager mgr, ResourceLocation id, Rotation rot, BlockPos pivot) {
        StructureTemplate t = mgr.get(id).orElse(null);
        return new StructurePlaceSettings().setRotation(rot).setRotationPivot(pivot)
                .addProcessor(BlockIgnoreProcessor.STRUCTURE_BLOCK)
                .addProcessor(new OutsideAirProcessor(OutsideAirProcessor.shape(t)))
                .setFinalizeEntities(true);
    }

    public LorePiece(StructureTemplateManager mgr, ResourceLocation id, BlockPos origin, Rotation rot, BlockPos pivot, boolean fill) {
        super(AncientPeaksLore.PIECE.get(), 0, mgr, id, id.toString(), settings(mgr, id, rot, pivot), origin);
        this.fill = fill;
    }

    public LorePiece(StructurePieceSerializationContext ctx, CompoundTag tag) {
        super(AncientPeaksLore.PIECE.get(), tag, ctx.structureTemplateManager(),
                rl -> settings(ctx.structureTemplateManager(), rl, Rotation.valueOf(tag.getString("Rot")), new BlockPos(tag.getInt("PX"), 0, tag.getInt("PZ"))));
        this.fill = tag.getBoolean("Fill");
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext ctx, CompoundTag tag) {
        super.addAdditionalSaveData(ctx, tag);
        tag.putString("Rot", placeSettings.getRotation().name());
        tag.putInt("PX", placeSettings.getRotationPivot().getX());
        tag.putInt("PZ", placeSettings.getRotationPivot().getZ());
        tag.putBoolean("Fill", fill);
    }

    @Override
    public void postProcess(WorldGenLevel level, StructureManager sm, ChunkGenerator gen, RandomSource random, BoundingBox box, ChunkPos cp, BlockPos pivot) {
        super.postProcess(level, sm, gen, random, box, cp, pivot);
        String name = templateName.toLowerCase(java.util.Locale.ROOT);
        if (name.contains("churches/") && (name.contains("merlin") || name.contains("besieged"))) placeMerlin(level, box);
        if (name.contains("swords/") && name.contains("pedestal")) placeSword(level, box);
        if (!fill) return;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (Map.Entry<Long, int[]> e : OutsideAirProcessor.shape(template).columns().entrySet()) {
            int lowest = e.getValue()[1];
            if (lowest > 1) continue;                                   // only the ground floor stands on the land
            int lx = (int) (e.getKey() >> 32), lz = (int) (long) e.getKey();
            BlockPos w = StructureTemplate.calculateRelativePosition(placeSettings, new BlockPos(lx, lowest, lz)).offset(templatePosition);
            if (!box.isInside(w)) continue;
            long h = w.asLong() * 0x9E3779B97F4A7C15L;
            for (int y = w.getY() - 1, n = 0; n < 14 && y > level.getMinBuildHeight(); y--, n++) {
                m.set(w.getX(), y, w.getZ());
                BlockState st = level.getBlockState(m);
                if (!(st.isAir() || st.canBeReplaced() || !st.getFluidState().isEmpty())) break;
                int k = (int) Math.floorMod(h + y * 7919L, 10L);
                level.setBlock(m, (k < 4 ? Blocks.MOSSY_COBBLESTONE : k < 9 ? Blocks.COBBLESTONE : Blocks.DIRT).defaultBlockState(), 2);
            }
        }
    }

    /** Merlin lies wounded near the middle of his chapel floor (once: only the chunk holding the middle does it). */
    private void placeMerlin(WorldGenLevel level, BoundingBox box) {
        var size = template.getSize();
        BlockPos mid = StructureTemplate.calculateRelativePosition(placeSettings, new BlockPos(size.getX() / 2, 1, size.getZ() / 2)).offset(templatePosition);
        if (!box.isInside(mid)) return;
        BlockPos spot = null;
        search:
        for (int r = 0; r <= 4; r++)
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                for (int dy = 0; dy <= 6; dy++) {
                    BlockPos p = mid.offset(dx, dy, dz);
                    if (!box.isInside(p)) continue;
                    if (level.getBlockState(p.below()).isFaceSturdy(level, p.below(), net.minecraft.core.Direction.UP)
                            && level.getBlockState(p).getCollisionShape(level, p).isEmpty() && level.getBlockState(p.above()).getCollisionShape(level, p.above()).isEmpty()) {
                        spot = p; break search;
                    }
                }
            }
        if (spot == null) spot = mid;
        Merlin m = LoreContent.MERLIN.get().create(level.getLevel());
        if (m == null) return;
        m.moveTo(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, level.getRandom().nextFloat() * 360, 0);
        m.setPersistenceRequired();
        level.addFreshEntity(m);
        AncientPeaksLore.LOGGER.info("[ancientpeaks_lore] Merlin lies wounded in his chapel at {}", spot.toShortString());
    }

    /** The plain stone at the top of the pedestal becomes the stone with Excalibur in it. */
    private void placeSword(WorldGenLevel level, BoundingBox box) {
        var size = template.getSize();
        BlockPos mid = StructureTemplate.calculateRelativePosition(placeSettings, new BlockPos(size.getX() / 2, 0, size.getZ() / 2)).offset(templatePosition);
        BlockPos best = null;
        for (StructureTemplate.StructureBlockInfo info : template.filterBlocks(templatePosition, placeSettings, Blocks.STONE)) {
            BlockPos p = info.pos();
            if (Math.abs(p.getX() - mid.getX()) > 2 || Math.abs(p.getZ() - mid.getZ()) > 2) continue;
            if (best == null || p.getY() > best.getY()) best = p;
        }
        if (best == null || !box.isInside(best)) return;
        level.setBlock(best, LoreContent.SWORD_IN_STONE.get().defaultBlockState(), 2);
        BlockPos above = best.above();
        if (!level.getBlockState(above).isAir() && level.getBlockState(above).canBeReplaced()) level.setBlock(above, Blocks.AIR.defaultBlockState(), 2);
        AncientPeaksLore.LOGGER.info("[ancientpeaks_lore] Excalibur waits in the stone at {}", best.toShortString());
    }

    @Override
    protected void handleDataMarker(String name, BlockPos pos, ServerLevelAccessor level, RandomSource random, BoundingBox box) { }
}
