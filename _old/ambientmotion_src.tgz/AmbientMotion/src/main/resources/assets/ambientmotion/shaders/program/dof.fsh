#version 150

// Depth of field. DofMode: 0 off, 1 autofocus (on whatever is under the crosshair), 2 far blur (sharp up close,
// soft in the distance), 3 tilt-shift (a band across the middle in focus, like a miniature).

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;
uniform sampler2D FocusSampler;
uniform mat4 InvViewProj;
uniform float DofMode;
uniform float DofStrength;      // the widest blur, in pixels
uniform float FocusDistance;    // far blur: where it starts, in blocks
uniform vec2 InSize;

in vec2 texCoord;
in vec2 oneTexel;
out vec4 fragColor;

float unpack(vec3 e) { return dot(e, vec3(1.0, 1.0 / 255.0, 1.0 / 65025.0)); }

float dist(vec2 uv) {
    float d = texture(DepthSampler, uv).r;
    vec4 p = InvViewProj * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    return length(p.xyz / p.w);
}

float coc(vec2 uv) {
    int mode = int(DofMode + 0.5);
    if (mode == 3) return smoothstep(0.10, 0.42, abs(uv.y - 0.5));
    float d = dist(uv);
    if (mode == 2) return smoothstep(FocusDistance, FocusDistance * 2.5 + 8.0, d);
    float f = exp2(unpack(texture(FocusSampler, vec2(0.5)).rgb) * 10.0) - 1.0;
    return clamp(abs(d - f) / (f * 0.9 + 3.0), 0.0, 1.0);
}

void main() {
    vec3 here = texture(DiffuseSampler, texCoord).rgb;
    if (DofMode < 0.5 || DofStrength <= 0.01) { fragColor = vec4(here, 1.0); return; }
    float c = coc(texCoord);
    float radius = c * DofStrength;
    if (radius < 0.5) { fragColor = vec4(here, 1.0); return; }
    // a soft disc of samples (golden angle spiral); samples much sharper than this pixel count for less, so crisp
    // things in focus don't bleed a halo into the blur behind them
    vec3 sum = here;
    float wsum = 1.0;
    const int N = 24;
    for (int i = 1; i <= N; i++) {
        float r = sqrt(float(i) / float(N)) * radius;
        float a = float(i) * 2.39996323;
        vec2 uv = texCoord + vec2(cos(a), sin(a)) * r * oneTexel;
        uv = clamp(uv, vec2(0.001), vec2(0.999));
        float w = DofMode > 2.5 ? 1.0 : clamp(coc(uv) * 1.5 / max(c, 0.05), 0.15, 1.0);
        sum += texture(DiffuseSampler, uv).rgb * w;
        wsum += w;
    }
    fragColor = vec4(sum / wsum, 1.0);
}
