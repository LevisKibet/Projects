#version 150

// Camera motion blur: where each pixel was on screen last frame (from its depth and last frame's camera), and a
// smear along the way it moved. Strength is the shutter: 0 = none, 1 = the whole frame's movement.

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;
uniform mat4 InvViewProj;
uniform mat4 PrevViewProj;
uniform vec3 CamDelta;
uniform float MotionStrength;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec3 here = texture(DiffuseSampler, texCoord).rgb;
    if (MotionStrength <= 0.001) { fragColor = vec4(here, 1.0); return; }
    float d = texture(DepthSampler, texCoord).r;
    vec4 p = InvViewProj * vec4(texCoord * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    vec3 world = p.xyz / p.w;
    vec4 prev = PrevViewProj * vec4(world + CamDelta, 1.0);
    if (prev.w <= 0.0) { fragColor = vec4(here, 1.0); return; }
    vec2 prevUV = prev.xy / prev.w * 0.5 + 0.5;
    vec2 vel = (texCoord - prevUV) * MotionStrength;
    float len = length(vel);
    if (len > 0.06) vel *= 0.06 / len;
    if (len < 0.0006) { fragColor = vec4(here, 1.0); return; }
    vec3 sum = vec3(0.0);
    const int N = 12;
    for (int i = 0; i < N; i++) {
        float f = float(i) / float(N - 1) - 0.5;
        sum += texture(DiffuseSampler, clamp(texCoord + vel * f, vec2(0.001), vec2(0.999))).rgb;
    }
    fragColor = vec4(sum / float(N), 1.0);
}
