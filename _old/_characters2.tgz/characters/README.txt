ANCIENT PEAKS LORE - CHARACTERS
===============================
The game reads this folder while you test (F3+T reloads it). Files starting with "_" are ignored.

MERLIN  (GeckoLib model, one animation)
  characters/merlin/merlin.geo.json          the model (player-skin layout, 64x64)
  characters/merlin/merlin.animation.json    ONE animation: "injured_lying" (loop) - wounded on the chapel floor
  characters/merlin/merlin.png               his skin
  He never gets up: once you heal him he speaks from where he lies (~16 s), blesses you, gives you his compass
  and vanishes in light. Bones the game cares about: "root" (holds everything). The head is not turned by the game.

VORTIGERN  (Epic Fight humanoid - no GeckoLib model)
  characters/vortigern/vortigern.png         his skin, in the normal 64x64 PLAYER SKIN layout (paint it like a skin)
  Epic Fight draws him with its own biped body (1.3x size) and animates him with its public greatsword moveset:
    greatsword combo (auto 1 -> auto 2 -> the knockdown swing), sweeping edge, the heavy knockdown swing,
    the ground-splitting dash, the guillotine leap, and from half health wrathful lighting (lightning on everyone
    near) and the greatsword air slash. Stun, death, idle, walk and run are Epic Fight's too.
  He wields Epic Fight's netherite greatsword and wears the Crown of Vortigern.
  The moveset is a data file: data/ancientpeaks_lore/epicfight_mobpatch/vortigern.json inside the mod - ask to
  change weights, cooldowns, distances, or to swap in other Epic Fight animations.
  A fully custom Vortigern (own mesh and moves) later means Epic Fight's Blender exporter.

ITEM ART  (items/ next to characters/)
  items/excalibur.png             16x16 icon       items/crown_of_vortigern.png    16x16 icon
  items/crown_layer_1.png         the crown as worn (64x32 armour layout, helmet area)
