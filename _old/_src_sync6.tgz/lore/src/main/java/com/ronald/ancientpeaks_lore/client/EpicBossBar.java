package com.ronald.ancientpeaks_lore.client;

import com.ronald.ancientpeaks_lore.LoreContent;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.LerpingBossEvent;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraftforge.client.event.CustomizeGuiOverlayEvent;
import net.minecraftforge.common.MinecraftForge;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Vortigern's boss bar, drawn in place of the vanilla one: a dark-crimson banner with a gold "legendary encounter"
 * header, the title in large letters with a skull plaque, the phase in gold, status chips on the right, and a long
 * health bar between a sword hilt and a gold diamond - crimson to gold, notched every 10%, a gold mark at the 50%
 * phase line, a pale trail showing the damage just dealt, a sheen sweeping across it, and a red pulse when he is
 * nearly done. Underneath, a thin gauge counts down to his second phase.
 * The server tells the phase by the bar's colour: red = phase I, purple = phase II.
 */
public final class EpicBossBar {
    private EpicBossBar() {}
    public static final String KEY = "bossbar.ancientpeaks_lore.vortigern";
    static final int MAX_HP = 400;
    private static final Map<UUID, float[]> TRAIL = new HashMap<>();   // shown trail, last seen progress

    public static void register() { MinecraftForge.EVENT_BUS.addListener(EpicBossBar::onBar); }

    private static void onBar(CustomizeGuiOverlayEvent.BossEventProgress e) {
        LerpingBossEvent b = e.getBossEvent();
        if (!(b.getName().getContents() instanceof TranslatableContents tc) || !KEY.equals(tc.getKey())) return;
        e.setCanceled(true);
        e.setIncrement(draw(e.getGuiGraphics(), b, e.getY()));
    }

    private static int argb(int a, int rgb) { return (Mth.clamp(a, 0, 255) << 24) | (rgb & 0xFFFFFF); }

    private static int mix(int c1, int c2, float k) {
        int r = (int) Mth.lerp(k, (c1 >> 16) & 255, (c2 >> 16) & 255), g = (int) Mth.lerp(k, (c1 >> 8) & 255, (c2 >> 8) & 255), bl = (int) Mth.lerp(k, c1 & 255, c2 & 255);
        return (r << 16) | (g << 8) | bl;
    }

    private static void text(GuiGraphics g, Font f, String s, float x, float y, float scale, int argb, boolean shadow) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0); g.pose().scale(scale, scale, 1);
        g.drawString(f, s, 0, 0, argb, shadow);
        g.pose().popPose();
    }

    private static float width(Font f, String s, float scale) { return f.width(s) * scale; }

    /** A diamond (a square turned 45 degrees) centred at x,y. */
    private static void diamond(GuiGraphics g, float x, float y, float r, int argb) {
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().mulPose(com.mojang.math.Axis.ZP.rotationDegrees(45));
        g.fill((int) -r, (int) -r, (int) r, (int) r, argb);
        g.pose().popPose();
    }

    private static int draw(GuiGraphics g, LerpingBossEvent b, int topY) {
        Minecraft mc = Minecraft.getInstance();
        Font f = mc.font;
        int sw = g.guiWidth();
        int W = Math.min(sw - 60, 360), x0 = (sw - W) / 2, y0 = topY - 6;
        float p = Mth.clamp(b.getProgress(), 0, 1);
        boolean two = b.getColor() == BossEvent.BossBarColor.PURPLE;
        long ms = Util.getMillis();
        float time = (ms % 100000L) / 1000f;

        // ---- the banner
        int H = 70;
        g.fillGradient(x0 - 10, y0 - 4, x0 + W + 10, y0 + H, argb(215, 0x24070A), argb(225, 0x120305));
        g.fill(x0 - 10, y0 - 4, x0 + W + 10, y0 - 3, argb(200, 0xB8862B));
        g.fill(x0 - 10, y0 + H - 1, x0 + W + 10, y0 + H, argb(200, 0xB8862B));
        g.fill(x0 - 10, y0 - 1, x0 + W + 10, y0, argb(90, 0xB8862B));

        // ---- header
        String head = "✦  LEGENDARY ENCOUNTER  •  THE HIGH MEADOW  ✦";
        text(g, f, head, sw / 2f - width(f, head, 0.6f) / 2, y0 + 1, 0.6f, argb(230, 0xD9A84A), false);

        // ---- skull plaque and title
        int sx = x0, sy = y0 + 10;
        g.fill(sx, sy, sx + 16, sy + 16, argb(255, 0x3A0E10));
        g.renderOutline(sx, sy, 16, 16, argb(255, 0xC99A3A));
        text(g, f, "☠", sx + 4, sy + 4, 1.0f, argb(255, 0xF0E6D0), false);
        text(g, f, "VORTIGERN THE USURPER", x0 + 22, y0 + 10, 1.45f, argb(255, 0xEFE8DC), true);
        String phase = two ? "PHASE II: DRAGONKIN AWAKENING • BLADE BOUND BY CURSED DRAGON FIRE" : "PHASE I: THE STONE KING WAKES • THE CROWN OF THESE ISLES";
        text(g, f, phase, x0 + 22, y0 + 24, 0.55f, argb(235, 0xD9A84A), false);

        // ---- chips (right)
        boolean excal = mc.player != null && mc.player.getMainHandItem().is(LoreContent.EXCALIBUR.get());
        String[] chips = two ? new String[]{"USURPER'S CROWN", "WHITE DRAGON'S IRE", "SAXON SHADES"} : new String[]{"USURPER'S CROWN", "STONE-BORN"};
        float cx = x0 + W;
        for (int i = chips.length - 1; i >= -1; i--) {
            String c = i == -1 ? (excal ? "EXCALIBUR IN HAND" : null) : chips[i];
            if (c == null) continue;
            float w = width(f, c, 0.55f) + 8;
            cx -= w;
            boolean gold = i == -1;
            g.fill((int) cx, y0 + 10, (int) (cx + w), y0 + 21, argb(230, gold ? 0x6B4A10 : 0x2A0A0C));
            g.renderOutline((int) cx, y0 + 10, (int) w, 11, argb(255, gold ? 0xF1C04C : 0x8A5A2A));
            text(g, f, c, cx + 4, y0 + 13.5f, 0.55f, argb(255, gold ? 0xFFE7A0 : 0xE6D3B0), false);
            cx -= 3;
        }

        // ---- health bar
        int bx = x0 + 6, by = y0 + 36, bw = W - 12, bh = 9;
        float[] tr = TRAIL.computeIfAbsent(b.getId(), k -> new float[]{p, p});
        if (p < tr[1]) tr[0] = Math.max(tr[0], tr[1]);                  // damage just taken: keep the trail where it was
        tr[1] = p;
        tr[0] = Math.max(p, tr[0] - 0.004f);                              // and let it drain down
        boolean critical = p < 0.25f;
        float pulse = critical ? (float) (0.5 + 0.5 * Math.sin(time * 6)) : 0;
        if (critical) g.fill(bx - 2, by - 2, bx + bw + 2, by + bh + 2, argb((int) (90 * pulse), 0xFF2020));
        g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, argb(255, 0xC99A3A));
        g.fill(bx, by, bx + bw, by + bh, argb(255, 0x120406));
        g.fill(bx, by, bx + (int) (bw * tr[0]), by + bh, argb(200, 0xF4E3C0));
        int fillW = (int) (bw * p);
        for (int x = 0; x < fillW; x += 2) {                               // crimson -> ember -> gold, along the bar
            float k = x / (float) bw;
            int c = k < 0.5f ? mix(0x7E0C12, 0xD8532A, k / 0.5f) : mix(0xD8532A, 0xF1C04C, (k - 0.5f) / 0.5f);
            g.fill(bx + x, by, bx + Math.min(x + 2, fillW), by + bh, argb(255, c));
        }
        g.fill(bx, by, bx + fillW, by + 2, argb(70, 0xFFFFFF));            // top highlight
        float sheen = (time * 0.35f) % 1.4f - 0.2f;                         // a sheen sweeping across
        int sxp = (int) (bx + bw * sheen);
        for (int i = 0; i < 14; i++) {
            int x = sxp + i;
            if (x < bx || x >= bx + fillW) continue;
            g.fill(x, by, x + 1, by + bh, argb((int) (60 * Math.sin(Math.PI * i / 14)), 0xFFF4D0));
        }
        for (int i = 1; i < 10; i++) {                                      // notches; the phase line in gold
            int x = bx + bw * i / 10;
            g.fill(x, by, x + 1, by + bh, i == 5 ? argb(255, 0xF1C04C) : argb(110, 0x000000));
        }
        // the hilt on the left: pommel, grip, crossguard
        diamond(g, bx - 15, by + bh / 2f, 3, argb(255, 0xF1C04C));
        g.fill(bx - 12, by + 3, bx - 5, by + bh - 3, argb(255, 0x5A3A1A));
        g.fill(bx - 5, by - 5, bx - 2, by + bh + 5, argb(255, 0xC99A3A));
        g.fill(bx - 4, by - 4, bx - 3, by + bh + 4, argb(255, 0xFFE7A0));
        // the tip on the right
        diamond(g, bx + bw + 5, by + bh / 2f, 4, argb(255, 0xC99A3A));
        diamond(g, bx + bw + 5, by + bh / 2f, 2, argb(255, 0xFFE7A0));
        int hp = Math.round(p * MAX_HP);
        text(g, f, String.format("%.1f%%  •  %d / %d", p * 100, hp, MAX_HP), bx + 4, by + 2.2f, 0.55f, argb(255, 0xFFF6E6), true);
        if (critical) {
            String crit = "PHASE CRITICAL";
            text(g, f, crit, bx + bw - width(f, crit, 0.55f) - 4, by + 2.2f, 0.55f, argb((int) (150 + 105 * pulse), 0xFFD0C0), true);
        }

        // ---- the gauge underneath: how close he is to waking the dragon fire
        int gy = by + bh + 7;
        float gauge = two ? 1 : Mth.clamp((p - 0.5f) / 0.5f, 0, 1);
        g.fill(bx, gy, bx + bw, gy + 3, argb(255, 0x1A0A0A));
        g.fill(bx, gy, bx + (int) (bw * (two ? 1 : 1 - gauge)), gy + 3, argb(255, two ? 0xB0303A : 0xC99A3A));
        String left = two ? "⚔ DRAGON FIRE UNLEASHED" : "⚔ RESOLVE";
        String right = two ? "STRIKE WITH EXCALIBUR FOR FULL DAMAGE" : Math.round(gauge * 100) + "% UNTIL PHASE II";
        text(g, f, left, bx, gy + 5, 0.5f, argb(220, 0xD9A84A), false);
        text(g, f, right, bx + bw - width(f, right, 0.5f), gy + 5, 0.5f, argb(220, 0xE6D3B0), false);
        return H + 8;
    }
}
